namespace DSW_Semester_Project
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();

            // Load every .txt file into the Lists before the first screen opens
            DataStore.LoadAll();

            // Dark or light mode, as it was the last time the app was used
            Theme.LoadTheme();

            Application.Run(new LoginForm());
        }
    }
}
