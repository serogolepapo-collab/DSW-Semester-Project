namespace DSW_Semester_Project
{
    // Small helpers so every screen looks the same.
    public static class Theme
    {
        public static readonly Color Deep = Color.FromArgb(18, 53, 36);      // sidebar
        public static readonly Color Forest = Color.FromArgb(30, 90, 60);    // buttons, active menu item
        public static readonly Color Mint = Color.FromArgb(227, 239, 230);   // selected grid row

        // Shows a list in a grid, nicer column titles, and hides the columns we don't need
        public static void ShowList<T>(DataGridView grid, List<T> list, params string[] hiddenColumns)
        {
            grid.DataSource = null;
            grid.DataSource = list;

            grid.EnableHeadersVisualStyles = false;
            grid.ColumnHeadersDefaultCellStyle.BackColor = Deep;
            grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            grid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            StyleGrid(grid);   // cell colours for light or dark mode
            grid.RowTemplate.Height = 30;

            foreach (DataGridViewColumn column in grid.Columns)
            {
                column.HeaderText = AddSpaces(column.HeaderText);
                if (column.ValueType == typeof(DateTime))
                    column.DefaultCellStyle.Format = "dd MMM yyyy";   // show the date without the time
            }
            foreach (string name in hiddenColumns)
            {
                if (grid.Columns.Contains(name)) grid.Columns[name].Visible = false;
            }
        }

        // "ResidentUsername" -> "Resident Username" (Unit 3: looping over the characters of a string)
        public static string AddSpaces(string text)
        {
            string result = "";
            for (int i = 0; i < text.Length; i++)
            {
                if (i > 0 && char.IsUpper(text[i])) result += " ";
                result += text[i];
            }
            return result;
        }

        // ---------- resizing (so a maximized window fills the screen properly) ----------

        // For the dashboards: when the window grows, every control is moved and stretched in
        // proportion, so the layout always matches the page. Call it once from the form's Load event.
        // All the scaling uses the FORM's own size (never a tab page's size, which isn't reliable yet).
        public static void MakeResponsive(Form form)
        {
            form.MinimumSize = form.Size;   // don't let the window get smaller than the design
            Size design = form.ClientSize;

            // Width taken by the docked sidebar(s). That part never grows.
            int fixedWidth = 0;
            foreach (Control c in form.Controls)
            {
                if (c.Dock == DockStyle.Left || c.Dock == DockStyle.Right) fixedWidth += c.Width;
            }

            // Remember the starting position and size of every control that is placed by hand
            List<ScaledItem> items = new List<ScaledItem>();
            foreach (Control top in form.Controls)
            {
                bool inSidebar = top.Dock == DockStyle.Left || top.Dock == DockStyle.Right;
                CollectItems(top, inSidebar, items);
            }

            form.SizeChanged += (sender, e) =>
            {
                if (form.WindowState == FormWindowState.Minimized) return;

                float sx = (float)(form.ClientSize.Width - fixedWidth) / Math.Max(1, design.Width - fixedWidth);
                float sy = (float)form.ClientSize.Height / Math.Max(1, design.Height);

                foreach (ScaledItem item in items)
                {
                    Control c = item.Control;
                    Rectangle r = item.Bounds;
                    float fx = item.InSidebar ? 1f : sx;   // the sidebar keeps its width

                    // Text boxes, buttons and labels keep their height so the text stays readable
                    bool keepHeight = c is Button || c is Label || c is TextBox || c is ComboBox ||
                                      c is DateTimePicker || c is NumericUpDown || c is CheckBox || c is RadioButton;

                    c.SetBounds((int)(r.Left * fx), (int)(r.Top * sy),
                                (int)(r.Width * fx), keepHeight ? r.Height : (int)(r.Height * sy));
                }
            };
        }

        private class ScaledItem
        {
            public Control Control;
            public Rectangle Bounds;
            public bool InSidebar;
        }

        // Walks into panels and tab pages and records the controls that sit at a fixed position
        private static void CollectItems(Control container, bool inSidebar, List<ScaledItem> items)
        {
            if (container is FlowLayoutPanel || container is TableLayoutPanel) return;   // they arrange themselves

            foreach (Control child in container.Controls)
            {
                if (child.Dock == DockStyle.None && child.Anchor == (AnchorStyles.Top | AnchorStyles.Left))
                    items.Add(new ScaledItem { Control = child, Bounds = child.Bounds, InSidebar = inSidebar });

                if (child is Panel || child is TabControl || child is TabPage || child is GroupBox)
                    CollectItems(child, inSidebar, items);
            }
        }

        // For Login and Register: the content keeps its size and stays centred when the window grows.
        public static void CenterContent(Form form)
        {
            form.MinimumSize = form.Size;
            Size design = form.ClientSize;
            List<KeyValuePair<Control, Point>> items = new List<KeyValuePair<Control, Point>>();

            foreach (Control child in form.Controls)
            {
                if (child.Dock == DockStyle.None)
                    items.Add(new KeyValuePair<Control, Point>(child, child.Location));
            }

            form.SizeChanged += (sender, e) =>
            {
                int dx = (form.ClientSize.Width - design.Width) / 2;
                int dy = (form.ClientSize.Height - design.Height) / 2;
                foreach (KeyValuePair<Control, Point> item in items)
                    item.Key.Location = new Point(item.Value.X + dx, item.Value.Y + dy);
            };
        }

        // Colours the clicked sidebar button and resets the others
        public static void HighlightMenu(Panel sidebar, Button active)
        {
            foreach (Control control in sidebar.Controls)
            {
                if (control is Button button && button.Name.StartsWith("btnNav"))
                    button.BackColor = (button == active) ? Forest : Deep;
            }
        }

        // ================= DARK MODE / LIGHT MODE =================
        // The choice is saved in theme.txt (next to the other .txt files) so the app remembers it.

        private const string ThemeFile = "theme.txt";
        public static bool IsDark = false;

        // Colours that change between the two modes. Same position = same colour:
        // LightBacks[0] (white) becomes DarkBacks[0] in dark mode, and back again in light mode.
        // Colours that are not in these lists (the green sidebar and buttons, white text) never change.
        private static readonly Color[] LightBacks =
        {
            Color.FromArgb(255, 255, 255),   // cards, text boxes, grids
            Color.FromArgb(243, 244, 239),   // page background
            Color.FromArgb(240, 240, 240),   // default Windows grey
            Color.FromArgb(227, 239, 230)    // Mint (selected / highlighted)
        };
        private static readonly Color[] DarkBacks =
        {
            Color.FromArgb(36, 40, 38),
            Color.FromArgb(24, 27, 25),
            Color.FromArgb(25, 28, 26),
            Color.FromArgb(38, 66, 50)
        };
        private static readonly Color[] LightTexts =
        {
            Color.FromArgb(22, 32, 26),      // normal text
            Color.FromArgb(0, 0, 0),         // black text
            Color.FromArgb(95, 107, 99),     // grey hint text
            Color.FromArgb(30, 90, 60),      // green text
            Color.FromArgb(163, 33, 22)      // red text
        };
        private static readonly Color[] DarkTexts =
        {
            Color.FromArgb(230, 235, 231),
            Color.FromArgb(231, 236, 232),
            Color.FromArgb(165, 176, 168),
            Color.FromArgb(120, 200, 150),
            Color.FromArgb(240, 120, 110)
        };

        // Handy colours for code that draws by itself (the chart, the stop list on the driver map)
        public static Color CardColor { get { return IsDark ? DarkBacks[0] : LightBacks[0]; } }
        public static Color TextColor { get { return IsDark ? DarkTexts[0] : LightTexts[0]; } }
        public static Color HintColor { get { return IsDark ? DarkTexts[2] : LightTexts[2]; } }
        public static Color SelectedColor { get { return IsDark ? DarkBacks[3] : LightBacks[3]; } }

        // Called once in Program.cs before the first screen opens
        public static void LoadTheme()
        {
            try
            {
                if (File.Exists(ThemeFile))
                    IsDark = File.ReadAllText(ThemeFile).Trim() == "dark";
            }
            catch (IOException)
            {
                IsDark = false;   // can't read it: just use light mode
            }
        }

        private static void SaveTheme()
        {
            try
            {
                File.WriteAllText(ThemeFile, IsDark ? "dark" : "light");
            }
            catch (IOException) { }                 // not saved: the app still works
            catch (UnauthorizedAccessException) { }
        }

        // What the dark / light button says
        public static string ThemeButtonText()
        {
            return IsDark ? "\u2600  Light mode" : "\u263E  Dark mode";
        }

        // The dark / light button on every screen calls this
        public static void ToggleTheme()
        {
            IsDark = !IsDark;
            SaveTheme();

            // Change every window that is open (e.g. the hidden login screen too)
            foreach (Form form in Application.OpenForms)
                ApplyTheme(form);
        }

        // Gives a control and everything inside it the colours of the current mode.
        // Each form calls it once in its constructor, after InitializeComponent().
        public static void ApplyTheme(Control control)
        {
            Color[] fromBacks = IsDark ? LightBacks : DarkBacks;
            Color[] toBacks = IsDark ? DarkBacks : LightBacks;
            Color[] fromTexts = IsDark ? LightTexts : DarkTexts;
            Color[] toTexts = IsDark ? DarkTexts : LightTexts;

            Color newBack = SwapColor(control.BackColor, fromBacks, toBacks);
            if (newBack != control.BackColor) control.BackColor = newBack;

            Color newText = SwapColor(control.ForeColor, fromTexts, toTexts);
            if (newText != control.ForeColor) control.ForeColor = newText;

            // A few controls need a little extra
            if (control is DataGridView grid)
                StyleGrid(grid);
            if (control is ComboBox combo)
                combo.FlatStyle = IsDark ? FlatStyle.Flat : FlatStyle.Standard;   // Flat lets the box use our colours
            if (control is TabPage page)
                page.UseVisualStyleBackColor = false;
            if (control is Button button && button.Name == "btnTheme")
                button.Text = ThemeButtonText();

            // Same thing for everything inside this control (panels, tab pages, ...)
            foreach (Control child in control.Controls)
                ApplyTheme(child);

            control.Invalidate();   // redraw things that draw themselves, like the chart
        }

        // Looks for the colour in one list and returns the colour at the same place in the other list
        private static Color SwapColor(Color current, Color[] from, Color[] to)
        {
            for (int i = 0; i < from.Length; i++)
            {
                if (current.ToArgb() == from[i].ToArgb())
                    return to[i];
            }
            return current;   // not in the list: keep it as it is
        }

        // Cell colours of a grid (the header row stays dark green in both modes)
        public static void StyleGrid(DataGridView grid)
        {
            grid.BackgroundColor = CardColor;
            grid.DefaultCellStyle.BackColor = CardColor;
            grid.DefaultCellStyle.ForeColor = TextColor;
            grid.DefaultCellStyle.SelectionBackColor = SelectedColor;
            grid.DefaultCellStyle.SelectionForeColor = IsDark ? Color.White : Color.Black;
            grid.GridColor = IsDark ? Color.FromArgb(62, 68, 64) : Color.FromArgb(220, 224, 218);
        }

        // The sidebar buttons already switch pages, so the tab headers at the top are hidden
        // while the app runs (they still show in the designer, so you can edit each page).
        public static void HideTabHeaders(TabControl tabs)
        {
            tabs.Appearance = TabAppearance.FlatButtons;
            tabs.ItemSize = new Size(0, 1);
            tabs.SizeMode = TabSizeMode.Fixed;
        }

        // ================= MESSAGES =================

        public static void ShowError(string message)
        {
            MessageBox.Show(message, "Please check", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        public static void ShowInfo(string message)
        {
            MessageBox.Show(message, "Smart Waste", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
