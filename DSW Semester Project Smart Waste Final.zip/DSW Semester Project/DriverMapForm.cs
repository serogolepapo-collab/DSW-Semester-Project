using Microsoft.Web.WebView2.WinForms;
using Microsoft.Web.WebView2.Core;
using System.Globalization;
using System.Text.Json;

namespace DSW_Semester_Project
{
    // Admin only: shows where a driver is going. Every stop for that driver on one day is a
    // numbered pin on the map, joined by a dashed line in order. The driver's CURRENT stop
    // (the job that is in progress, or otherwise the next one) is the big pulsing pin.
    //
    // The app has no GPS, so "where the driver is going" comes from the driver's jobs:
    // the status the driver sets in the Staff screen (Start / Completed / Missed) decides the colours.
    public class DriverMapForm : Form
    {
        private class Stop
        {
            public WasteCollection Job;
            public GeoPoint? Point;       // null = address not found
            public bool IsCurrent;
        }

        private readonly StaffMember _driver;
        private readonly DateTime _date;
        private readonly List<Stop> _stops = new List<Stop>();

        private readonly Label _header = new Label();
        private readonly ListBox _list = new ListBox();
        private readonly WebView2 _web = new WebView2();
        private readonly Label _status = new Label();
        private bool _mapReady;

        public DriverMapForm(StaffMember driver, DateTime date, List<WasteCollection> jobs)
        {
            _driver = driver;
            _date = date;

            foreach (WasteCollection job in jobs)
                _stops.Add(new Stop { Job = job });
            MarkCurrentStop();

            Text = "Track driver - " + driver.FullName;
            Size = new Size(1150, 720);
            MinimumSize = new Size(800, 500);
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Color.White;

            // ---- top bar: who, which truck, where to ----
            _header.Dock = DockStyle.Top;
            _header.Height = 66;
            _header.Font = new Font("Segoe UI", 10.5F);
            _header.ForeColor = Color.White;
            _header.BackColor = Theme.Deep;
            _header.Padding = new Padding(14, 6, 0, 0);
            _header.Text = BuildHeaderText();

            // ---- left: the list of stops ----
            Panel left = new Panel();
            left.Dock = DockStyle.Left;
            left.Width = 320;
            left.BackColor = Color.White;

            _list.Dock = DockStyle.Fill;
            _list.BorderStyle = BorderStyle.None;
            _list.DrawMode = DrawMode.OwnerDrawFixed;
            _list.ItemHeight = 70;
            _list.DrawItem += List_DrawItem;
            _list.SelectedIndexChanged += List_SelectedIndexChanged;
            foreach (Stop s in _stops) _list.Items.Add(s.Job.Id);
            left.Controls.Add(_list);

            // ---- bottom: loading / error message ----
            _status.Dock = DockStyle.Bottom;
            _status.Height = 30;
            _status.Font = new Font("Segoe UI", 9.5F);
            _status.ForeColor = Color.FromArgb(22, 32, 26);
            _status.TextAlign = ContentAlignment.MiddleLeft;
            _status.Padding = new Padding(10, 0, 0, 0);
            _status.BackColor = Theme.Mint;
            _status.Text = "Finding the addresses on the map ...";

            _web.Dock = DockStyle.Fill;

            // The order matters for docking: fill first, then the edges
            Controls.Add(_web);
            Controls.Add(left);
            Controls.Add(_status);
            Controls.Add(_header);

            Theme.ApplyTheme(this);   // follows the dark / light setting
            Load += DriverMapForm_Load;
        }

        // The stop the driver is at / heading to: the job in progress, otherwise the first one still to do
        private void MarkCurrentStop()
        {
            Stop current = null;
            foreach (Stop s in _stops)
                if (s.Job.Status == CollectionStatus.InProgress) { current = s; break; }
            if (current == null)
                foreach (Stop s in _stops)
                    if (s.Job.Status == CollectionStatus.Assigned) { current = s; break; }
            if (current != null) current.IsCurrent = true;
        }

        private string BuildHeaderText()
        {
            string vehicle = "";
            foreach (Stop s in _stops)
                if (s.Job.VehicleRegistration != "") { vehicle = s.Job.VehicleRegistration; break; }

            int done = 0;
            foreach (Stop s in _stops)
                if (s.Job.Status == CollectionStatus.Completed || s.Job.Status == CollectionStatus.Missed) done++;

            string line1 = $"{_driver.FullName}   |   Vehicle: {(vehicle == "" ? "none" : vehicle)}   |   " +
                           $"{_date:dddd, d MMMM yyyy}   |   {done} of {_stops.Count} stops done";

            string line2;
            Stop current = _stops.Find(s => s.IsCurrent);
            if (current == null)
                line2 = "No stops left for this driver.";
            else if (current.Job.Status == CollectionStatus.InProgress)
                line2 = "Currently at / working on: " + current.Job.Address;
            else
                line2 = "Heading to next: " + current.Job.Address;

            return line1 + "\r\n" + line2;
        }

        private static Color StatusColor(CollectionStatus status)
        {
            switch (status)
            {
                case CollectionStatus.InProgress: return Color.FromArgb(234, 88, 12);
                case CollectionStatus.Completed: return Color.FromArgb(30, 90, 60);
                case CollectionStatus.Missed: return Color.FromArgb(163, 33, 22);
                default: return Color.FromArgb(37, 99, 235);   // Assigned = still to come
            }
        }

        // ---------------- loading the map ----------------

        private async void DriverMapForm_Load(object sender, EventArgs e)
        {
            try
            {
                string cache = Path.Combine(Path.GetTempPath(), "DSW_WebView2");
                CoreWebView2Environment env = await CoreWebView2Environment.CreateAsync(null, cache);
                await _web.EnsureCoreWebView2Async(env);
                if (IsDisposed) return;
                _web.CoreWebView2.NavigationCompleted += (s, a) => _mapReady = true;

                // Look up each address (one at a time, the free service asks for that)
                bool networkProblem = false;
                for (int i = 0; i < _stops.Count; i++)
                {
                    _status.Text = $"Finding the addresses on the map ...  ({i + 1} of {_stops.Count})";
                    try
                    {
                        _stops[i].Point = await Geocoder.FindAsync(_stops[i].Job.Address);
                    }
                    catch (Exception)
                    {
                        networkProblem = true;
                    }
                    if (IsDisposed) return;
                    _list.Invalidate();
                }

                // OpenStreetMap's tile servers need a website "Referer", so the page is served from a
                // proper https address (same trick as MapForm).
                string folder = Path.Combine(Path.GetTempPath(), "DSW_Map_Page");
                Directory.CreateDirectory(folder);
                File.WriteAllText(Path.Combine(folder, "driver_map.html"), BuildHtml());
                _web.CoreWebView2.SetVirtualHostNameToFolderMapping(
                    "dsw-map.local", folder, CoreWebView2HostResourceAccessKind.Allow);
                _web.CoreWebView2.Navigate("https://dsw-map.local/driver_map.html");

                int notFound = _stops.Count(s => s.Point == null);
                if (networkProblem)
                    _status.Text = "Some addresses couldn't be looked up. Check your internet connection.";
                else if (notFound > 0)
                    _status.Text = $"{notFound} address(es) couldn't be found on the map (they are marked in the list).";
                else
                    _status.Text = "Click a stop in the list to zoom to it. Pins: blue = still to come, orange = in progress, green = done, red = missed.";
            }
            catch (Exception ex)
            {
                _status.Text = "The map couldn't load. Check your internet connection.";
                Theme.ShowError("Map error: " + ex.Message +
                    "\n\nIf this says WebView2 is missing, install the 'WebView2 Runtime' from Microsoft.");
            }
        }

        // The map page. Leaflet is loaded from a CDN, so the PC needs internet.
        // The stops are handed to the page as JSON (System.Text.Json escapes everything safely).
        private string BuildHtml()
        {
            var data = new List<object>();
            for (int i = 0; i < _stops.Count; i++)
            {
                Stop s = _stops[i];
                data.Add(new
                {
                    n = i + 1,
                    title = s.Job.CollectionType,
                    addr = s.Job.Address,
                    status = s.Job.Status.ToString(),
                    cls = s.Job.Status.ToString().ToLower(),
                    current = s.IsCurrent,
                    lat = s.Point.HasValue ? (double?)s.Point.Value.Lat : null,
                    lon = s.Point.HasValue ? (double?)s.Point.Value.Lon : null
                });
            }
            string json = JsonSerializer.Serialize(data);

            return @"<!DOCTYPE html>
<html><head><meta charset='utf-8'>
<meta name='referrer' content='strict-origin-when-cross-origin'>
<link rel='stylesheet' href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'/>
<script src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'></script>
<style>
html,body,#map{height:100%;margin:0}
.wrap{width:40px;height:40px;display:flex;align-items:center;justify-content:center}
.pin{width:28px;height:28px;border-radius:50%;color:#fff;font:bold 13px 'Segoe UI',Arial,sans-serif;
     display:flex;align-items:center;justify-content:center;border:2px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,.5)}
.assigned{background:#2563eb;--pc:rgba(37,99,235,.7)}
.inprogress{background:#ea580c;--pc:rgba(234,88,12,.7)}
.completed{background:#1e5a3c}
.missed{background:#a32116}
.current{width:38px;height:38px;font-size:16px;animation:pulse 1.4s infinite}
@keyframes pulse{0%{box-shadow:0 0 0 0 var(--pc)}70%{box-shadow:0 0 0 16px transparent}100%{box-shadow:0 0 0 0 transparent}}
.legend{position:absolute;left:10px;bottom:24px;z-index:1000;background:#fff;padding:8px 10px;border-radius:6px;
        font:12px 'Segoe UI',Arial,sans-serif;box-shadow:0 1px 5px rgba(0,0,0,.4);line-height:1.6}
.dot{display:inline-block;width:11px;height:11px;border-radius:50%;margin-right:6px;vertical-align:middle}
</style></head>
<body><div id='map'></div>
<div class='legend'>
<div><span class='dot' style='background:#ea580c'></span>In progress (driver is here)</div>
<div><span class='dot' style='background:#2563eb'></span>Still to come</div>
<div><span class='dot' style='background:#1e5a3c'></span>Completed</div>
<div><span class='dot' style='background:#a32116'></span>Missed</div>
</div>
<script>
var stops = " + json + @";
var map = L.map('map').setView([-26.2041, 28.0473], 10);   // start on Johannesburg; the real view is set below
L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19,
  attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);

var markers = [];
var points = [];

stops.forEach(function (s, i) {
  if (s.lat === null) { markers.push(null); return; }

  var icon = L.divIcon({
    className: '',
    html: '<div class=""wrap""><div class=""pin ' + s.cls + (s.current ? ' current' : '') + '"">' + s.n + '</div></div>',
    iconSize: [40, 40],
    iconAnchor: [20, 20]
  });

  var popup = document.createElement('div');
  var b = document.createElement('b');
  b.textContent = s.n + '. ' + s.title;
  popup.appendChild(b);
  popup.appendChild(document.createElement('br'));
  popup.appendChild(document.createTextNode(s.addr));
  popup.appendChild(document.createElement('br'));
  popup.appendChild(document.createTextNode(s.status + (s.current ? ' - current stop' : '')));

  var m = L.marker([s.lat, s.lon], { icon: icon, zIndexOffset: s.current ? 1000 : 0 }).addTo(map).bindPopup(popup);
  markers.push(m);
  points.push([s.lat, s.lon]);
  if (s.current) m.openPopup();
});

if (points.length > 1) {
  L.polyline(points, { color: '#4b5563', weight: 3, dashArray: '8 8' }).addTo(map);
}

if (points.length === 1) {
  map.setView(points[0], 15);
} else if (points.length > 1) {
  map.fitBounds(points, { padding: [50, 50] });
}

// Called from the stop list in the C# form
function focusStop(i) {
  var m = markers[i];
  if (!m) return;
  map.setView(m.getLatLng(), 16);
  m.openPopup();
}
</script></body></html>";
        }

        // ---------------- the list of stops ----------------

        private async void List_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_list.SelectedIndex < 0 || !_mapReady) return;
            try
            {
                await _web.CoreWebView2.ExecuteScriptAsync("focusStop(" + _list.SelectedIndex + ")");
            }
            catch (Exception)
            {
                // the page isn't ready yet: ignore, the next click will work
            }
        }

        // Draws each stop as three lines: number + type, status, address
        private void List_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0 || e.Index >= _stops.Count) return;

            Stop s = _stops[e.Index];
            Rectangle r = e.Bounds;
            bool selected = (e.State & DrawItemState.Selected) == DrawItemState.Selected;

            using (SolidBrush back = new SolidBrush(selected ? Theme.SelectedColor : Theme.CardColor))
                e.Graphics.FillRectangle(back, r);

            // coloured strip on the left shows the status
            using (SolidBrush strip = new SolidBrush(StatusColor(s.Job.Status)))
                e.Graphics.FillRectangle(strip, r.Left, r.Top, 7, r.Height);

            string statusText = s.Job.Status.ToString();
            if (s.IsCurrent) statusText += s.Job.Status == CollectionStatus.InProgress ? "  -  driver is here" : "  -  next stop";
            if (s.Point == null) statusText += "  (not found on map)";

            using (Font bold = new Font("Segoe UI", 10.5F, FontStyle.Bold))
            using (Font small = new Font("Segoe UI", 9F))
            using (SolidBrush dark = new SolidBrush(Theme.TextColor))
            using (SolidBrush statusBrush = new SolidBrush(StatusColor(s.Job.Status)))
            using (SolidBrush gray = new SolidBrush(Theme.HintColor))
            using (StringFormat format = new StringFormat { Trimming = StringTrimming.EllipsisCharacter, FormatFlags = StringFormatFlags.NoWrap })
            {
                float x = r.Left + 16;
                float width = r.Width - 24;
                e.Graphics.DrawString($"{e.Index + 1}. {s.Job.CollectionType}", bold, dark, new RectangleF(x, r.Top + 6, width, 22), format);
                e.Graphics.DrawString(statusText, small, statusBrush, new RectangleF(x, r.Top + 29, width, 18), format);
                e.Graphics.DrawString(s.Job.Address, small, gray, new RectangleF(x, r.Top + 47, width, 18), format);
            }

            using (Pen line = new Pen(Theme.IsDark ? Color.FromArgb(62, 68, 64) : Color.FromArgb(225, 228, 222)))
                e.Graphics.DrawLine(line, r.Left, r.Bottom - 1, r.Right, r.Bottom - 1);
        }
    }
}
