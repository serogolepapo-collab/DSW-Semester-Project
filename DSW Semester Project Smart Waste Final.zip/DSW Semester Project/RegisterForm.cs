namespace DSW_Semester_Project
{
    public partial class RegisterForm : Form
    {
        // The login screen reads this after a successful registration
        public string NewUsername { get; private set; } = "";

        public RegisterForm()
        {
            InitializeComponent();
            Load += (s, e) => Theme.CenterContent(this);
            Theme.ApplyTheme(this);   // dark or light colours
        }

        // Switches between dark mode and light mode (every open window changes)
        private void btnTheme_Click(object sender, EventArgs e)
        {
            Theme.ToggleTheme();
        }

        private void btnCreateAccount_Click(object sender, EventArgs e)
        {
            lblError.Text = "";
            try
            {
                Resident resident = AccountManager.Register(
                    txtFullName.Text, txtEmail.Text, txtPhone.Text, txtNewUsername.Text,
                    txtNewPassword.Text, txtConfirm.Text,
                    txtStreet.Text, txtSuburb.Text, txtCity.Text, txtPostalCode.Text);

                NewUsername = resident.Username;
                DialogResult = DialogResult.OK;   // closes this form and tells the login screen it worked
            }
            catch (ArgumentException ex)
            {
                lblError.Text = ex.Message;       // shown in red next to the button
            }
        }

        private void btnBackToLogin_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void chkShowPasswords_CheckedChanged(object sender, EventArgs e)
        {
            txtNewPassword.UseSystemPasswordChar = !chkShowPasswords.Checked;
            txtConfirm.UseSystemPasswordChar = !chkShowPasswords.Checked;
        }
    }
}
