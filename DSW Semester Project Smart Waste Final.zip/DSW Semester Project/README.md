# Smart Waste Collection & Recycling (C# WinForms, .NET 10)

## How to run

1. Open `DSW Semester Project.sln` in Visual Studio.
2. Press **F5**.

The first run creates demo data in `bin\Debug\net10.0-windows\*.txt`:

| Role | Username | Password |
|---|---|---|
| Resident | `michael` | `Resident@123` |
| Administrator | `admin` (or any new name) | `Admin@123` |
| Collection staff | `thabo` (or any new name) | `Staff@123` |

To start with empty data, delete the `.txt` files in that folder.

## Folders

- **Models**
  - `User` is the parent class, with `Resident`, `StaffMember` and `Administrator` as its children.
  - The other models are `Address`, `WasteCollection`, `RecyclingRequest`, `Complaint`, `Vehicle` and the status enums.
- **Data**
  - `DataStore` reads and writes the `.txt` files.
  - `AccountManager` handles login and registration.
  - `Validator` checks passwords, emails, phone numbers and postal codes.
  - `SampleData` holds the demo records.
  - `Theme` has the shared colours and grid styling.
  - `Geocoder` turns an address into map coordinates (OpenStreetMap Nominatim) and remembers the results.
- **Forms**
  - `LoginForm` and `RegisterForm` are the sign-in screens.
  - `ResidentForm`, `AdminForm` and `StaffForm` are the three dashboards.
  - `MissedReasonForm` is the pop-up that asks staff why a collection was missed.
  - `MapForm` shows one address on a map (staff). `DriverMapForm` shows all of a driver's stops for a day, with the current stop highlighted (admin: Collections page > **Track driver**).
  - Every form has a `.Designer.cs` file, so you can open it in the designer.

## UML (inheritance)

```
                 User
  - _username, _password
  + Username, Password, FullName, Email, Phone
  + CheckPassword()
  + virtual GetRole(), OpenDashboard(), ToFileLine()
        ^              ^                 ^
        |              |                 |
    Resident      StaffMember       Administrator
                  + IsOnDuty
  (each one overrides GetRole() and OpenDashboard())
```

## Where each OOP idea is

| Idea | Where |
|---|---|
| Encapsulation | Private fields with validating properties: `User.Password`, `Address.PostalCode`, `Vehicle.CapacityTons`, `RecyclingRequest.Bags`, `Complaint.Description` |
| Abstraction | `WasteCollection.Assign()`, `Start()`, `Complete()`, `MarkMissed()`, `Cancel()`, and `Complaint.Resolve()` |
| Inheritance | `Resident : User`, `StaffMember : User`, `Administrator : User` |
| Polymorphism | `user.OpenDashboard()` in `LoginForm` opens a different screen for each role |
| Constructors | Default and parameterised constructors in `User`, and `base(...)` in the child classes |
| Text files | `DataStore`: `File.Exists`, `ReadAllLines`, `WriteAllLines`, `Split('|')`, try-catch |

## Latest changes

**Admin, Collections page**
- The "Schedule a collection" panel is gone. Residents already choose the type, address and date when they request a pickup.
- The admin clicks a collection in the grid. The **Selected collection** card shows who it is for (name, type, date, address), and the admin picks a driver and a vehicle, then clicks **Assign driver & vehicle**.
- The grid now opens on **Scheduled**, so the requests still waiting for a driver are shown first.

**Admin, Vehicles & staff page**
- "Add a staff member" now has **Email** and **Phone** boxes. They are checked with `Validator.IsValidEmail` / `IsValidPhone` (the same rules as the Register form), saved in users.txt and shown in the staff grid.

**Dark mode / light mode**
- Every screen has a **Dark mode / Light mode** button: in the sidebar on the dashboards and at the top of the Login and Register screens. The pop-ups and maps follow the same setting.
- Clicking it changes every open window at once, and the choice is saved in `theme.txt`, so the app remembers it next time.
- All the code is in `Data/Theme.cs`, under "DARK MODE / LIGHT MODE". It has two lists of colours (light and dark). `ApplyTheme` loops over every control and swaps each light colour for the dark one in the same position, or back again.
- While the app runs, the tab headers at the top of the dashboards are hidden, because the sidebar buttons already switch pages. They still show in the designer, so you can click through the pages to edit them.
