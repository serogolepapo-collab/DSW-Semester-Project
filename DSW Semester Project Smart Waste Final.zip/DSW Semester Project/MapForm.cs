using Microsoft.Web.WebView2.WinForms;
using Microsoft.Web.WebView2.Core;
using System.Globalization;
using System.Net.Http;
using System.Text.Json;

namespace DSW_Semester_Project
{
    // A pop-up map (OpenStreetMap + Leaflet, shown inside a WebView2 control).
    // No API key is needed. The address is turned into coordinates with the free Nominatim service.
    public class MapForm : Form
    {
        private readonly string _address;
        private readonly string _title;
        private readonly WebView2 _web = new WebView2();
        private readonly Label _status = new Label();
        private readonly Button _btnDirections = new Button();
        private double _lat, _lon;
        private bool _found;

        // One shared HttpClient. Nominatim requires a User-Agent that identifies the app.
        private static readonly HttpClient Http = CreateClient();

        private static HttpClient CreateClient()
        {
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.UserAgent.ParseAdd("DSW-Semester-Project/1.0 (student project)");
            client.Timeout = TimeSpan.FromSeconds(15);
            return client;
        }

        public MapForm(string address, string title)
        {
            _address = address;
            _title = title;

            Text = "Map - " + title;
            Size = new Size(900, 650);
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Color.White;

            _status.Dock = DockStyle.Top;
            _status.Height = 36;
            _status.Font = new Font("Segoe UI", 10.5F);
            _status.ForeColor = Color.FromArgb(22, 32, 26);
            _status.TextAlign = ContentAlignment.MiddleLeft;
            _status.Padding = new Padding(10, 0, 0, 0);
            _status.Text = "Finding " + address + " ...";

            _btnDirections.Dock = DockStyle.Bottom;
            _btnDirections.Height = 44;
            _btnDirections.Text = "Get directions (opens in your browser)";
            _btnDirections.FlatStyle = FlatStyle.Flat;
            _btnDirections.FlatAppearance.BorderSize = 0;
            _btnDirections.BackColor = Theme.Forest;
            _btnDirections.ForeColor = Color.White;
            _btnDirections.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            _btnDirections.Cursor = Cursors.Hand;
            _btnDirections.Enabled = false;
            _btnDirections.Click += btnDirections_Click;

            _web.Dock = DockStyle.Fill;

            Controls.Add(_web);
            Controls.Add(_btnDirections);
            Controls.Add(_status);

            Theme.ApplyTheme(this);   // follows the dark / light setting
            Load += MapForm_Load;
        }

        private async void MapForm_Load(object sender, EventArgs e)
        {
            try
            {
                // Keep WebView2's cache in the temp folder (Program Files isn't writable)
                string cache = Path.Combine(Path.GetTempPath(), "DSW_WebView2");
                CoreWebView2Environment env = await CoreWebView2Environment.CreateAsync(null, cache);
                await _web.EnsureCoreWebView2Async(env);

                if (!await FindAddress())
                {
                    _status.Text = "Couldn't find that address on the map: " + _address;
                    return;
                }

                _status.Text = _address;

                // OpenStreetMap's tile servers block requests that have no website "Referer".
                // So instead of NavigateToString, save the page as a file and serve it from a
                // proper https address (https://dsw-map.local/). The browser then sends the Referer.
                string folder = Path.Combine(Path.GetTempPath(), "DSW_Map_Page");
                Directory.CreateDirectory(folder);
                File.WriteAllText(Path.Combine(folder, "map.html"), BuildHtml());
                _web.CoreWebView2.SetVirtualHostNameToFolderMapping(
                    "dsw-map.local", folder, CoreWebView2HostResourceAccessKind.Allow);
                _web.CoreWebView2.Navigate("https://dsw-map.local/map.html");
                _btnDirections.Enabled = true;
            }
            catch (Exception ex)
            {
                _status.Text = "The map couldn't load. Check your internet connection.";
                Theme.ShowError("Map error: " + ex.Message +
                    "\n\nIf this says WebView2 is missing, install the 'WebView2 Runtime' from Microsoft.");
            }
        }

        // Tries the full address first, then a looser search (suburb + city + postal code)
        private async Task<bool> FindAddress()
        {
            string[] parts = _address.Split(',');
            List<string> attempts = new List<string> { _address };
            if (parts.Length > 1)
                attempts.Add(string.Join(",", parts.Skip(1)).Trim());   // drop the street

            foreach (string attempt in attempts)
            {
                string url = "https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=za&q=" +
                             Uri.EscapeDataString(attempt);
                string json = await Http.GetStringAsync(url);

                using (JsonDocument doc = JsonDocument.Parse(json))
                {
                    JsonElement list = doc.RootElement;
                    if (list.GetArrayLength() == 0) continue;

                    JsonElement first = list[0];
                    _lat = double.Parse(first.GetProperty("lat").GetString(), CultureInfo.InvariantCulture);
                    _lon = double.Parse(first.GetProperty("lon").GetString(), CultureInfo.InvariantCulture);
                    _found = true;
                    return true;
                }
            }
            return false;
        }

        // Builds a tiny web page with the map. Leaflet is loaded from a CDN, so the PC needs internet.
        private string BuildHtml()
        {
            string lat = _lat.ToString(CultureInfo.InvariantCulture);
            string lon = _lon.ToString(CultureInfo.InvariantCulture);
            string label = System.Net.WebUtility.HtmlEncode(_title).Replace("'", "\\'");

            return @"<!DOCTYPE html>
<html><head><meta charset='utf-8'>
<meta name='referrer' content='strict-origin-when-cross-origin'>
<link rel='stylesheet' href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'/>
<script src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'></script>
<style>html,body,#map{height:100%;margin:0}</style></head>
<body><div id='map'></div>
<script>
var map = L.map('map').setView([" + lat + ", " + lon + @"], 16);
L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19,
  attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);
L.marker([" + lat + ", " + lon + @"]).addTo(map).bindPopup('" + label + @"').openPopup();
</script></body></html>";
        }

        private void btnDirections_Click(object sender, EventArgs e)
        {
            if (!_found) return;
            string dest = _lat.ToString(CultureInfo.InvariantCulture) + "," + _lon.ToString(CultureInfo.InvariantCulture);
            string url = "https://www.google.com/maps/dir/?api=1&destination=" + dest;
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(url) { UseShellExecute = true });
        }
    }
}
