namespace DSW_Semester_Project
{
    public partial class AdminForm : Form
    {
        private readonly Administrator _admin;
        private string _lastReport = "";   // kept so it can be exported

        public AdminForm(Administrator admin)
        {
            InitializeComponent();
            Load += (s, e) => Theme.MakeResponsive(this);
            _admin = admin;
        }

        private void AdminForm_Load(object sender, EventArgs e)
        {
            lblHello.Text = "Hello, " + _admin.FullName;
            lblDashDate.Text = DateTime.Today.ToString("dddd, d MMMM yyyy");
            dtpSchDate.MinDate = DateTime.Today.AddDays(1);
            cboStatusFilter.SelectedIndex = 0;
            cboRecFilter.SelectedIndex = 1;    // Pending first: that's the work to do
            cboCompFilter.SelectedIndex = 0;   // Open complaints
            cboReportType.SelectedIndex = 0;
            RefreshAll();
            Theme.HighlightMenu(pnlSidebar, btnNavDashboard);
        }

        // ---------------- menu ----------------

        private void btnNavDashboard_Click(object sender, EventArgs e) { ShowPage(tabDashboard, btnNavDashboard); }
        private void btnNavResidents_Click(object sender, EventArgs e) { ShowPage(tabResidents, btnNavResidents); }
        private void btnNavCollections_Click(object sender, EventArgs e) { ShowPage(tabCollections, btnNavCollections); }
        private void btnNavFleet_Click(object sender, EventArgs e) { ShowPage(tabFleet, btnNavFleet); }
        private void btnNavRecycling_Click(object sender, EventArgs e) { ShowPage(tabRecycling, btnNavRecycling); }
        private void btnNavComplaints_Click(object sender, EventArgs e) { ShowPage(tabComplaints, btnNavComplaints); }
        private void btnNavReports_Click(object sender, EventArgs e) { ShowPage(tabReports, btnNavReports); }

        private void ShowPage(TabPage page, Button menuButton)
        {
            tabMain.SelectedTab = page;
            Theme.HighlightMenu(pnlSidebar, menuButton);
        }

        private void tabMain_SelectedIndexChanged(object sender, EventArgs e)
        {
            RefreshAll();
        }

        private void btnSignOut_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void RefreshAll()
        {
            RefreshDashboard();
            ShowResidents("");
            RefreshCollections();
            RefreshFleet();
            RefreshRecycling();
            RefreshComplaints();
        }

        // ================= DASHBOARD =================

        private void RefreshDashboard()
        {
            List<WasteCollection> today = new List<WasteCollection>();
            foreach (WasteCollection c in DataStore.Collections)
                if (c.Date == DateTime.Today && c.Status != CollectionStatus.Cancelled) today.Add(c);

            int openComplaints = 0;
            foreach (Complaint c in DataStore.Complaints)
                if (c.Status != ComplaintStatus.Resolved) openComplaints++;

            int pending = 0;
            foreach (RecyclingRequest r in DataStore.RecyclingRequests)
                if (r.Status == RequestStatus.Pending) pending++;

            int available = 0;
            foreach (Vehicle v in DataStore.Vehicles)
                if (v.Status == VehicleStatus.Available) available++;

            lblKpi1Value.Text = today.Count.ToString();
            lblKpi2Value.Text = openComplaints.ToString();
            lblKpi3Value.Text = pending.ToString();
            lblKpi4Value.Text = $"{available} / {DataStore.Vehicles.Count}";

            Theme.ShowList(dgvToday, today, "Notes", "RequestId");
            pnlChart.Invalidate();   // redraw the chart
        }

        // Bar chart of completed collections for the last 6 months, drawn with simple rectangles
        private void pnlChart_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            int[] counts = new int[6];
            string[] months = new string[6];

            for (int i = 0; i < 6; i++)
            {
                DateTime month = DateTime.Today.AddMonths(i - 5);
                months[i] = month.ToString("MMM");
                foreach (WasteCollection c in DataStore.Collections)
                {
                    if (c.Status == CollectionStatus.Completed && c.Date.Month == month.Month && c.Date.Year == month.Year)
                        counts[i]++;
                }
            }

            int max = 1;
            foreach (int count in counts)
                if (count > max) max = count;

            using (Font titleFont = new Font("Segoe UI", 12F, FontStyle.Bold))
            using (Font font = new Font("Segoe UI", 10F))
            using (SolidBrush barBrush = new SolidBrush(Theme.Forest))
            {
                g.DrawString("Completed collections per month", titleFont, Brushes.Black, 16, 12);

                int top = 60;
                int height = pnlChart.Height - top - 40;
                int slot = (pnlChart.Width - 40) / 6;
                int barWidth = slot / 2;

                for (int i = 0; i < 6; i++)
                {
                    int barHeight = counts[i] * height / max;
                    int x = 20 + i * slot + (slot - barWidth) / 2;
                    int y = top + height - barHeight;
                    g.FillRectangle(barBrush, x, y, barWidth, barHeight);
                    g.DrawString(counts[i].ToString(), font, Brushes.Black, x + barWidth / 2 - 8, y - 22);
                    g.DrawString(months[i], font, Brushes.Gray, x + barWidth / 2 - 14, top + height + 8);
                }
            }
        }

        // ================= RESIDENTS =================

        private void ShowResidents(string search)
        {
            string text = search.Trim().ToLower();
            List<Resident> found = new List<Resident>();
            foreach (Resident r in DataStore.Residents())
            {
                if (text == "" || r.FullName.ToLower().Contains(text) || r.Username.ToLower().Contains(text) || r.Email.ToLower().Contains(text))
                    found.Add(r);
            }
            Theme.ShowList(dgvResidents, found, "Password");
            if (text != "" && found.Count == 0) Theme.ShowInfo("No residents match your search.");
        }

        private void btnSearchResident_Click(object sender, EventArgs e) { ShowResidents(txtSearchResident.Text); }

        private void btnShowAllResidents_Click(object sender, EventArgs e)
        {
            txtSearchResident.Clear();
            ShowResidents("");
        }

        private void dgvResidents_SelectionChanged(object sender, EventArgs e)
        {
            lstResidentAddresses.Items.Clear();
            if (dgvResidents.CurrentRow == null) return;
            Resident selected = (Resident)dgvResidents.CurrentRow.DataBoundItem;
            foreach (Address a in DataStore.AddressesOf(selected.Username))
                lstResidentAddresses.Items.Add(a);
        }

        // ================= COLLECTIONS =================

        private void RefreshCollections()
        {
            // Filter by status and search text
            string search = txtSearchCollection.Text.Trim().ToLower();
            List<WasteCollection> list = new List<WasteCollection>();
            foreach (WasteCollection c in DataStore.Collections)
            {
                bool statusOk = cboStatusFilter.Text == "All" || cboStatusFilter.Text == "" || c.Status.ToString() == cboStatusFilter.Text;
                bool searchOk = search == "" || c.Id.ToLower().Contains(search) || c.ResidentUsername.ToLower().Contains(search) || c.Address.ToLower().Contains(search);
                if (statusOk && searchOk) list.Add(c);
            }
            Theme.ShowList(dgvCollections, list, "RequestId");

            // Combo boxes for scheduling and assigning
            cboSchResident.DisplayMember = "FullName";   // show the name, not the class name
            if (cboSchResident.Items.Count != DataStore.Residents().Count)
                cboSchResident.DataSource = DataStore.Residents();
            cboDriver.DataSource = DataStore.StaffMembers();
            cboVehicle.DataSource = new List<Vehicle>(DataStore.Vehicles);
        }

        private void cboStatusFilter_SelectedIndexChanged(object sender, EventArgs e) { RefreshCollections(); }
        private void txtSearchCollection_TextChanged(object sender, EventArgs e) { RefreshCollections(); }

        private void cboSchResident_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboSchResident.SelectedItem is Resident resident)
                cboSchAddress.DataSource = DataStore.AddressesOf(resident.Username);
        }

        private void btnSchedule_Click(object sender, EventArgs e)
        {
            if (!(cboSchResident.SelectedItem is Resident resident)) { Theme.ShowError("Choose a resident."); return; }
            try
            {
                string id = DataStore.NextId("WC", DataStore.Collections.Count);
                WasteCollection c = new WasteCollection(id, resident.Username, cboSchAddress.Text, cboSchType.Text, dtpSchDate.Value, "");
                DataStore.Collections.Add(c);
                DataStore.SaveAll();
                RefreshAll();
                Theme.ShowInfo($"{id} scheduled. Select it in the list to assign a driver and vehicle.");
            }
            catch (ArgumentException ex)
            {
                Theme.ShowError(ex.Message);
            }
        }

        private void btnAssign_Click(object sender, EventArgs e)
        {
            if (dgvCollections.CurrentRow == null) { Theme.ShowError("Select a collection in the list first."); return; }
            WasteCollection selected = (WasteCollection)dgvCollections.CurrentRow.DataBoundItem;
            StaffMember driver = cboDriver.SelectedItem as StaffMember;
            Vehicle vehicle = cboVehicle.SelectedItem as Vehicle;

            try
            {
                selected.Assign(driver, vehicle);   // the class checks duty, maintenance and status
                DataStore.SaveAll();
                RefreshAll();
            }
            catch (Exception ex)
            {
                Theme.ShowError(ex.Message);
            }
        }

        private void btnCancelSelectedCollection_Click(object sender, EventArgs e)
        {
            if (dgvCollections.CurrentRow == null) { Theme.ShowError("Select a collection in the list first."); return; }
            WasteCollection selected = (WasteCollection)dgvCollections.CurrentRow.DataBoundItem;
            try
            {
                selected.Cancel();
                DataStore.SaveAll();
                RefreshAll();
            }
            catch (InvalidOperationException ex)
            {
                Theme.ShowError(ex.Message);
            }
        }

        // Opens a map showing where the driver is going: all of that driver's stops for the day,
        // with the current stop highlighted. The driver comes from the selected collection
        // (or, if it has no driver yet, from the Driver box above).
        private void btnTrackDriver_Click(object sender, EventArgs e)
        {
            WasteCollection selected = null;
            if (dgvCollections.CurrentRow != null)
                selected = (WasteCollection)dgvCollections.CurrentRow.DataBoundItem;

            StaffMember driver = null;
            DateTime day = DateTime.Today;
            if (selected != null)
            {
                day = selected.Date;
                if (selected.DriverUsername != "")
                    driver = DataStore.FindUser(selected.DriverUsername) as StaffMember;
            }
            if (driver == null) driver = cboDriver.SelectedItem as StaffMember;
            if (driver == null) { Theme.ShowError("Select a collection that has a driver, or choose a driver first."); return; }

            List<WasteCollection> stops = new List<WasteCollection>();
            foreach (WasteCollection c in DataStore.Collections)
            {
                if (c.DriverUsername == driver.Username && c.Date == day && c.Status != CollectionStatus.Cancelled)
                    stops.Add(c);
            }
            if (stops.Count == 0)
            {
                Theme.ShowInfo($"{driver.FullName} has no collections on {day:dd MMM yyyy}.");
                return;
            }

            using (DriverMapForm map = new DriverMapForm(driver, day, stops))
            {
                map.ShowDialog(this);
            }
        }

        // ================= VEHICLES & STAFF =================

        private void RefreshFleet()
        {
            Theme.ShowList(dgvVehicles, new List<Vehicle>(DataStore.Vehicles));
            Theme.ShowList(dgvStaff, DataStore.StaffMembers(), "Password");
            cboStaffVehicle.DataSource = new List<Vehicle>(DataStore.Vehicles);
        }

        private void btnAddVehicle_Click(object sender, EventArgs e)
        {
            try
            {
                if (DataStore.FindVehicle(txtRegistration.Text.Trim().ToUpper()) != null)
                    throw new ArgumentException("A vehicle with this registration already exists.");
                if (cboVehicleType.SelectedIndex == -1)
                    throw new ArgumentException("Choose the vehicle type.");

                Vehicle vehicle = new Vehicle(txtRegistration.Text, cboVehicleType.Text, (int)nudCapacity.Value);
                DataStore.Vehicles.Add(vehicle);
                DataStore.SaveAll();
                txtRegistration.Clear();
                RefreshAll();
            }
            catch (ArgumentException ex)
            {
                Theme.ShowError(ex.Message);
            }
        }

        private Vehicle SelectedVehicle()
        {
            if (dgvVehicles.CurrentRow == null) return null;
            return (Vehicle)dgvVehicles.CurrentRow.DataBoundItem;
        }

        private void btnMaintenance_Click(object sender, EventArgs e)
        {
            Vehicle vehicle = SelectedVehicle();
            if (vehicle == null) { Theme.ShowError("Select a vehicle first."); return; }
            vehicle.SendToMaintenance();
            DataStore.SaveAll();
            RefreshAll();
        }

        private void btnAvailable_Click(object sender, EventArgs e)
        {
            Vehicle vehicle = SelectedVehicle();
            if (vehicle == null) { Theme.ShowError("Select a vehicle first."); return; }
            vehicle.MakeAvailable();
            DataStore.SaveAll();
            RefreshAll();
        }

        private void btnAddStaff_Click(object sender, EventArgs e)
        {
            try
            {
                if (!Validator.IsValidUsername(txtStaffUsername.Text))
                    throw new ArgumentException("Username must be 3 to 30 letters or numbers.");
                if (DataStore.FindUser(txtStaffUsername.Text) != null)
                    throw new ArgumentException("That username is already taken.");
                if (string.IsNullOrWhiteSpace(txtStaffName.Text))
                    throw new ArgumentException("Enter the staff member's name.");

                StaffMember staff = new StaffMember(txtStaffUsername.Text, txtStaffName.Text.Trim(), "", "", AccountManager.StaffPassword, true);
                DataStore.Users.Add(staff);
                DataStore.SaveAll();
                txtStaffName.Clear();
                txtStaffUsername.Clear();
                RefreshAll();
            }
            catch (ArgumentException ex)
            {
                Theme.ShowError(ex.Message);
            }
        }

        private StaffMember SelectedStaff()
        {
            if (dgvStaff.CurrentRow == null) return null;
            return (StaffMember)dgvStaff.CurrentRow.DataBoundItem;
        }

        private void btnGiveVehicle_Click(object sender, EventArgs e)
        {
            StaffMember staff = SelectedStaff();
            if (staff == null || !(cboStaffVehicle.SelectedItem is Vehicle vehicle)) { Theme.ShowError("Select a staff member and a vehicle."); return; }

            // A vehicle has one usual driver: take it away from anyone else first
            foreach (Vehicle v in DataStore.Vehicles)
                if (v.DriverUsername == staff.Username) v.DriverUsername = "";
            vehicle.DriverUsername = staff.Username;

            DataStore.SaveAll();
            RefreshAll();
        }

        private void btnToggleDuty_Click(object sender, EventArgs e)
        {
            StaffMember staff = SelectedStaff();
            if (staff == null) { Theme.ShowError("Select a staff member first."); return; }
            staff.IsOnDuty = !staff.IsOnDuty;
            DataStore.SaveAll();
            RefreshAll();
        }

        // ================= RECYCLING =================

        private void RefreshRecycling()
        {
            List<RecyclingRequest> list = new List<RecyclingRequest>();
            foreach (RecyclingRequest r in DataStore.RecyclingRequests)
            {
                if (cboRecFilter.Text == "All" || cboRecFilter.Text == "" || r.Status.ToString() == cboRecFilter.Text)
                    list.Add(r);
            }
            Theme.ShowList(dgvRecycling, list);
        }

        private void cboRecFilter_SelectedIndexChanged(object sender, EventArgs e) { RefreshRecycling(); }

        private RecyclingRequest SelectedRequest()
        {
            if (dgvRecycling.CurrentRow == null) return null;
            return (RecyclingRequest)dgvRecycling.CurrentRow.DataBoundItem;
        }

        // Approving creates a "Recycling" collection that can then be assigned like any other
        private void btnApprove_Click(object sender, EventArgs e)
        {
            RecyclingRequest request = SelectedRequest();
            if (request == null) { Theme.ShowError("Select a request first."); return; }

            try
            {
                if (request.Status != RequestStatus.Pending)
                    throw new InvalidOperationException("Only pending requests can be approved.");

                string id = DataStore.NextId("WC", DataStore.Collections.Count);
                DateTime date = request.PreferredDate < DateTime.Today ? DateTime.Today : request.PreferredDate;
                WasteCollection c = new WasteCollection(id, request.ResidentUsername, request.Address, "Recycling", date,
                                                        $"{request.Bags} bag(s) of {request.Category}");
                c.RequestId = request.Id;
                request.Approve(id);
                DataStore.Collections.Add(c);
                DataStore.SaveAll();
                RefreshAll();
                Theme.ShowInfo($"Approved. Collection {id} was scheduled. Assign a driver on the Collections page.");
            }
            catch (Exception ex)
            {
                Theme.ShowError(ex.Message);
            }
        }

        private void btnReject_Click(object sender, EventArgs e)
        {
            RecyclingRequest request = SelectedRequest();
            if (request == null) { Theme.ShowError("Select a request first."); return; }
            try
            {
                request.Reject(txtRejectReason.Text);
                DataStore.SaveAll();
                txtRejectReason.Clear();
                RefreshAll();
            }
            catch (Exception ex)
            {
                Theme.ShowError(ex.Message);
            }
        }

        // ================= COMPLAINTS =================

        private void RefreshComplaints()
        {
            List<Complaint> list = new List<Complaint>();
            foreach (Complaint c in DataStore.Complaints)
            {
                string filter = cboCompFilter.Text;
                bool show = filter == "All" || filter == ""
                            || (filter == "Open" && c.Status != ComplaintStatus.Resolved)
                            || c.Status.ToString() == filter;
                if (show) list.Add(c);
            }
            Theme.ShowList(dgvComplaints, list, "Description", "Response");
        }

        private void cboCompFilter_SelectedIndexChanged(object sender, EventArgs e) { RefreshComplaints(); }

        private Complaint SelectedComplaint()
        {
            if (dgvComplaints.CurrentRow == null) return null;
            return (Complaint)dgvComplaints.CurrentRow.DataBoundItem;
        }

        private void dgvComplaints_SelectionChanged(object sender, EventArgs e)
        {
            Complaint c = SelectedComplaint();
            if (c == null) { txtCompDetails.Text = ""; return; }

            User resident = DataStore.FindUser(c.ResidentUsername);
            string name = resident == null ? c.ResidentUsername : resident.FullName;
            txtCompDetails.Text = $"{c.Id} - {c.ComplaintType}\r\nFrom: {name}\r\nDate: {c.DateReported:dd MMM yyyy}\r\n" +
                                  (c.CollectionId != "" ? $"Collection: {c.CollectionId}\r\n" : "") +
                                  $"\r\n{c.Description}\r\n\r\nStatus: {c.Status}";
            txtReply.Text = c.Response;
        }

        private void btnStartReview_Click(object sender, EventArgs e)
        {
            Complaint c = SelectedComplaint();
            if (c == null) { Theme.ShowError("Select a complaint first."); return; }
            try
            {
                c.StartReview();
                DataStore.SaveAll();
                RefreshAll();
            }
            catch (InvalidOperationException ex)
            {
                Theme.ShowError(ex.Message);
            }
        }

        private void btnResolve_Click(object sender, EventArgs e)
        {
            Complaint c = SelectedComplaint();
            if (c == null) { Theme.ShowError("Select a complaint first."); return; }
            try
            {
                c.Resolve(txtReply.Text);
                DataStore.SaveAll();
                txtReply.Clear();
                RefreshAll();
            }
            catch (Exception ex)
            {
                Theme.ShowError(ex.Message);
            }
        }

        // ================= REPORTS =================

        private void btnRunReport_Click(object sender, EventArgs e)
        {
            DateTime day = dtpReportDate.Value.Date;
            string report = "SMART WASTE - " + cboReportType.Text.ToUpper() + "\r\n";
            report += "Created " + DateTime.Now.ToString("dd MMM yyyy HH:mm") + "\r\n\r\n";

            if (cboReportType.SelectedIndex == 0)        // Daily collection report
            {
                report += "Date: " + day.ToString("dd MMM yyyy") + "\r\n\r\n";
                report += "ID".PadRight(10) + "Resident".PadRight(14) + "Type".PadRight(18) + "Driver".PadRight(14) + "Status\r\n";
                int count = 0;
                foreach (WasteCollection c in DataStore.Collections)
                {
                    if (c.Date != day) continue;
                    report += c.Id.PadRight(10) + c.ResidentUsername.PadRight(14) + c.CollectionType.PadRight(18) + c.DriverUsername.PadRight(14) + c.Status + "\r\n";
                    count++;
                }
                report += $"\r\nTotal: {count} collection(s)";
            }
            else if (cboReportType.SelectedIndex == 1)   // Missed collections
            {
                int missed = 0, finished = 0;
                foreach (WasteCollection c in DataStore.Collections)
                {
                    if (c.Status == CollectionStatus.Completed) finished++;
                    if (c.Status != CollectionStatus.Missed) continue;
                    missed++;
                    finished++;
                    report += $"{c.Date:dd MMM}  {c.Id}  {c.Address}  ({c.DriverUsername})  {c.Notes}\r\n";
                }
                report += $"\r\n{missed} missed out of {finished} finished collections.";
            }
            else if (cboReportType.SelectedIndex == 2)   // Recycling statistics
            {
                string[] categories = { "Plastic", "Glass", "Paper", "Metal" };
                report += "Category".PadRight(12) + "Requests".PadRight(10) + "Bags".PadRight(8) + "Collected\r\n";
                foreach (string category in categories)
                {
                    int requests = 0, bags = 0, collected = 0;
                    foreach (RecyclingRequest r in DataStore.RecyclingRequests)
                    {
                        if (r.Category != category || r.Status == RequestStatus.Rejected) continue;
                        requests++;
                        bags += r.Bags;
                        if (r.Status == RequestStatus.Collected) collected++;
                    }
                    report += category.PadRight(12) + requests.ToString().PadRight(10) + bags.ToString().PadRight(8) + collected + "\r\n";
                }
            }
            else                                          // Vehicle usage
            {
                report += "Vehicle".PadRight(14) + "Status".PadRight(14) + "Jobs".PadRight(8) + "Completed\r\n";
                foreach (Vehicle v in DataStore.Vehicles)
                {
                    int jobs = 0, completed = 0;
                    foreach (WasteCollection c in DataStore.Collections)
                    {
                        if (c.VehicleRegistration != v.Registration) continue;
                        jobs++;
                        if (c.Status == CollectionStatus.Completed) completed++;
                    }
                    report += v.Registration.PadRight(14) + v.Status.ToString().PadRight(14) + jobs.ToString().PadRight(8) + completed + "\r\n";
                }
            }

            _lastReport = report;
            txtReport.Text = report;
        }

        private void btnExportReport_Click(object sender, EventArgs e)
        {
            if (_lastReport == "") { Theme.ShowError("Run a report first."); return; }

            string fileName = "report_" + DateTime.Now.ToString("yyyy-MM-dd_HHmm") + ".txt";
            try
            {
                File.WriteAllText(fileName, _lastReport);
                Theme.ShowInfo("Saved as " + Path.GetFullPath(fileName));
            }
            catch (IOException ex)
            {
                Theme.ShowError("Could not save the report: " + ex.Message);
            }
        }
    }
}
