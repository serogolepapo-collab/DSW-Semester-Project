namespace DSW_Semester_Project
{
    partial class AdminForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabMain = new TabControl();
            pnlSidebar = new Panel();
            picLogo = new PictureBox();
            lblAppName = new Label();
            lblRole = new Label();
            btnNavDashboard = new Button();
            btnNavResidents = new Button();
            btnNavCollections = new Button();
            btnNavFleet = new Button();
            btnNavRecycling = new Button();
            btnNavComplaints = new Button();
            btnNavReports = new Button();
            lblHello = new Label();
            btnSignOut = new Button();
            tabDashboard = new TabPage();
            tabResidents = new TabPage();
            tabCollections = new TabPage();
            tabFleet = new TabPage();
            tabRecycling = new TabPage();
            tabComplaints = new TabPage();
            tabReports = new TabPage();
            lblDashTitle = new Label();
            lblDashDate = new Label();
            pnlKpi1 = new Panel();
            lblKpi1Title = new Label();
            lblKpi1Value = new Label();
            pnlKpi2 = new Panel();
            lblKpi2Title = new Label();
            lblKpi2Value = new Label();
            pnlKpi3 = new Panel();
            lblKpi3Title = new Label();
            lblKpi3Value = new Label();
            pnlKpi4 = new Panel();
            lblKpi4Title = new Label();
            lblKpi4Value = new Label();
            pnlChart = new Panel();
            lblTodayTitle = new Label();
            dgvToday = new DataGridView();
            lblResidentsTitle = new Label();
            txtSearchResident = new TextBox();
            btnSearchResident = new Button();
            btnShowAllResidents = new Button();
            dgvResidents = new DataGridView();
            lblResidentAddressesTitle = new Label();
            lstResidentAddresses = new ListBox();
            lblCollectionsTitle = new Label();
            pnlSchedule = new Panel();
            lblScheduleHeading = new Label();
            lblSchResident = new Label();
            cboSchResident = new ComboBox();
            lblSchAddress = new Label();
            cboSchAddress = new ComboBox();
            lblSchType = new Label();
            cboSchType = new ComboBox();
            lblSchDate = new Label();
            dtpSchDate = new DateTimePicker();
            btnSchedule = new Button();
            pnlAssign = new Panel();
            lblAssignHeading = new Label();
            lblDriver = new Label();
            cboDriver = new ComboBox();
            lblVehicle = new Label();
            cboVehicle = new ComboBox();
            btnAssign = new Button();
            btnCancelSelectedCollection = new Button();
            btnTrackDriver = new Button();
            lblStatusFilter = new Label();
            cboStatusFilter = new ComboBox();
            txtSearchCollection = new TextBox();
            dgvCollections = new DataGridView();
            lblFleetTitle = new Label();
            pnlAddVehicle = new Panel();
            lblAddVehicleHeading = new Label();
            lblRegistration = new Label();
            txtRegistration = new TextBox();
            lblVehicleType = new Label();
            cboVehicleType = new ComboBox();
            lblCapacity = new Label();
            nudCapacity = new NumericUpDown();
            btnAddVehicle = new Button();
            dgvVehicles = new DataGridView();
            btnMaintenance = new Button();
            btnAvailable = new Button();
            pnlAddStaff = new Panel();
            lblAddStaffHeading = new Label();
            lblStaffName = new Label();
            txtStaffName = new TextBox();
            lblStaffUsername = new Label();
            txtStaffUsername = new TextBox();
            lblStaffPasswordNote = new Label();
            btnAddStaff = new Button();
            lblStaffTitle = new Label();
            dgvStaff = new DataGridView();
            lblStaffVehicle = new Label();
            cboStaffVehicle = new ComboBox();
            btnGiveVehicle = new Button();
            btnToggleDuty = new Button();
            lblRecyclingTitle = new Label();
            lblRecFilter = new Label();
            cboRecFilter = new ComboBox();
            dgvRecycling = new DataGridView();
            btnApprove = new Button();
            lblRejectReason = new Label();
            txtRejectReason = new TextBox();
            btnReject = new Button();
            lblComplaintsTitle = new Label();
            lblCompFilter = new Label();
            cboCompFilter = new ComboBox();
            dgvComplaints = new DataGridView();
            pnlCompDetail = new Panel();
            lblCompDetailHeading = new Label();
            txtCompDetails = new TextBox();
            btnStartReview = new Button();
            lblReply = new Label();
            txtReply = new TextBox();
            btnResolve = new Button();
            lblReportsTitle = new Label();
            cboReportType = new ComboBox();
            dtpReportDate = new DateTimePicker();
            btnRunReport = new Button();
            btnExportReport = new Button();
            txtReport = new TextBox();
            tabMain.SuspendLayout();
            pnlSidebar.SuspendLayout();
            tabDashboard.SuspendLayout();
            tabResidents.SuspendLayout();
            tabCollections.SuspendLayout();
            tabFleet.SuspendLayout();
            tabRecycling.SuspendLayout();
            tabComplaints.SuspendLayout();
            tabReports.SuspendLayout();
            pnlKpi1.SuspendLayout();
            pnlKpi2.SuspendLayout();
            pnlKpi3.SuspendLayout();
            pnlKpi4.SuspendLayout();
            pnlChart.SuspendLayout();
            pnlSchedule.SuspendLayout();
            pnlAssign.SuspendLayout();
            pnlAddVehicle.SuspendLayout();
            pnlAddStaff.SuspendLayout();
            pnlCompDetail.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)picLogo).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvToday).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvResidents).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvCollections).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudCapacity).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvVehicles).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvStaff).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvRecycling).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvComplaints).BeginInit();
            SuspendLayout();
            // 
            // tabMain
            // 
            tabMain.Controls.Add(tabDashboard);
            tabMain.Controls.Add(tabResidents);
            tabMain.Controls.Add(tabCollections);
            tabMain.Controls.Add(tabFleet);
            tabMain.Controls.Add(tabRecycling);
            tabMain.Controls.Add(tabComplaints);
            tabMain.Controls.Add(tabReports);
            tabMain.Dock = DockStyle.Fill;
            tabMain.Font = new Font("Segoe UI", 10F);
            tabMain.Name = "tabMain";
            tabMain.SelectedIndex = 0;
            tabMain.TabIndex = 0;
            tabMain.SelectedIndexChanged += tabMain_SelectedIndexChanged;
            // 
            // pnlSidebar
            // 
            pnlSidebar.Controls.Add(picLogo);
            pnlSidebar.Controls.Add(lblAppName);
            pnlSidebar.Controls.Add(lblRole);
            pnlSidebar.Controls.Add(btnNavDashboard);
            pnlSidebar.Controls.Add(btnNavResidents);
            pnlSidebar.Controls.Add(btnNavCollections);
            pnlSidebar.Controls.Add(btnNavFleet);
            pnlSidebar.Controls.Add(btnNavRecycling);
            pnlSidebar.Controls.Add(btnNavComplaints);
            pnlSidebar.Controls.Add(btnNavReports);
            pnlSidebar.Controls.Add(lblHello);
            pnlSidebar.Controls.Add(btnSignOut);
            pnlSidebar.BackColor = Color.FromArgb(18, 53, 36);
            pnlSidebar.Dock = DockStyle.Left;
            pnlSidebar.Name = "pnlSidebar";
            pnlSidebar.Size = new Size(230, 760);
            pnlSidebar.TabIndex = 1;
            // 
            // picLogo
            // 
            picLogo.Image = Properties.Resources.logo_white;
            picLogo.Location = new Point(20, 22);
            picLogo.Name = "picLogo";
            picLogo.Size = new Size(46, 52);
            picLogo.SizeMode = PictureBoxSizeMode.Zoom;
            picLogo.TabIndex = 0;
            picLogo.TabStop = false;
            // 
            // lblAppName
            // 
            lblAppName.AutoSize = true;
            lblAppName.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            lblAppName.ForeColor = Color.White;
            lblAppName.Location = new Point(72, 24);
            lblAppName.Name = "lblAppName";
            lblAppName.TabIndex = 1;
            lblAppName.Text = "Smart Waste";
            // 
            // lblRole
            // 
            lblRole.AutoSize = true;
            lblRole.Font = new Font("Segoe UI", 9.5F);
            lblRole.ForeColor = Color.FromArgb(158, 208, 174);
            lblRole.Location = new Point(74, 54);
            lblRole.Name = "lblRole";
            lblRole.TabIndex = 2;
            lblRole.Text = "Administration";
            // 
            // btnNavDashboard
            // 
            btnNavDashboard.BackColor = Color.FromArgb(18, 53, 36);
            btnNavDashboard.Cursor = Cursors.Hand;
            btnNavDashboard.FlatAppearance.BorderSize = 0;
            btnNavDashboard.FlatAppearance.MouseOverBackColor = Color.FromArgb(30, 90, 60);
            btnNavDashboard.FlatStyle = FlatStyle.Flat;
            btnNavDashboard.Font = new Font("Segoe UI", 11F);
            btnNavDashboard.ForeColor = Color.White;
            btnNavDashboard.Location = new Point(0, 120);
            btnNavDashboard.Name = "btnNavDashboard";
            btnNavDashboard.Padding = new Padding(24, 0, 0, 0);
            btnNavDashboard.Size = new Size(230, 46);
            btnNavDashboard.TabIndex = 3;
            btnNavDashboard.Text = "Dashboard";
            btnNavDashboard.TextAlign = ContentAlignment.MiddleLeft;
            btnNavDashboard.UseVisualStyleBackColor = false;
            btnNavDashboard.Click += btnNavDashboard_Click;
            // 
            // btnNavResidents
            // 
            btnNavResidents.BackColor = Color.FromArgb(18, 53, 36);
            btnNavResidents.Cursor = Cursors.Hand;
            btnNavResidents.FlatAppearance.BorderSize = 0;
            btnNavResidents.FlatAppearance.MouseOverBackColor = Color.FromArgb(30, 90, 60);
            btnNavResidents.FlatStyle = FlatStyle.Flat;
            btnNavResidents.Font = new Font("Segoe UI", 11F);
            btnNavResidents.ForeColor = Color.White;
            btnNavResidents.Location = new Point(0, 170);
            btnNavResidents.Name = "btnNavResidents";
            btnNavResidents.Padding = new Padding(24, 0, 0, 0);
            btnNavResidents.Size = new Size(230, 46);
            btnNavResidents.TabIndex = 4;
            btnNavResidents.Text = "Residents";
            btnNavResidents.TextAlign = ContentAlignment.MiddleLeft;
            btnNavResidents.UseVisualStyleBackColor = false;
            btnNavResidents.Click += btnNavResidents_Click;
            // 
            // btnNavCollections
            // 
            btnNavCollections.BackColor = Color.FromArgb(18, 53, 36);
            btnNavCollections.Cursor = Cursors.Hand;
            btnNavCollections.FlatAppearance.BorderSize = 0;
            btnNavCollections.FlatAppearance.MouseOverBackColor = Color.FromArgb(30, 90, 60);
            btnNavCollections.FlatStyle = FlatStyle.Flat;
            btnNavCollections.Font = new Font("Segoe UI", 11F);
            btnNavCollections.ForeColor = Color.White;
            btnNavCollections.Location = new Point(0, 220);
            btnNavCollections.Name = "btnNavCollections";
            btnNavCollections.Padding = new Padding(24, 0, 0, 0);
            btnNavCollections.Size = new Size(230, 46);
            btnNavCollections.TabIndex = 5;
            btnNavCollections.Text = "Collections";
            btnNavCollections.TextAlign = ContentAlignment.MiddleLeft;
            btnNavCollections.UseVisualStyleBackColor = false;
            btnNavCollections.Click += btnNavCollections_Click;
            // 
            // btnNavFleet
            // 
            btnNavFleet.BackColor = Color.FromArgb(18, 53, 36);
            btnNavFleet.Cursor = Cursors.Hand;
            btnNavFleet.FlatAppearance.BorderSize = 0;
            btnNavFleet.FlatAppearance.MouseOverBackColor = Color.FromArgb(30, 90, 60);
            btnNavFleet.FlatStyle = FlatStyle.Flat;
            btnNavFleet.Font = new Font("Segoe UI", 11F);
            btnNavFleet.ForeColor = Color.White;
            btnNavFleet.Location = new Point(0, 270);
            btnNavFleet.Name = "btnNavFleet";
            btnNavFleet.Padding = new Padding(24, 0, 0, 0);
            btnNavFleet.Size = new Size(230, 46);
            btnNavFleet.TabIndex = 6;
            btnNavFleet.Text = "Vehicles && staff";
            btnNavFleet.TextAlign = ContentAlignment.MiddleLeft;
            btnNavFleet.UseVisualStyleBackColor = false;
            btnNavFleet.Click += btnNavFleet_Click;
            // 
            // btnNavRecycling
            // 
            btnNavRecycling.BackColor = Color.FromArgb(18, 53, 36);
            btnNavRecycling.Cursor = Cursors.Hand;
            btnNavRecycling.FlatAppearance.BorderSize = 0;
            btnNavRecycling.FlatAppearance.MouseOverBackColor = Color.FromArgb(30, 90, 60);
            btnNavRecycling.FlatStyle = FlatStyle.Flat;
            btnNavRecycling.Font = new Font("Segoe UI", 11F);
            btnNavRecycling.ForeColor = Color.White;
            btnNavRecycling.Location = new Point(0, 320);
            btnNavRecycling.Name = "btnNavRecycling";
            btnNavRecycling.Padding = new Padding(24, 0, 0, 0);
            btnNavRecycling.Size = new Size(230, 46);
            btnNavRecycling.TabIndex = 7;
            btnNavRecycling.Text = "Recycling";
            btnNavRecycling.TextAlign = ContentAlignment.MiddleLeft;
            btnNavRecycling.UseVisualStyleBackColor = false;
            btnNavRecycling.Click += btnNavRecycling_Click;
            // 
            // btnNavComplaints
            // 
            btnNavComplaints.BackColor = Color.FromArgb(18, 53, 36);
            btnNavComplaints.Cursor = Cursors.Hand;
            btnNavComplaints.FlatAppearance.BorderSize = 0;
            btnNavComplaints.FlatAppearance.MouseOverBackColor = Color.FromArgb(30, 90, 60);
            btnNavComplaints.FlatStyle = FlatStyle.Flat;
            btnNavComplaints.Font = new Font("Segoe UI", 11F);
            btnNavComplaints.ForeColor = Color.White;
            btnNavComplaints.Location = new Point(0, 370);
            btnNavComplaints.Name = "btnNavComplaints";
            btnNavComplaints.Padding = new Padding(24, 0, 0, 0);
            btnNavComplaints.Size = new Size(230, 46);
            btnNavComplaints.TabIndex = 8;
            btnNavComplaints.Text = "Complaints";
            btnNavComplaints.TextAlign = ContentAlignment.MiddleLeft;
            btnNavComplaints.UseVisualStyleBackColor = false;
            btnNavComplaints.Click += btnNavComplaints_Click;
            // 
            // btnNavReports
            // 
            btnNavReports.BackColor = Color.FromArgb(18, 53, 36);
            btnNavReports.Cursor = Cursors.Hand;
            btnNavReports.FlatAppearance.BorderSize = 0;
            btnNavReports.FlatAppearance.MouseOverBackColor = Color.FromArgb(30, 90, 60);
            btnNavReports.FlatStyle = FlatStyle.Flat;
            btnNavReports.Font = new Font("Segoe UI", 11F);
            btnNavReports.ForeColor = Color.White;
            btnNavReports.Location = new Point(0, 420);
            btnNavReports.Name = "btnNavReports";
            btnNavReports.Padding = new Padding(24, 0, 0, 0);
            btnNavReports.Size = new Size(230, 46);
            btnNavReports.TabIndex = 9;
            btnNavReports.Text = "Reports";
            btnNavReports.TextAlign = ContentAlignment.MiddleLeft;
            btnNavReports.UseVisualStyleBackColor = false;
            btnNavReports.Click += btnNavReports_Click;
            // 
            // lblHello
            // 
            lblHello.AutoSize = true;
            lblHello.Font = new Font("Segoe UI", 10F);
            lblHello.ForeColor = Color.White;
            lblHello.Location = new Point(22, 646);
            lblHello.Name = "lblHello";
            lblHello.TabIndex = 10;
            lblHello.Text = "Hello, name";
            // 
            // btnSignOut
            // 
            btnSignOut.BackColor = Color.FromArgb(18, 53, 36);
            btnSignOut.Cursor = Cursors.Hand;
            btnSignOut.FlatAppearance.BorderColor = Color.FromArgb(158, 208, 174);
            btnSignOut.FlatStyle = FlatStyle.Flat;
            btnSignOut.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnSignOut.ForeColor = Color.White;
            btnSignOut.Location = new Point(22, 680);
            btnSignOut.Name = "btnSignOut";
            btnSignOut.Size = new Size(186, 40);
            btnSignOut.TabIndex = 11;
            btnSignOut.Text = "Sign out";
            btnSignOut.UseVisualStyleBackColor = false;
            btnSignOut.Click += btnSignOut_Click;
            // 
            // tabDashboard
            // 
            tabDashboard.Controls.Add(lblDashTitle);
            tabDashboard.Controls.Add(lblDashDate);
            tabDashboard.Controls.Add(pnlKpi1);
            tabDashboard.Controls.Add(pnlKpi2);
            tabDashboard.Controls.Add(pnlKpi3);
            tabDashboard.Controls.Add(pnlKpi4);
            tabDashboard.Controls.Add(pnlChart);
            tabDashboard.Controls.Add(lblTodayTitle);
            tabDashboard.Controls.Add(dgvToday);
            tabDashboard.BackColor = Color.FromArgb(243, 244, 239);
            tabDashboard.Location = new Point(4, 32);
            tabDashboard.Name = "tabDashboard";
            tabDashboard.Padding = new Padding(3);
            tabDashboard.Size = new Size(1042, 724);
            tabDashboard.Text = "Dashboard";
            // 
            // tabResidents
            // 
            tabResidents.Controls.Add(lblResidentsTitle);
            tabResidents.Controls.Add(txtSearchResident);
            tabResidents.Controls.Add(btnSearchResident);
            tabResidents.Controls.Add(btnShowAllResidents);
            tabResidents.Controls.Add(dgvResidents);
            tabResidents.Controls.Add(lblResidentAddressesTitle);
            tabResidents.Controls.Add(lstResidentAddresses);
            tabResidents.BackColor = Color.FromArgb(243, 244, 239);
            tabResidents.Location = new Point(4, 32);
            tabResidents.Name = "tabResidents";
            tabResidents.Padding = new Padding(3);
            tabResidents.Size = new Size(1042, 724);
            tabResidents.Text = "Residents";
            // 
            // tabCollections
            // 
            tabCollections.Controls.Add(lblCollectionsTitle);
            tabCollections.Controls.Add(pnlSchedule);
            tabCollections.Controls.Add(pnlAssign);
            tabCollections.Controls.Add(lblStatusFilter);
            tabCollections.Controls.Add(cboStatusFilter);
            tabCollections.Controls.Add(txtSearchCollection);
            tabCollections.Controls.Add(dgvCollections);
            tabCollections.BackColor = Color.FromArgb(243, 244, 239);
            tabCollections.Location = new Point(4, 32);
            tabCollections.Name = "tabCollections";
            tabCollections.Padding = new Padding(3);
            tabCollections.Size = new Size(1042, 724);
            tabCollections.Text = "Collections";
            // 
            // tabFleet
            // 
            tabFleet.Controls.Add(lblFleetTitle);
            tabFleet.Controls.Add(pnlAddVehicle);
            tabFleet.Controls.Add(dgvVehicles);
            tabFleet.Controls.Add(btnMaintenance);
            tabFleet.Controls.Add(btnAvailable);
            tabFleet.Controls.Add(pnlAddStaff);
            tabFleet.Controls.Add(lblStaffTitle);
            tabFleet.Controls.Add(dgvStaff);
            tabFleet.Controls.Add(lblStaffVehicle);
            tabFleet.Controls.Add(cboStaffVehicle);
            tabFleet.Controls.Add(btnGiveVehicle);
            tabFleet.Controls.Add(btnToggleDuty);
            tabFleet.BackColor = Color.FromArgb(243, 244, 239);
            tabFleet.Location = new Point(4, 32);
            tabFleet.Name = "tabFleet";
            tabFleet.Padding = new Padding(3);
            tabFleet.Size = new Size(1042, 724);
            tabFleet.Text = "Vehicles and staff";
            // 
            // tabRecycling
            // 
            tabRecycling.Controls.Add(lblRecyclingTitle);
            tabRecycling.Controls.Add(lblRecFilter);
            tabRecycling.Controls.Add(cboRecFilter);
            tabRecycling.Controls.Add(dgvRecycling);
            tabRecycling.Controls.Add(btnApprove);
            tabRecycling.Controls.Add(lblRejectReason);
            tabRecycling.Controls.Add(txtRejectReason);
            tabRecycling.Controls.Add(btnReject);
            tabRecycling.BackColor = Color.FromArgb(243, 244, 239);
            tabRecycling.Location = new Point(4, 32);
            tabRecycling.Name = "tabRecycling";
            tabRecycling.Padding = new Padding(3);
            tabRecycling.Size = new Size(1042, 724);
            tabRecycling.Text = "Recycling";
            // 
            // tabComplaints
            // 
            tabComplaints.Controls.Add(lblComplaintsTitle);
            tabComplaints.Controls.Add(lblCompFilter);
            tabComplaints.Controls.Add(cboCompFilter);
            tabComplaints.Controls.Add(dgvComplaints);
            tabComplaints.Controls.Add(pnlCompDetail);
            tabComplaints.BackColor = Color.FromArgb(243, 244, 239);
            tabComplaints.Location = new Point(4, 32);
            tabComplaints.Name = "tabComplaints";
            tabComplaints.Padding = new Padding(3);
            tabComplaints.Size = new Size(1042, 724);
            tabComplaints.Text = "Complaints";
            // 
            // tabReports
            // 
            tabReports.Controls.Add(lblReportsTitle);
            tabReports.Controls.Add(cboReportType);
            tabReports.Controls.Add(dtpReportDate);
            tabReports.Controls.Add(btnRunReport);
            tabReports.Controls.Add(btnExportReport);
            tabReports.Controls.Add(txtReport);
            tabReports.BackColor = Color.FromArgb(243, 244, 239);
            tabReports.Location = new Point(4, 32);
            tabReports.Name = "tabReports";
            tabReports.Padding = new Padding(3);
            tabReports.Size = new Size(1042, 724);
            tabReports.Text = "Reports";
            // 
            // lblDashTitle
            // 
            lblDashTitle.AutoSize = true;
            lblDashTitle.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            lblDashTitle.ForeColor = Color.FromArgb(22, 32, 26);
            lblDashTitle.Location = new Point(20, 14);
            lblDashTitle.Name = "lblDashTitle";
            lblDashTitle.TabIndex = 0;
            lblDashTitle.Text = "Administration Dashboard";
            // 
            // lblDashDate
            // 
            lblDashDate.AutoSize = true;
            lblDashDate.Font = new Font("Segoe UI", 10F);
            lblDashDate.ForeColor = Color.FromArgb(95, 107, 99);
            lblDashDate.Location = new Point(23, 54);
            lblDashDate.Name = "lblDashDate";
            lblDashDate.TabIndex = 1;
            lblDashDate.Text = "Today";
            // 
            // pnlKpi1
            // 
            pnlKpi1.Controls.Add(lblKpi1Title);
            pnlKpi1.Controls.Add(lblKpi1Value);
            pnlKpi1.BackColor = Color.White;
            pnlKpi1.BorderStyle = BorderStyle.FixedSingle;
            pnlKpi1.Location = new Point(20, 90);
            pnlKpi1.Name = "pnlKpi1";
            pnlKpi1.Size = new Size(236, 100);
            pnlKpi1.TabIndex = 2;
            // 
            // lblKpi1Title
            // 
            lblKpi1Title.AutoSize = true;
            lblKpi1Title.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblKpi1Title.ForeColor = Color.FromArgb(95, 107, 99);
            lblKpi1Title.Location = new Point(14, 12);
            lblKpi1Title.Name = "lblKpi1Title";
            lblKpi1Title.TabIndex = 0;
            lblKpi1Title.Text = "Collections today";
            // 
            // lblKpi1Value
            // 
            lblKpi1Value.AutoSize = true;
            lblKpi1Value.Font = new Font("Segoe UI", 24F, FontStyle.Bold);
            lblKpi1Value.ForeColor = Color.FromArgb(22, 32, 26);
            lblKpi1Value.Location = new Point(12, 38);
            lblKpi1Value.Name = "lblKpi1Value";
            lblKpi1Value.TabIndex = 1;
            lblKpi1Value.Text = "0";
            // 
            // pnlKpi2
            // 
            pnlKpi2.Controls.Add(lblKpi2Title);
            pnlKpi2.Controls.Add(lblKpi2Value);
            pnlKpi2.BackColor = Color.White;
            pnlKpi2.BorderStyle = BorderStyle.FixedSingle;
            pnlKpi2.Location = new Point(272, 90);
            pnlKpi2.Name = "pnlKpi2";
            pnlKpi2.Size = new Size(236, 100);
            pnlKpi2.TabIndex = 3;
            // 
            // lblKpi2Title
            // 
            lblKpi2Title.AutoSize = true;
            lblKpi2Title.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblKpi2Title.ForeColor = Color.FromArgb(95, 107, 99);
            lblKpi2Title.Location = new Point(14, 12);
            lblKpi2Title.Name = "lblKpi2Title";
            lblKpi2Title.TabIndex = 0;
            lblKpi2Title.Text = "Open complaints";
            // 
            // lblKpi2Value
            // 
            lblKpi2Value.AutoSize = true;
            lblKpi2Value.Font = new Font("Segoe UI", 24F, FontStyle.Bold);
            lblKpi2Value.ForeColor = Color.FromArgb(22, 32, 26);
            lblKpi2Value.Location = new Point(12, 38);
            lblKpi2Value.Name = "lblKpi2Value";
            lblKpi2Value.TabIndex = 1;
            lblKpi2Value.Text = "0";
            // 
            // pnlKpi3
            // 
            pnlKpi3.Controls.Add(lblKpi3Title);
            pnlKpi3.Controls.Add(lblKpi3Value);
            pnlKpi3.BackColor = Color.White;
            pnlKpi3.BorderStyle = BorderStyle.FixedSingle;
            pnlKpi3.Location = new Point(524, 90);
            pnlKpi3.Name = "pnlKpi3";
            pnlKpi3.Size = new Size(236, 100);
            pnlKpi3.TabIndex = 4;
            // 
            // lblKpi3Title
            // 
            lblKpi3Title.AutoSize = true;
            lblKpi3Title.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblKpi3Title.ForeColor = Color.FromArgb(95, 107, 99);
            lblKpi3Title.Location = new Point(14, 12);
            lblKpi3Title.Name = "lblKpi3Title";
            lblKpi3Title.TabIndex = 0;
            lblKpi3Title.Text = "Pending recycling";
            // 
            // lblKpi3Value
            // 
            lblKpi3Value.AutoSize = true;
            lblKpi3Value.Font = new Font("Segoe UI", 24F, FontStyle.Bold);
            lblKpi3Value.ForeColor = Color.FromArgb(22, 32, 26);
            lblKpi3Value.Location = new Point(12, 38);
            lblKpi3Value.Name = "lblKpi3Value";
            lblKpi3Value.TabIndex = 1;
            lblKpi3Value.Text = "0";
            // 
            // pnlKpi4
            // 
            pnlKpi4.Controls.Add(lblKpi4Title);
            pnlKpi4.Controls.Add(lblKpi4Value);
            pnlKpi4.BackColor = Color.White;
            pnlKpi4.BorderStyle = BorderStyle.FixedSingle;
            pnlKpi4.Location = new Point(776, 90);
            pnlKpi4.Name = "pnlKpi4";
            pnlKpi4.Size = new Size(236, 100);
            pnlKpi4.TabIndex = 5;
            // 
            // lblKpi4Title
            // 
            lblKpi4Title.AutoSize = true;
            lblKpi4Title.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblKpi4Title.ForeColor = Color.FromArgb(95, 107, 99);
            lblKpi4Title.Location = new Point(14, 12);
            lblKpi4Title.Name = "lblKpi4Title";
            lblKpi4Title.TabIndex = 0;
            lblKpi4Title.Text = "Vehicles available";
            // 
            // lblKpi4Value
            // 
            lblKpi4Value.AutoSize = true;
            lblKpi4Value.Font = new Font("Segoe UI", 24F, FontStyle.Bold);
            lblKpi4Value.ForeColor = Color.FromArgb(22, 32, 26);
            lblKpi4Value.Location = new Point(12, 38);
            lblKpi4Value.Name = "lblKpi4Value";
            lblKpi4Value.TabIndex = 1;
            lblKpi4Value.Text = "0";
            // 
            // pnlChart
            // 
            pnlChart.BackColor = Color.White;
            pnlChart.BorderStyle = BorderStyle.FixedSingle;
            pnlChart.Location = new Point(20, 206);
            pnlChart.Name = "pnlChart";
            pnlChart.Size = new Size(1000, 260);
            pnlChart.TabIndex = 6;
            pnlChart.Paint += pnlChart_Paint;
            // 
            // lblTodayTitle
            // 
            lblTodayTitle.AutoSize = true;
            lblTodayTitle.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            lblTodayTitle.ForeColor = Color.FromArgb(22, 32, 26);
            lblTodayTitle.Location = new Point(20, 480);
            lblTodayTitle.Name = "lblTodayTitle";
            lblTodayTitle.TabIndex = 7;
            lblTodayTitle.Text = "Today's collections";
            // 
            // dgvToday
            // 
            dgvToday.AllowUserToAddRows = false;
            dgvToday.AllowUserToDeleteRows = false;
            dgvToday.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvToday.BackgroundColor = Color.White;
            dgvToday.BorderStyle = BorderStyle.None;
            dgvToday.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvToday.Location = new Point(20, 514);
            dgvToday.MultiSelect = false;
            dgvToday.Name = "dgvToday";
            dgvToday.ReadOnly = true;
            dgvToday.RowHeadersVisible = false;
            dgvToday.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvToday.Size = new Size(1000, 160);
            dgvToday.TabIndex = 8;
            // 
            // lblResidentsTitle
            // 
            lblResidentsTitle.AutoSize = true;
            lblResidentsTitle.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            lblResidentsTitle.ForeColor = Color.FromArgb(22, 32, 26);
            lblResidentsTitle.Location = new Point(20, 14);
            lblResidentsTitle.Name = "lblResidentsTitle";
            lblResidentsTitle.TabIndex = 0;
            lblResidentsTitle.Text = "Residents";
            // 
            // txtSearchResident
            // 
            txtSearchResident.Font = new Font("Segoe UI", 11F);
            txtSearchResident.Location = new Point(20, 62);
            txtSearchResident.Name = "txtSearchResident";
            txtSearchResident.PlaceholderText = "Search name, username or email";
            txtSearchResident.Size = new Size(340, 31);
            txtSearchResident.TabIndex = 1;
            // 
            // btnSearchResident
            // 
            btnSearchResident.BackColor = Color.FromArgb(30, 90, 60);
            btnSearchResident.Cursor = Cursors.Hand;
            btnSearchResident.FlatAppearance.BorderSize = 0;
            btnSearchResident.FlatStyle = FlatStyle.Flat;
            btnSearchResident.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnSearchResident.ForeColor = Color.White;
            btnSearchResident.Location = new Point(372, 60);
            btnSearchResident.Name = "btnSearchResident";
            btnSearchResident.Size = new Size(120, 36);
            btnSearchResident.TabIndex = 2;
            btnSearchResident.Text = "Search";
            btnSearchResident.UseVisualStyleBackColor = false;
            btnSearchResident.Click += btnSearchResident_Click;
            // 
            // btnShowAllResidents
            // 
            btnShowAllResidents.BackColor = Color.White;
            btnShowAllResidents.Cursor = Cursors.Hand;
            btnShowAllResidents.FlatAppearance.BorderColor = Color.FromArgb(30, 90, 60);
            btnShowAllResidents.FlatStyle = FlatStyle.Flat;
            btnShowAllResidents.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnShowAllResidents.ForeColor = Color.FromArgb(30, 90, 60);
            btnShowAllResidents.Location = new Point(502, 60);
            btnShowAllResidents.Name = "btnShowAllResidents";
            btnShowAllResidents.Size = new Size(120, 36);
            btnShowAllResidents.TabIndex = 3;
            btnShowAllResidents.Text = "Show all";
            btnShowAllResidents.UseVisualStyleBackColor = false;
            btnShowAllResidents.Click += btnShowAllResidents_Click;
            // 
            // dgvResidents
            // 
            dgvResidents.AllowUserToAddRows = false;
            dgvResidents.AllowUserToDeleteRows = false;
            dgvResidents.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvResidents.BackgroundColor = Color.White;
            dgvResidents.BorderStyle = BorderStyle.None;
            dgvResidents.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvResidents.Location = new Point(20, 110);
            dgvResidents.MultiSelect = false;
            dgvResidents.Name = "dgvResidents";
            dgvResidents.ReadOnly = true;
            dgvResidents.RowHeadersVisible = false;
            dgvResidents.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvResidents.Size = new Size(1000, 400);
            dgvResidents.TabIndex = 4;
            dgvResidents.SelectionChanged += dgvResidents_SelectionChanged;
            // 
            // lblResidentAddressesTitle
            // 
            lblResidentAddressesTitle.AutoSize = true;
            lblResidentAddressesTitle.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lblResidentAddressesTitle.ForeColor = Color.FromArgb(22, 32, 26);
            lblResidentAddressesTitle.Location = new Point(20, 524);
            lblResidentAddressesTitle.Name = "lblResidentAddressesTitle";
            lblResidentAddressesTitle.TabIndex = 5;
            lblResidentAddressesTitle.Text = "Addresses of the selected resident";
            // 
            // lstResidentAddresses
            // 
            lstResidentAddresses.Font = new Font("Segoe UI", 10.5F);
            lstResidentAddresses.FormattingEnabled = true;
            lstResidentAddresses.ItemHeight = 23;
            lstResidentAddresses.Location = new Point(20, 556);
            lstResidentAddresses.Name = "lstResidentAddresses";
            lstResidentAddresses.Size = new Size(1000, 110);
            lstResidentAddresses.TabIndex = 6;
            // 
            // lblCollectionsTitle
            // 
            lblCollectionsTitle.AutoSize = true;
            lblCollectionsTitle.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            lblCollectionsTitle.ForeColor = Color.FromArgb(22, 32, 26);
            lblCollectionsTitle.Location = new Point(20, 14);
            lblCollectionsTitle.Name = "lblCollectionsTitle";
            lblCollectionsTitle.TabIndex = 0;
            lblCollectionsTitle.Text = "Collections";
            // 
            // pnlSchedule
            // 
            pnlSchedule.Controls.Add(lblScheduleHeading);
            pnlSchedule.Controls.Add(lblSchResident);
            pnlSchedule.Controls.Add(cboSchResident);
            pnlSchedule.Controls.Add(lblSchAddress);
            pnlSchedule.Controls.Add(cboSchAddress);
            pnlSchedule.Controls.Add(lblSchType);
            pnlSchedule.Controls.Add(cboSchType);
            pnlSchedule.Controls.Add(lblSchDate);
            pnlSchedule.Controls.Add(dtpSchDate);
            pnlSchedule.Controls.Add(btnSchedule);
            pnlSchedule.BackColor = Color.White;
            pnlSchedule.BorderStyle = BorderStyle.FixedSingle;
            pnlSchedule.Location = new Point(20, 60);
            pnlSchedule.Name = "pnlSchedule";
            pnlSchedule.Size = new Size(320, 345);
            pnlSchedule.TabIndex = 1;
            // 
            // lblScheduleHeading
            // 
            lblScheduleHeading.AutoSize = true;
            lblScheduleHeading.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            lblScheduleHeading.ForeColor = Color.FromArgb(22, 32, 26);
            lblScheduleHeading.Location = new Point(14, 12);
            lblScheduleHeading.Name = "lblScheduleHeading";
            lblScheduleHeading.TabIndex = 0;
            lblScheduleHeading.Text = "Schedule a collection";
            // 
            // lblSchResident
            // 
            lblSchResident.AutoSize = true;
            lblSchResident.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblSchResident.ForeColor = Color.FromArgb(22, 32, 26);
            lblSchResident.Location = new Point(14, 48);
            lblSchResident.Name = "lblSchResident";
            lblSchResident.TabIndex = 1;
            lblSchResident.Text = "Resident";
            // 
            // cboSchResident
            // 
            cboSchResident.DropDownStyle = ComboBoxStyle.DropDownList;
            cboSchResident.Font = new Font("Segoe UI", 10.5F);
            cboSchResident.FormattingEnabled = true;
            cboSchResident.Location = new Point(14, 72);
            cboSchResident.Name = "cboSchResident";
            cboSchResident.Size = new Size(290, 32);
            cboSchResident.TabIndex = 2;
            cboSchResident.SelectedIndexChanged += cboSchResident_SelectedIndexChanged;
            // 
            // lblSchAddress
            // 
            lblSchAddress.AutoSize = true;
            lblSchAddress.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblSchAddress.ForeColor = Color.FromArgb(22, 32, 26);
            lblSchAddress.Location = new Point(14, 108);
            lblSchAddress.Name = "lblSchAddress";
            lblSchAddress.TabIndex = 3;
            lblSchAddress.Text = "Address";
            // 
            // cboSchAddress
            // 
            cboSchAddress.DropDownStyle = ComboBoxStyle.DropDownList;
            cboSchAddress.Font = new Font("Segoe UI", 10.5F);
            cboSchAddress.FormattingEnabled = true;
            cboSchAddress.Location = new Point(14, 132);
            cboSchAddress.Name = "cboSchAddress";
            cboSchAddress.Size = new Size(290, 32);
            cboSchAddress.TabIndex = 4;
            // 
            // lblSchType
            // 
            lblSchType.AutoSize = true;
            lblSchType.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblSchType.ForeColor = Color.FromArgb(22, 32, 26);
            lblSchType.Location = new Point(14, 168);
            lblSchType.Name = "lblSchType";
            lblSchType.TabIndex = 5;
            lblSchType.Text = "Type";
            // 
            // cboSchType
            // 
            cboSchType.DropDownStyle = ComboBoxStyle.DropDownList;
            cboSchType.Font = new Font("Segoe UI", 10.5F);
            cboSchType.FormattingEnabled = true;
            cboSchType.Items.AddRange(new object[] { "General waste", "Garden refuse", "Bulky items", "Recycling" });
            cboSchType.Location = new Point(14, 192);
            cboSchType.Name = "cboSchType";
            cboSchType.Size = new Size(140, 32);
            cboSchType.TabIndex = 6;
            // 
            // lblSchDate
            // 
            lblSchDate.AutoSize = true;
            lblSchDate.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblSchDate.ForeColor = Color.FromArgb(22, 32, 26);
            lblSchDate.Location = new Point(164, 168);
            lblSchDate.Name = "lblSchDate";
            lblSchDate.TabIndex = 7;
            lblSchDate.Text = "Date";
            // 
            // dtpSchDate
            // 
            dtpSchDate.Font = new Font("Segoe UI", 10F);
            dtpSchDate.Format = DateTimePickerFormat.Short;
            dtpSchDate.Location = new Point(164, 192);
            dtpSchDate.Name = "dtpSchDate";
            dtpSchDate.Size = new Size(140, 32);
            dtpSchDate.TabIndex = 8;
            // 
            // btnSchedule
            // 
            btnSchedule.BackColor = Color.FromArgb(30, 90, 60);
            btnSchedule.Cursor = Cursors.Hand;
            btnSchedule.FlatAppearance.BorderSize = 0;
            btnSchedule.FlatStyle = FlatStyle.Flat;
            btnSchedule.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnSchedule.ForeColor = Color.White;
            btnSchedule.Location = new Point(14, 238);
            btnSchedule.Name = "btnSchedule";
            btnSchedule.Size = new Size(290, 44);
            btnSchedule.TabIndex = 9;
            btnSchedule.Text = "Schedule";
            btnSchedule.UseVisualStyleBackColor = false;
            btnSchedule.Click += btnSchedule_Click;
            // 
            // pnlAssign
            // 
            pnlAssign.Controls.Add(lblAssignHeading);
            pnlAssign.Controls.Add(lblDriver);
            pnlAssign.Controls.Add(cboDriver);
            pnlAssign.Controls.Add(lblVehicle);
            pnlAssign.Controls.Add(cboVehicle);
            pnlAssign.Controls.Add(btnAssign);
            pnlAssign.Controls.Add(btnTrackDriver);
            pnlAssign.Controls.Add(btnCancelSelectedCollection);
            pnlAssign.BackColor = Color.White;
            pnlAssign.BorderStyle = BorderStyle.FixedSingle;
            pnlAssign.Location = new Point(20, 415);
            pnlAssign.Name = "pnlAssign";
            pnlAssign.Size = new Size(320, 280);
            pnlAssign.TabIndex = 2;
            // 
            // lblAssignHeading
            // 
            lblAssignHeading.AutoSize = true;
            lblAssignHeading.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            lblAssignHeading.ForeColor = Color.FromArgb(22, 32, 26);
            lblAssignHeading.Location = new Point(14, 12);
            lblAssignHeading.Name = "lblAssignHeading";
            lblAssignHeading.TabIndex = 0;
            lblAssignHeading.Text = "Selected collection";
            // 
            // lblDriver
            // 
            lblDriver.AutoSize = true;
            lblDriver.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblDriver.ForeColor = Color.FromArgb(22, 32, 26);
            lblDriver.Location = new Point(14, 48);
            lblDriver.Name = "lblDriver";
            lblDriver.TabIndex = 1;
            lblDriver.Text = "Driver";
            // 
            // cboDriver
            // 
            cboDriver.DropDownStyle = ComboBoxStyle.DropDownList;
            cboDriver.Font = new Font("Segoe UI", 10.5F);
            cboDriver.FormattingEnabled = true;
            cboDriver.Location = new Point(14, 72);
            cboDriver.Name = "cboDriver";
            cboDriver.Size = new Size(290, 32);
            cboDriver.TabIndex = 2;
            // 
            // lblVehicle
            // 
            lblVehicle.AutoSize = true;
            lblVehicle.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblVehicle.ForeColor = Color.FromArgb(22, 32, 26);
            lblVehicle.Location = new Point(14, 108);
            lblVehicle.Name = "lblVehicle";
            lblVehicle.TabIndex = 3;
            lblVehicle.Text = "Vehicle";
            // 
            // cboVehicle
            // 
            cboVehicle.DropDownStyle = ComboBoxStyle.DropDownList;
            cboVehicle.Font = new Font("Segoe UI", 10.5F);
            cboVehicle.FormattingEnabled = true;
            cboVehicle.Location = new Point(14, 132);
            cboVehicle.Name = "cboVehicle";
            cboVehicle.Size = new Size(290, 32);
            cboVehicle.TabIndex = 4;
            // 
            // btnAssign
            // 
            btnAssign.BackColor = Color.FromArgb(30, 90, 60);
            btnAssign.Cursor = Cursors.Hand;
            btnAssign.FlatAppearance.BorderSize = 0;
            btnAssign.FlatStyle = FlatStyle.Flat;
            btnAssign.Font = new Font("Segoe UI", 10.5F, FontStyle.Bold);
            btnAssign.ForeColor = Color.White;
            btnAssign.Location = new Point(14, 178);
            btnAssign.Name = "btnAssign";
            btnAssign.Size = new Size(290, 42);
            btnAssign.TabIndex = 5;
            btnAssign.Text = "Assign driver && vehicle";
            btnAssign.UseVisualStyleBackColor = false;
            btnAssign.Click += btnAssign_Click;
            // 
            // btnTrackDriver
            // 
            btnTrackDriver.BackColor = Color.White;
            btnTrackDriver.Cursor = Cursors.Hand;
            btnTrackDriver.FlatAppearance.BorderColor = Color.FromArgb(30, 90, 60);
            btnTrackDriver.FlatStyle = FlatStyle.Flat;
            btnTrackDriver.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnTrackDriver.ForeColor = Color.FromArgb(30, 90, 60);
            btnTrackDriver.Location = new Point(14, 228);
            btnTrackDriver.Name = "btnTrackDriver";
            btnTrackDriver.Size = new Size(130, 38);
            btnTrackDriver.TabIndex = 6;
            btnTrackDriver.Text = "Track driver";
            btnTrackDriver.UseVisualStyleBackColor = false;
            btnTrackDriver.Click += btnTrackDriver_Click;
            // 
            // btnCancelSelectedCollection
            // 
            btnCancelSelectedCollection.BackColor = Color.White;
            btnCancelSelectedCollection.Cursor = Cursors.Hand;
            btnCancelSelectedCollection.FlatAppearance.BorderColor = Color.FromArgb(163, 33, 22);
            btnCancelSelectedCollection.FlatStyle = FlatStyle.Flat;
            btnCancelSelectedCollection.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnCancelSelectedCollection.ForeColor = Color.FromArgb(163, 33, 22);
            btnCancelSelectedCollection.Location = new Point(154, 228);
            btnCancelSelectedCollection.Name = "btnCancelSelectedCollection";
            btnCancelSelectedCollection.Size = new Size(150, 38);
            btnCancelSelectedCollection.TabIndex = 7;
            btnCancelSelectedCollection.Text = "Cancel collection";
            btnCancelSelectedCollection.UseVisualStyleBackColor = false;
            btnCancelSelectedCollection.Click += btnCancelSelectedCollection_Click;
            // 
            // lblStatusFilter
            // 
            lblStatusFilter.AutoSize = true;
            lblStatusFilter.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblStatusFilter.ForeColor = Color.FromArgb(22, 32, 26);
            lblStatusFilter.Location = new Point(360, 66);
            lblStatusFilter.Name = "lblStatusFilter";
            lblStatusFilter.TabIndex = 3;
            lblStatusFilter.Text = "Show:";
            // 
            // cboStatusFilter
            // 
            cboStatusFilter.DropDownStyle = ComboBoxStyle.DropDownList;
            cboStatusFilter.Font = new Font("Segoe UI", 10.5F);
            cboStatusFilter.FormattingEnabled = true;
            cboStatusFilter.Items.AddRange(new object[] { "All", "Scheduled", "Assigned", "InProgress", "Completed", "Missed", "Cancelled" });
            cboStatusFilter.Location = new Point(412, 62);
            cboStatusFilter.Name = "cboStatusFilter";
            cboStatusFilter.Size = new Size(170, 32);
            cboStatusFilter.TabIndex = 4;
            cboStatusFilter.SelectedIndexChanged += cboStatusFilter_SelectedIndexChanged;
            // 
            // txtSearchCollection
            // 
            txtSearchCollection.Font = new Font("Segoe UI", 11F);
            txtSearchCollection.Location = new Point(600, 62);
            txtSearchCollection.Name = "txtSearchCollection";
            txtSearchCollection.PlaceholderText = "Search id, resident or address";
            txtSearchCollection.Size = new Size(420, 31);
            txtSearchCollection.TabIndex = 5;
            txtSearchCollection.TextChanged += txtSearchCollection_TextChanged;
            // 
            // dgvCollections
            // 
            dgvCollections.AllowUserToAddRows = false;
            dgvCollections.AllowUserToDeleteRows = false;
            dgvCollections.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvCollections.BackgroundColor = Color.White;
            dgvCollections.BorderStyle = BorderStyle.None;
            dgvCollections.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvCollections.Location = new Point(360, 105);
            dgvCollections.MultiSelect = false;
            dgvCollections.Name = "dgvCollections";
            dgvCollections.ReadOnly = true;
            dgvCollections.RowHeadersVisible = false;
            dgvCollections.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvCollections.Size = new Size(660, 580);
            dgvCollections.TabIndex = 6;
            // 
            // lblFleetTitle
            // 
            lblFleetTitle.AutoSize = true;
            lblFleetTitle.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            lblFleetTitle.ForeColor = Color.FromArgb(22, 32, 26);
            lblFleetTitle.Location = new Point(20, 14);
            lblFleetTitle.Name = "lblFleetTitle";
            lblFleetTitle.TabIndex = 0;
            lblFleetTitle.Text = "Vehicles && staff";
            // 
            // pnlAddVehicle
            // 
            pnlAddVehicle.Controls.Add(lblAddVehicleHeading);
            pnlAddVehicle.Controls.Add(lblRegistration);
            pnlAddVehicle.Controls.Add(txtRegistration);
            pnlAddVehicle.Controls.Add(lblVehicleType);
            pnlAddVehicle.Controls.Add(cboVehicleType);
            pnlAddVehicle.Controls.Add(lblCapacity);
            pnlAddVehicle.Controls.Add(nudCapacity);
            pnlAddVehicle.Controls.Add(btnAddVehicle);
            pnlAddVehicle.BackColor = Color.White;
            pnlAddVehicle.BorderStyle = BorderStyle.FixedSingle;
            pnlAddVehicle.Location = new Point(20, 60);
            pnlAddVehicle.Name = "pnlAddVehicle";
            pnlAddVehicle.Size = new Size(320, 300);
            pnlAddVehicle.TabIndex = 1;
            // 
            // lblAddVehicleHeading
            // 
            lblAddVehicleHeading.AutoSize = true;
            lblAddVehicleHeading.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            lblAddVehicleHeading.ForeColor = Color.FromArgb(22, 32, 26);
            lblAddVehicleHeading.Location = new Point(14, 12);
            lblAddVehicleHeading.Name = "lblAddVehicleHeading";
            lblAddVehicleHeading.TabIndex = 0;
            lblAddVehicleHeading.Text = "Register a vehicle";
            // 
            // lblRegistration
            // 
            lblRegistration.AutoSize = true;
            lblRegistration.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblRegistration.ForeColor = Color.FromArgb(22, 32, 26);
            lblRegistration.Location = new Point(14, 48);
            lblRegistration.Name = "lblRegistration";
            lblRegistration.TabIndex = 1;
            lblRegistration.Text = "Registration";
            // 
            // txtRegistration
            // 
            txtRegistration.Font = new Font("Segoe UI", 11F);
            txtRegistration.Location = new Point(14, 72);
            txtRegistration.Name = "txtRegistration";
            txtRegistration.PlaceholderText = "e.g. CA 123-456";
            txtRegistration.Size = new Size(290, 31);
            txtRegistration.TabIndex = 2;
            // 
            // lblVehicleType
            // 
            lblVehicleType.AutoSize = true;
            lblVehicleType.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblVehicleType.ForeColor = Color.FromArgb(22, 32, 26);
            lblVehicleType.Location = new Point(14, 107);
            lblVehicleType.Name = "lblVehicleType";
            lblVehicleType.TabIndex = 3;
            lblVehicleType.Text = "Type";
            // 
            // cboVehicleType
            // 
            cboVehicleType.DropDownStyle = ComboBoxStyle.DropDownList;
            cboVehicleType.Font = new Font("Segoe UI", 10.5F);
            cboVehicleType.FormattingEnabled = true;
            cboVehicleType.Items.AddRange(new object[] { "Compactor truck", "Recycling truck", "Tipper truck" });
            cboVehicleType.Location = new Point(14, 131);
            cboVehicleType.Name = "cboVehicleType";
            cboVehicleType.Size = new Size(180, 32);
            cboVehicleType.TabIndex = 4;
            // 
            // lblCapacity
            // 
            lblCapacity.AutoSize = true;
            lblCapacity.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblCapacity.ForeColor = Color.FromArgb(22, 32, 26);
            lblCapacity.Location = new Point(204, 107);
            lblCapacity.Name = "lblCapacity";
            lblCapacity.TabIndex = 5;
            lblCapacity.Text = "Tons";
            // 
            // nudCapacity
            // 
            nudCapacity.Font = new Font("Segoe UI", 10.5F);
            nudCapacity.Location = new Point(204, 131);
            nudCapacity.Maximum = new decimal(new int[] { 40, 0, 0, 0 });
            nudCapacity.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            nudCapacity.Name = "nudCapacity";
            nudCapacity.Size = new Size(100, 32);
            nudCapacity.TabIndex = 6;
            nudCapacity.Value = new decimal(new int[] { 10, 0, 0, 0 });
            // 
            // btnAddVehicle
            // 
            btnAddVehicle.BackColor = Color.FromArgb(30, 90, 60);
            btnAddVehicle.Cursor = Cursors.Hand;
            btnAddVehicle.FlatAppearance.BorderSize = 0;
            btnAddVehicle.FlatStyle = FlatStyle.Flat;
            btnAddVehicle.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnAddVehicle.ForeColor = Color.White;
            btnAddVehicle.Location = new Point(14, 177);
            btnAddVehicle.Name = "btnAddVehicle";
            btnAddVehicle.Size = new Size(290, 44);
            btnAddVehicle.TabIndex = 7;
            btnAddVehicle.Text = "Add vehicle";
            btnAddVehicle.UseVisualStyleBackColor = false;
            btnAddVehicle.Click += btnAddVehicle_Click;
            // 
            // dgvVehicles
            // 
            dgvVehicles.AllowUserToAddRows = false;
            dgvVehicles.AllowUserToDeleteRows = false;
            dgvVehicles.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvVehicles.BackgroundColor = Color.White;
            dgvVehicles.BorderStyle = BorderStyle.None;
            dgvVehicles.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvVehicles.Location = new Point(360, 60);
            dgvVehicles.MultiSelect = false;
            dgvVehicles.Name = "dgvVehicles";
            dgvVehicles.ReadOnly = true;
            dgvVehicles.RowHeadersVisible = false;
            dgvVehicles.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvVehicles.Size = new Size(660, 220);
            dgvVehicles.TabIndex = 2;
            // 
            // btnMaintenance
            // 
            btnMaintenance.BackColor = Color.White;
            btnMaintenance.Cursor = Cursors.Hand;
            btnMaintenance.FlatAppearance.BorderColor = Color.FromArgb(163, 33, 22);
            btnMaintenance.FlatStyle = FlatStyle.Flat;
            btnMaintenance.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnMaintenance.ForeColor = Color.FromArgb(163, 33, 22);
            btnMaintenance.Location = new Point(360, 290);
            btnMaintenance.Name = "btnMaintenance";
            btnMaintenance.Size = new Size(220, 38);
            btnMaintenance.TabIndex = 3;
            btnMaintenance.Text = "Send to maintenance";
            btnMaintenance.UseVisualStyleBackColor = false;
            btnMaintenance.Click += btnMaintenance_Click;
            // 
            // btnAvailable
            // 
            btnAvailable.BackColor = Color.White;
            btnAvailable.Cursor = Cursors.Hand;
            btnAvailable.FlatAppearance.BorderColor = Color.FromArgb(30, 90, 60);
            btnAvailable.FlatStyle = FlatStyle.Flat;
            btnAvailable.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnAvailable.ForeColor = Color.FromArgb(30, 90, 60);
            btnAvailable.Location = new Point(590, 290);
            btnAvailable.Name = "btnAvailable";
            btnAvailable.Size = new Size(180, 38);
            btnAvailable.TabIndex = 4;
            btnAvailable.Text = "Mark available";
            btnAvailable.UseVisualStyleBackColor = false;
            btnAvailable.Click += btnAvailable_Click;
            // 
            // pnlAddStaff
            // 
            pnlAddStaff.Controls.Add(lblAddStaffHeading);
            pnlAddStaff.Controls.Add(lblStaffName);
            pnlAddStaff.Controls.Add(txtStaffName);
            pnlAddStaff.Controls.Add(lblStaffUsername);
            pnlAddStaff.Controls.Add(txtStaffUsername);
            pnlAddStaff.Controls.Add(lblStaffPasswordNote);
            pnlAddStaff.Controls.Add(btnAddStaff);
            pnlAddStaff.BackColor = Color.White;
            pnlAddStaff.BorderStyle = BorderStyle.FixedSingle;
            pnlAddStaff.Location = new Point(20, 372);
            pnlAddStaff.Name = "pnlAddStaff";
            pnlAddStaff.Size = new Size(320, 313);
            pnlAddStaff.TabIndex = 5;
            // 
            // lblAddStaffHeading
            // 
            lblAddStaffHeading.AutoSize = true;
            lblAddStaffHeading.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            lblAddStaffHeading.ForeColor = Color.FromArgb(22, 32, 26);
            lblAddStaffHeading.Location = new Point(14, 12);
            lblAddStaffHeading.Name = "lblAddStaffHeading";
            lblAddStaffHeading.TabIndex = 0;
            lblAddStaffHeading.Text = "Add a staff member";
            // 
            // lblStaffName
            // 
            lblStaffName.AutoSize = true;
            lblStaffName.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblStaffName.ForeColor = Color.FromArgb(22, 32, 26);
            lblStaffName.Location = new Point(14, 48);
            lblStaffName.Name = "lblStaffName";
            lblStaffName.TabIndex = 1;
            lblStaffName.Text = "Full name";
            // 
            // txtStaffName
            // 
            txtStaffName.Font = new Font("Segoe UI", 11F);
            txtStaffName.Location = new Point(14, 72);
            txtStaffName.Name = "txtStaffName";
            txtStaffName.Size = new Size(290, 31);
            txtStaffName.TabIndex = 2;
            // 
            // lblStaffUsername
            // 
            lblStaffUsername.AutoSize = true;
            lblStaffUsername.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblStaffUsername.ForeColor = Color.FromArgb(22, 32, 26);
            lblStaffUsername.Location = new Point(14, 107);
            lblStaffUsername.Name = "lblStaffUsername";
            lblStaffUsername.TabIndex = 3;
            lblStaffUsername.Text = "Username";
            // 
            // txtStaffUsername
            // 
            txtStaffUsername.Font = new Font("Segoe UI", 11F);
            txtStaffUsername.Location = new Point(14, 131);
            txtStaffUsername.Name = "txtStaffUsername";
            txtStaffUsername.Size = new Size(290, 31);
            txtStaffUsername.TabIndex = 4;
            // 
            // lblStaffPasswordNote
            // 
            lblStaffPasswordNote.Font = new Font("Segoe UI", 9F);
            lblStaffPasswordNote.ForeColor = Color.FromArgb(95, 107, 99);
            lblStaffPasswordNote.Location = new Point(14, 168);
            lblStaffPasswordNote.Name = "lblStaffPasswordNote";
            lblStaffPasswordNote.Size = new Size(290, 22);
            lblStaffPasswordNote.TabIndex = 5;
            lblStaffPasswordNote.Text = "Their password will be Staff@123";
            // 
            // btnAddStaff
            // 
            btnAddStaff.BackColor = Color.FromArgb(30, 90, 60);
            btnAddStaff.Cursor = Cursors.Hand;
            btnAddStaff.FlatAppearance.BorderSize = 0;
            btnAddStaff.FlatStyle = FlatStyle.Flat;
            btnAddStaff.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnAddStaff.ForeColor = Color.White;
            btnAddStaff.Location = new Point(14, 196);
            btnAddStaff.Name = "btnAddStaff";
            btnAddStaff.Size = new Size(290, 44);
            btnAddStaff.TabIndex = 6;
            btnAddStaff.Text = "Add staff member";
            btnAddStaff.UseVisualStyleBackColor = false;
            btnAddStaff.Click += btnAddStaff_Click;
            // 
            // lblStaffTitle
            // 
            lblStaffTitle.AutoSize = true;
            lblStaffTitle.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lblStaffTitle.ForeColor = Color.FromArgb(22, 32, 26);
            lblStaffTitle.Location = new Point(360, 346);
            lblStaffTitle.Name = "lblStaffTitle";
            lblStaffTitle.TabIndex = 6;
            lblStaffTitle.Text = "Collection staff";
            // 
            // dgvStaff
            // 
            dgvStaff.AllowUserToAddRows = false;
            dgvStaff.AllowUserToDeleteRows = false;
            dgvStaff.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvStaff.BackgroundColor = Color.White;
            dgvStaff.BorderStyle = BorderStyle.None;
            dgvStaff.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvStaff.Location = new Point(360, 376);
            dgvStaff.MultiSelect = false;
            dgvStaff.Name = "dgvStaff";
            dgvStaff.ReadOnly = true;
            dgvStaff.RowHeadersVisible = false;
            dgvStaff.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvStaff.Size = new Size(660, 228);
            dgvStaff.TabIndex = 7;
            // 
            // lblStaffVehicle
            // 
            lblStaffVehicle.AutoSize = true;
            lblStaffVehicle.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            lblStaffVehicle.ForeColor = Color.FromArgb(22, 32, 26);
            lblStaffVehicle.Location = new Point(360, 612);
            lblStaffVehicle.Name = "lblStaffVehicle";
            lblStaffVehicle.TabIndex = 8;
            lblStaffVehicle.Text = "Vehicle for the selected driver:";
            // 
            // cboStaffVehicle
            // 
            cboStaffVehicle.DropDownStyle = ComboBoxStyle.DropDownList;
            cboStaffVehicle.Font = new Font("Segoe UI", 10.5F);
            cboStaffVehicle.FormattingEnabled = true;
            cboStaffVehicle.Location = new Point(360, 640);
            cboStaffVehicle.Name = "cboStaffVehicle";
            cboStaffVehicle.Size = new Size(200, 32);
            cboStaffVehicle.TabIndex = 9;
            // 
            // btnGiveVehicle
            // 
            btnGiveVehicle.BackColor = Color.White;
            btnGiveVehicle.Cursor = Cursors.Hand;
            btnGiveVehicle.FlatAppearance.BorderColor = Color.FromArgb(30, 90, 60);
            btnGiveVehicle.FlatStyle = FlatStyle.Flat;
            btnGiveVehicle.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnGiveVehicle.ForeColor = Color.FromArgb(30, 90, 60);
            btnGiveVehicle.Location = new Point(570, 638);
            btnGiveVehicle.Name = "btnGiveVehicle";
            btnGiveVehicle.Size = new Size(210, 38);
            btnGiveVehicle.TabIndex = 10;
            btnGiveVehicle.Text = "Give vehicle to driver";
            btnGiveVehicle.UseVisualStyleBackColor = false;
            btnGiveVehicle.Click += btnGiveVehicle_Click;
            // 
            // btnToggleDuty
            // 
            btnToggleDuty.BackColor = Color.White;
            btnToggleDuty.Cursor = Cursors.Hand;
            btnToggleDuty.FlatAppearance.BorderColor = Color.FromArgb(30, 90, 60);
            btnToggleDuty.FlatStyle = FlatStyle.Flat;
            btnToggleDuty.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnToggleDuty.ForeColor = Color.FromArgb(30, 90, 60);
            btnToggleDuty.Location = new Point(790, 638);
            btnToggleDuty.Name = "btnToggleDuty";
            btnToggleDuty.Size = new Size(230, 38);
            btnToggleDuty.TabIndex = 11;
            btnToggleDuty.Text = "Switch on / off duty";
            btnToggleDuty.UseVisualStyleBackColor = false;
            btnToggleDuty.Click += btnToggleDuty_Click;
            // 
            // lblRecyclingTitle
            // 
            lblRecyclingTitle.AutoSize = true;
            lblRecyclingTitle.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            lblRecyclingTitle.ForeColor = Color.FromArgb(22, 32, 26);
            lblRecyclingTitle.Location = new Point(20, 14);
            lblRecyclingTitle.Name = "lblRecyclingTitle";
            lblRecyclingTitle.TabIndex = 0;
            lblRecyclingTitle.Text = "Recycling requests";
            // 
            // lblRecFilter
            // 
            lblRecFilter.AutoSize = true;
            lblRecFilter.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblRecFilter.ForeColor = Color.FromArgb(22, 32, 26);
            lblRecFilter.Location = new Point(20, 66);
            lblRecFilter.Name = "lblRecFilter";
            lblRecFilter.TabIndex = 1;
            lblRecFilter.Text = "Show:";
            // 
            // cboRecFilter
            // 
            cboRecFilter.DropDownStyle = ComboBoxStyle.DropDownList;
            cboRecFilter.Font = new Font("Segoe UI", 10.5F);
            cboRecFilter.FormattingEnabled = true;
            cboRecFilter.Items.AddRange(new object[] { "All", "Pending", "Approved", "Collected", "Rejected" });
            cboRecFilter.Location = new Point(72, 62);
            cboRecFilter.Name = "cboRecFilter";
            cboRecFilter.Size = new Size(170, 32);
            cboRecFilter.TabIndex = 2;
            cboRecFilter.SelectedIndexChanged += cboRecFilter_SelectedIndexChanged;
            // 
            // dgvRecycling
            // 
            dgvRecycling.AllowUserToAddRows = false;
            dgvRecycling.AllowUserToDeleteRows = false;
            dgvRecycling.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvRecycling.BackgroundColor = Color.White;
            dgvRecycling.BorderStyle = BorderStyle.None;
            dgvRecycling.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvRecycling.Location = new Point(20, 105);
            dgvRecycling.MultiSelect = false;
            dgvRecycling.Name = "dgvRecycling";
            dgvRecycling.ReadOnly = true;
            dgvRecycling.RowHeadersVisible = false;
            dgvRecycling.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvRecycling.Size = new Size(1000, 430);
            dgvRecycling.TabIndex = 3;
            // 
            // btnApprove
            // 
            btnApprove.BackColor = Color.FromArgb(30, 90, 60);
            btnApprove.Cursor = Cursors.Hand;
            btnApprove.FlatAppearance.BorderSize = 0;
            btnApprove.FlatStyle = FlatStyle.Flat;
            btnApprove.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnApprove.ForeColor = Color.White;
            btnApprove.Location = new Point(20, 548);
            btnApprove.Name = "btnApprove";
            btnApprove.Size = new Size(240, 44);
            btnApprove.TabIndex = 4;
            btnApprove.Text = "Approve && schedule";
            btnApprove.UseVisualStyleBackColor = false;
            btnApprove.Click += btnApprove_Click;
            // 
            // lblRejectReason
            // 
            lblRejectReason.AutoSize = true;
            lblRejectReason.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblRejectReason.ForeColor = Color.FromArgb(22, 32, 26);
            lblRejectReason.Location = new Point(20, 606);
            lblRejectReason.Name = "lblRejectReason";
            lblRejectReason.TabIndex = 5;
            lblRejectReason.Text = "Reason for rejecting (the resident will see it):";
            // 
            // txtRejectReason
            // 
            txtRejectReason.Font = new Font("Segoe UI", 11F);
            txtRejectReason.Location = new Point(20, 632);
            txtRejectReason.Name = "txtRejectReason";
            txtRejectReason.PlaceholderText = "e.g. Please rinse the bottles and request again";
            txtRejectReason.Size = new Size(600, 31);
            txtRejectReason.TabIndex = 6;
            // 
            // btnReject
            // 
            btnReject.BackColor = Color.White;
            btnReject.Cursor = Cursors.Hand;
            btnReject.FlatAppearance.BorderColor = Color.FromArgb(163, 33, 22);
            btnReject.FlatStyle = FlatStyle.Flat;
            btnReject.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnReject.ForeColor = Color.FromArgb(163, 33, 22);
            btnReject.Location = new Point(632, 629);
            btnReject.Name = "btnReject";
            btnReject.Size = new Size(160, 38);
            btnReject.TabIndex = 7;
            btnReject.Text = "Reject";
            btnReject.UseVisualStyleBackColor = false;
            btnReject.Click += btnReject_Click;
            // 
            // lblComplaintsTitle
            // 
            lblComplaintsTitle.AutoSize = true;
            lblComplaintsTitle.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            lblComplaintsTitle.ForeColor = Color.FromArgb(22, 32, 26);
            lblComplaintsTitle.Location = new Point(20, 14);
            lblComplaintsTitle.Name = "lblComplaintsTitle";
            lblComplaintsTitle.TabIndex = 0;
            lblComplaintsTitle.Text = "Complaints";
            // 
            // lblCompFilter
            // 
            lblCompFilter.AutoSize = true;
            lblCompFilter.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblCompFilter.ForeColor = Color.FromArgb(22, 32, 26);
            lblCompFilter.Location = new Point(20, 66);
            lblCompFilter.Name = "lblCompFilter";
            lblCompFilter.TabIndex = 1;
            lblCompFilter.Text = "Show:";
            // 
            // cboCompFilter
            // 
            cboCompFilter.DropDownStyle = ComboBoxStyle.DropDownList;
            cboCompFilter.Font = new Font("Segoe UI", 10.5F);
            cboCompFilter.FormattingEnabled = true;
            cboCompFilter.Items.AddRange(new object[] { "Open", "All", "Submitted", "UnderReview", "Resolved" });
            cboCompFilter.Location = new Point(72, 62);
            cboCompFilter.Name = "cboCompFilter";
            cboCompFilter.Size = new Size(170, 32);
            cboCompFilter.TabIndex = 2;
            cboCompFilter.SelectedIndexChanged += cboCompFilter_SelectedIndexChanged;
            // 
            // dgvComplaints
            // 
            dgvComplaints.AllowUserToAddRows = false;
            dgvComplaints.AllowUserToDeleteRows = false;
            dgvComplaints.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvComplaints.BackgroundColor = Color.White;
            dgvComplaints.BorderStyle = BorderStyle.None;
            dgvComplaints.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvComplaints.Location = new Point(20, 105);
            dgvComplaints.MultiSelect = false;
            dgvComplaints.Name = "dgvComplaints";
            dgvComplaints.ReadOnly = true;
            dgvComplaints.RowHeadersVisible = false;
            dgvComplaints.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvComplaints.Size = new Size(620, 580);
            dgvComplaints.TabIndex = 3;
            dgvComplaints.SelectionChanged += dgvComplaints_SelectionChanged;
            // 
            // pnlCompDetail
            // 
            pnlCompDetail.Controls.Add(lblCompDetailHeading);
            pnlCompDetail.Controls.Add(txtCompDetails);
            pnlCompDetail.Controls.Add(btnStartReview);
            pnlCompDetail.Controls.Add(lblReply);
            pnlCompDetail.Controls.Add(txtReply);
            pnlCompDetail.Controls.Add(btnResolve);
            pnlCompDetail.BackColor = Color.White;
            pnlCompDetail.BorderStyle = BorderStyle.FixedSingle;
            pnlCompDetail.Location = new Point(660, 105);
            pnlCompDetail.Name = "pnlCompDetail";
            pnlCompDetail.Size = new Size(360, 580);
            pnlCompDetail.TabIndex = 4;
            // 
            // lblCompDetailHeading
            // 
            lblCompDetailHeading.AutoSize = true;
            lblCompDetailHeading.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            lblCompDetailHeading.ForeColor = Color.FromArgb(22, 32, 26);
            lblCompDetailHeading.Location = new Point(14, 12);
            lblCompDetailHeading.Name = "lblCompDetailHeading";
            lblCompDetailHeading.TabIndex = 0;
            lblCompDetailHeading.Text = "Details";
            // 
            // txtCompDetails
            // 
            txtCompDetails.BackColor = Color.White;
            txtCompDetails.Font = new Font("Segoe UI", 10F);
            txtCompDetails.Location = new Point(14, 46);
            txtCompDetails.Multiline = true;
            txtCompDetails.Name = "txtCompDetails";
            txtCompDetails.ReadOnly = true;
            txtCompDetails.Size = new Size(330, 170);
            txtCompDetails.TabIndex = 1;
            // 
            // btnStartReview
            // 
            btnStartReview.BackColor = Color.White;
            btnStartReview.Cursor = Cursors.Hand;
            btnStartReview.FlatAppearance.BorderColor = Color.FromArgb(30, 90, 60);
            btnStartReview.FlatStyle = FlatStyle.Flat;
            btnStartReview.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnStartReview.ForeColor = Color.FromArgb(30, 90, 60);
            btnStartReview.Location = new Point(14, 228);
            btnStartReview.Name = "btnStartReview";
            btnStartReview.Size = new Size(330, 40);
            btnStartReview.TabIndex = 2;
            btnStartReview.Text = "Start review";
            btnStartReview.UseVisualStyleBackColor = false;
            btnStartReview.Click += btnStartReview_Click;
            // 
            // lblReply
            // 
            lblReply.AutoSize = true;
            lblReply.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblReply.ForeColor = Color.FromArgb(22, 32, 26);
            lblReply.Location = new Point(14, 284);
            lblReply.Name = "lblReply";
            lblReply.TabIndex = 3;
            lblReply.Text = "Reply to the resident";
            // 
            // txtReply
            // 
            txtReply.Font = new Font("Segoe UI", 10F);
            txtReply.Location = new Point(14, 310);
            txtReply.Multiline = true;
            txtReply.Name = "txtReply";
            txtReply.Size = new Size(330, 150);
            txtReply.TabIndex = 4;
            // 
            // btnResolve
            // 
            btnResolve.BackColor = Color.FromArgb(30, 90, 60);
            btnResolve.Cursor = Cursors.Hand;
            btnResolve.FlatAppearance.BorderSize = 0;
            btnResolve.FlatStyle = FlatStyle.Flat;
            btnResolve.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnResolve.ForeColor = Color.White;
            btnResolve.Location = new Point(14, 474);
            btnResolve.Name = "btnResolve";
            btnResolve.Size = new Size(330, 44);
            btnResolve.TabIndex = 5;
            btnResolve.Text = "Resolve";
            btnResolve.UseVisualStyleBackColor = false;
            btnResolve.Click += btnResolve_Click;
            // 
            // lblReportsTitle
            // 
            lblReportsTitle.AutoSize = true;
            lblReportsTitle.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            lblReportsTitle.ForeColor = Color.FromArgb(22, 32, 26);
            lblReportsTitle.Location = new Point(20, 14);
            lblReportsTitle.Name = "lblReportsTitle";
            lblReportsTitle.TabIndex = 0;
            lblReportsTitle.Text = "Reports";
            // 
            // cboReportType
            // 
            cboReportType.DropDownStyle = ComboBoxStyle.DropDownList;
            cboReportType.Font = new Font("Segoe UI", 10.5F);
            cboReportType.FormattingEnabled = true;
            cboReportType.Items.AddRange(new object[] { "Daily collection report", "Missed collections", "Recycling statistics", "Vehicle usage" });
            cboReportType.Location = new Point(20, 62);
            cboReportType.Name = "cboReportType";
            cboReportType.Size = new Size(270, 32);
            cboReportType.TabIndex = 1;
            // 
            // dtpReportDate
            // 
            dtpReportDate.Font = new Font("Segoe UI", 10.5F);
            dtpReportDate.Location = new Point(304, 62);
            dtpReportDate.Name = "dtpReportDate";
            dtpReportDate.Size = new Size(240, 32);
            dtpReportDate.TabIndex = 2;
            // 
            // btnRunReport
            // 
            btnRunReport.BackColor = Color.FromArgb(30, 90, 60);
            btnRunReport.Cursor = Cursors.Hand;
            btnRunReport.FlatAppearance.BorderSize = 0;
            btnRunReport.FlatStyle = FlatStyle.Flat;
            btnRunReport.Font = new Font("Segoe UI", 10.5F, FontStyle.Bold);
            btnRunReport.ForeColor = Color.White;
            btnRunReport.Location = new Point(560, 59);
            btnRunReport.Name = "btnRunReport";
            btnRunReport.Size = new Size(150, 38);
            btnRunReport.TabIndex = 3;
            btnRunReport.Text = "Run report";
            btnRunReport.UseVisualStyleBackColor = false;
            btnRunReport.Click += btnRunReport_Click;
            // 
            // btnExportReport
            // 
            btnExportReport.BackColor = Color.White;
            btnExportReport.Cursor = Cursors.Hand;
            btnExportReport.FlatAppearance.BorderColor = Color.FromArgb(30, 90, 60);
            btnExportReport.FlatStyle = FlatStyle.Flat;
            btnExportReport.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnExportReport.ForeColor = Color.FromArgb(30, 90, 60);
            btnExportReport.Location = new Point(720, 59);
            btnExportReport.Name = "btnExportReport";
            btnExportReport.Size = new Size(180, 38);
            btnExportReport.TabIndex = 4;
            btnExportReport.Text = "Export to .txt";
            btnExportReport.UseVisualStyleBackColor = false;
            btnExportReport.Click += btnExportReport_Click;
            // 
            // txtReport
            // 
            txtReport.BackColor = Color.White;
            txtReport.Font = new Font("Consolas", 10.5F);
            txtReport.Location = new Point(20, 110);
            txtReport.Multiline = true;
            txtReport.Name = "txtReport";
            txtReport.ReadOnly = true;
            txtReport.ScrollBars = ScrollBars.Vertical;
            txtReport.Size = new Size(1000, 570);
            txtReport.TabIndex = 5;
            // 
            // AdminForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(243, 244, 239);
            ClientSize = new Size(1280, 760);
            MinimumSize = new Size(1296, 799);
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Smart Waste - Administration";
            Controls.Add(tabMain);
            Controls.Add(pnlSidebar);
            Name = "AdminForm";
            Load += AdminForm_Load;
            ((System.ComponentModel.ISupportInitialize)dgvComplaints).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvRecycling).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvStaff).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvVehicles).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudCapacity).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvCollections).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvResidents).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvToday).EndInit();
            ((System.ComponentModel.ISupportInitialize)picLogo).EndInit();
            pnlCompDetail.ResumeLayout(false);
            pnlCompDetail.PerformLayout();
            pnlAddStaff.ResumeLayout(false);
            pnlAddStaff.PerformLayout();
            pnlAddVehicle.ResumeLayout(false);
            pnlAddVehicle.PerformLayout();
            pnlAssign.ResumeLayout(false);
            pnlAssign.PerformLayout();
            pnlSchedule.ResumeLayout(false);
            pnlSchedule.PerformLayout();
            pnlChart.ResumeLayout(false);
            pnlChart.PerformLayout();
            pnlKpi4.ResumeLayout(false);
            pnlKpi4.PerformLayout();
            pnlKpi3.ResumeLayout(false);
            pnlKpi3.PerformLayout();
            pnlKpi2.ResumeLayout(false);
            pnlKpi2.PerformLayout();
            pnlKpi1.ResumeLayout(false);
            pnlKpi1.PerformLayout();
            tabReports.ResumeLayout(false);
            tabReports.PerformLayout();
            tabComplaints.ResumeLayout(false);
            tabComplaints.PerformLayout();
            tabRecycling.ResumeLayout(false);
            tabRecycling.PerformLayout();
            tabFleet.ResumeLayout(false);
            tabFleet.PerformLayout();
            tabCollections.ResumeLayout(false);
            tabCollections.PerformLayout();
            tabResidents.ResumeLayout(false);
            tabResidents.PerformLayout();
            tabDashboard.ResumeLayout(false);
            tabDashboard.PerformLayout();
            pnlSidebar.ResumeLayout(false);
            pnlSidebar.PerformLayout();
            tabMain.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabMain;
        private Panel pnlSidebar;
        private PictureBox picLogo;
        private Label lblAppName;
        private Label lblRole;
        private Button btnNavDashboard;
        private Button btnNavResidents;
        private Button btnNavCollections;
        private Button btnNavFleet;
        private Button btnNavRecycling;
        private Button btnNavComplaints;
        private Button btnNavReports;
        private Label lblHello;
        private Button btnSignOut;
        private TabPage tabDashboard;
        private TabPage tabResidents;
        private TabPage tabCollections;
        private TabPage tabFleet;
        private TabPage tabRecycling;
        private TabPage tabComplaints;
        private TabPage tabReports;
        private Label lblDashTitle;
        private Label lblDashDate;
        private Panel pnlKpi1;
        private Label lblKpi1Title;
        private Label lblKpi1Value;
        private Panel pnlKpi2;
        private Label lblKpi2Title;
        private Label lblKpi2Value;
        private Panel pnlKpi3;
        private Label lblKpi3Title;
        private Label lblKpi3Value;
        private Panel pnlKpi4;
        private Label lblKpi4Title;
        private Label lblKpi4Value;
        private Panel pnlChart;
        private Label lblTodayTitle;
        private DataGridView dgvToday;
        private Label lblResidentsTitle;
        private TextBox txtSearchResident;
        private Button btnSearchResident;
        private Button btnShowAllResidents;
        private DataGridView dgvResidents;
        private Label lblResidentAddressesTitle;
        private ListBox lstResidentAddresses;
        private Label lblCollectionsTitle;
        private Panel pnlSchedule;
        private Label lblScheduleHeading;
        private Label lblSchResident;
        private ComboBox cboSchResident;
        private Label lblSchAddress;
        private ComboBox cboSchAddress;
        private Label lblSchType;
        private ComboBox cboSchType;
        private Label lblSchDate;
        private DateTimePicker dtpSchDate;
        private Button btnSchedule;
        private Panel pnlAssign;
        private Label lblAssignHeading;
        private Label lblDriver;
        private ComboBox cboDriver;
        private Label lblVehicle;
        private ComboBox cboVehicle;
        private Button btnAssign;
        private Button btnCancelSelectedCollection;
        private Button btnTrackDriver;
        private Label lblStatusFilter;
        private ComboBox cboStatusFilter;
        private TextBox txtSearchCollection;
        private DataGridView dgvCollections;
        private Label lblFleetTitle;
        private Panel pnlAddVehicle;
        private Label lblAddVehicleHeading;
        private Label lblRegistration;
        private TextBox txtRegistration;
        private Label lblVehicleType;
        private ComboBox cboVehicleType;
        private Label lblCapacity;
        private NumericUpDown nudCapacity;
        private Button btnAddVehicle;
        private DataGridView dgvVehicles;
        private Button btnMaintenance;
        private Button btnAvailable;
        private Panel pnlAddStaff;
        private Label lblAddStaffHeading;
        private Label lblStaffName;
        private TextBox txtStaffName;
        private Label lblStaffUsername;
        private TextBox txtStaffUsername;
        private Label lblStaffPasswordNote;
        private Button btnAddStaff;
        private Label lblStaffTitle;
        private DataGridView dgvStaff;
        private Label lblStaffVehicle;
        private ComboBox cboStaffVehicle;
        private Button btnGiveVehicle;
        private Button btnToggleDuty;
        private Label lblRecyclingTitle;
        private Label lblRecFilter;
        private ComboBox cboRecFilter;
        private DataGridView dgvRecycling;
        private Button btnApprove;
        private Label lblRejectReason;
        private TextBox txtRejectReason;
        private Button btnReject;
        private Label lblComplaintsTitle;
        private Label lblCompFilter;
        private ComboBox cboCompFilter;
        private DataGridView dgvComplaints;
        private Panel pnlCompDetail;
        private Label lblCompDetailHeading;
        private TextBox txtCompDetails;
        private Button btnStartReview;
        private Label lblReply;
        private TextBox txtReply;
        private Button btnResolve;
        private Label lblReportsTitle;
        private ComboBox cboReportType;
        private DateTimePicker dtpReportDate;
        private Button btnRunReport;
        private Button btnExportReport;
        private TextBox txtReport;
    }
}
