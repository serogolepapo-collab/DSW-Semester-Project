using System.Globalization;
using System.Net.Http;
using System.Text.Json;

namespace DSW_Semester_Project
{
    // A map position.
    public record struct GeoPoint(double Lat, double Lon);

    // Turns an address into coordinates with the free Nominatim service (no API key needed).
    // Used when the map has to show several addresses at once (the admin's driver tracking map).
    // - Results are remembered, so each address is only looked up once while the app is open.
    // - Nominatim allows about one request per second, so the calls are spaced out.
    public static class Geocoder
    {
        private static readonly HttpClient Http = CreateClient();
        private static readonly Dictionary<string, GeoPoint?> Cache = new Dictionary<string, GeoPoint?>();
        private static DateTime _lastCall = DateTime.MinValue;

        private static HttpClient CreateClient()
        {
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.UserAgent.ParseAdd("DSW-Semester-Project/1.0 (student project)");
            client.Timeout = TimeSpan.FromSeconds(15);
            return client;
        }

        // Returns null when the address can't be found. Throws if the internet is not reachable.
        public static async Task<GeoPoint?> FindAsync(string address)
        {
            if (Cache.TryGetValue(address, out GeoPoint? cached)) return cached;

            // Full address first, then a looser search (suburb + city + postal code)
            string[] parts = address.Split(',');
            List<string> attempts = new List<string> { address };
            if (parts.Length > 1)
                attempts.Add(string.Join(",", parts.Skip(1)).Trim());

            foreach (string attempt in attempts)
            {
                await WaitForTurn();

                string url = "https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=za&q=" +
                             Uri.EscapeDataString(attempt);
                string json = await Http.GetStringAsync(url);

                using (JsonDocument doc = JsonDocument.Parse(json))
                {
                    JsonElement list = doc.RootElement;
                    if (list.GetArrayLength() == 0) continue;

                    JsonElement first = list[0];
                    GeoPoint point = new GeoPoint(
                        double.Parse(first.GetProperty("lat").GetString(), CultureInfo.InvariantCulture),
                        double.Parse(first.GetProperty("lon").GetString(), CultureInfo.InvariantCulture));
                    Cache[address] = point;
                    return point;
                }
            }

            Cache[address] = null;   // looked everywhere and found nothing
            return null;
        }

        // Waits until at least 1.1 seconds have passed since the last request
        private static async Task WaitForTurn()
        {
            double wait = 1100 - (DateTime.UtcNow - _lastCall).TotalMilliseconds;
            if (wait > 0) await Task.Delay((int)wait);
            _lastCall = DateTime.UtcNow;
        }
    }
}
