# Smart Waste Collection & Recycling (C# WinForms, .NET 10)

## How to run

1. Open `DSW Semester Project.sln` in Visual Studio.
2. Press **F5**.

The first run creates demo data in `bin\Debug\net10.0-windows\*.txt`:

| Role | Username | Password |
|---|---|---|
| Resident | `michael` | `Resident@123` |
| Administrator | `admin` (or any new name) | `Admin@123` |
| Collection staff | `thabo` (or any new name) | `Staff@123` |

To start with empty data, delete the `.txt` files in that folder.

## Folders

- **Models**
  - `User` is the parent class, with `Resident`, `StaffMember` and `Administrator` as its children.
  - The other models are `Address`, `WasteCollection`, `RecyclingRequest`, `Complaint`, `Vehicle` and the status enums.
- **Data**
  - `DataStore` reads and writes the `.txt` files.
  - `AccountManager` handles login and registration.
  - `Validator` checks passwords, emails, phone numbers and postal codes.
  - `SampleData` holds the demo records.
  - `Theme` has the shared colours and grid styling.
  - `Geocoder` turns an address into map coordinates (OpenStreetMap Nominatim) and remembers the results.
- **Forms**
  - `LoginForm` and `RegisterForm` are the sign-in screens.
  - `ResidentForm`, `AdminForm` and `StaffForm` are the three dashboards.
  - `MissedReasonForm` is the pop-up that asks staff why a collection was missed.
  - `MapForm` shows one address on a map (staff). `DriverMapForm` shows all of a driver's stops for a day, with the current stop highlighted (admin: Collections page > **Track driver**).
  - Every form has a `.Designer.cs` file, so you can open it in the designer.

## UML (inheritance)

```
                 User
  - _username, _password
  + Username, Password, FullName, Email, Phone
  + CheckPassword()
  + virtual GetRole(), OpenDashboard(), ToFileLine()
        ^              ^                 ^
        |              |                 |
    Resident      StaffMember       Administrator
                  + IsOnDuty
  (each one overrides GetRole() and OpenDashboard())
```

## Where each OOP idea is

| Idea | Where |
|---|---|
| Encapsulation | Private fields with validating properties: `User.Password`, `Address.PostalCode`, `Vehicle.CapacityTons`, `RecyclingRequest.Bags`, `Complaint.Description` |
| Abstraction | `WasteCollection.Assign()`, `Start()`, `Complete()`, `MarkMissed()`, `Cancel()`, and `Complaint.Resolve()` |
| Inheritance | `Resident : User`, `StaffMember : User`, `Administrator : User` |
| Polymorphism | `user.OpenDashboard()` in `LoginForm` opens a different screen for each role |
| Constructors | Default and parameterised constructors in `User`, and `base(...)` in the child classes |
| Text files | `DataStore`: `File.Exists`, `ReadAllLines`, `WriteAllLines`, `Split('|')`, try-catch |
