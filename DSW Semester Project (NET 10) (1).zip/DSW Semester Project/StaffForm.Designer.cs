namespace DSW_Semester_Project
{
    partial class StaffForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabMain = new TabControl();
            pnlSidebar = new Panel();
            picLogo = new PictureBox();
            lblAppName = new Label();
            lblRole = new Label();
            btnNavJobs = new Button();
            btnNavHistory = new Button();
            lblHello = new Label();
            btnSignOut = new Button();
            tabJobs = new TabPage();
            tabHistory = new TabPage();
            lblJobsTitle = new Label();
            lblJobsSummary = new Label();
            dgvJobs = new DataGridView();
            pnlJob = new Panel();
            lblJobHeading = new Label();
            lblJobAddress = new Label();
            lblJobInfo = new Label();
            lblJobStatus = new Label();
            btnStartJob = new Button();
            btnCompleteJob = new Button();
            btnMissedJob = new Button();
            lblJobHelp = new Label();
            lblHistoryTitle = new Label();
            lblHistorySummary = new Label();
            dgvHistory = new DataGridView();
            tabMain.SuspendLayout();
            pnlSidebar.SuspendLayout();
            tabJobs.SuspendLayout();
            tabHistory.SuspendLayout();
            pnlJob.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)picLogo).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvJobs).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvHistory).BeginInit();
            SuspendLayout();
            // 
            // tabMain
            // 
            tabMain.Controls.Add(tabJobs);
            tabMain.Controls.Add(tabHistory);
            tabMain.Dock = DockStyle.Fill;
            tabMain.Font = new Font("Segoe UI", 10F);
            tabMain.Name = "tabMain";
            tabMain.SelectedIndex = 0;
            tabMain.TabIndex = 0;
            tabMain.SelectedIndexChanged += tabMain_SelectedIndexChanged;
            // 
            // pnlSidebar
            // 
            pnlSidebar.Controls.Add(picLogo);
            pnlSidebar.Controls.Add(lblAppName);
            pnlSidebar.Controls.Add(lblRole);
            pnlSidebar.Controls.Add(btnNavJobs);
            pnlSidebar.Controls.Add(btnNavHistory);
            pnlSidebar.Controls.Add(lblHello);
            pnlSidebar.Controls.Add(btnSignOut);
            pnlSidebar.BackColor = Color.FromArgb(18, 53, 36);
            pnlSidebar.Dock = DockStyle.Left;
            pnlSidebar.Name = "pnlSidebar";
            pnlSidebar.Size = new Size(230, 760);
            pnlSidebar.TabIndex = 1;
            // 
            // picLogo
            // 
            picLogo.Image = Properties.Resources.logo_white;
            picLogo.Location = new Point(20, 22);
            picLogo.Name = "picLogo";
            picLogo.Size = new Size(46, 52);
            picLogo.SizeMode = PictureBoxSizeMode.Zoom;
            picLogo.TabIndex = 0;
            picLogo.TabStop = false;
            // 
            // lblAppName
            // 
            lblAppName.AutoSize = true;
            lblAppName.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            lblAppName.ForeColor = Color.White;
            lblAppName.Location = new Point(72, 24);
            lblAppName.Name = "lblAppName";
            lblAppName.TabIndex = 1;
            lblAppName.Text = "Smart Waste";
            // 
            // lblRole
            // 
            lblRole.AutoSize = true;
            lblRole.Font = new Font("Segoe UI", 9.5F);
            lblRole.ForeColor = Color.FromArgb(158, 208, 174);
            lblRole.Location = new Point(74, 54);
            lblRole.Name = "lblRole";
            lblRole.TabIndex = 2;
            lblRole.Text = "Collection staff";
            // 
            // btnNavJobs
            // 
            btnNavJobs.BackColor = Color.FromArgb(18, 53, 36);
            btnNavJobs.Cursor = Cursors.Hand;
            btnNavJobs.FlatAppearance.BorderSize = 0;
            btnNavJobs.FlatAppearance.MouseOverBackColor = Color.FromArgb(30, 90, 60);
            btnNavJobs.FlatStyle = FlatStyle.Flat;
            btnNavJobs.Font = new Font("Segoe UI", 11F);
            btnNavJobs.ForeColor = Color.White;
            btnNavJobs.Location = new Point(0, 120);
            btnNavJobs.Name = "btnNavJobs";
            btnNavJobs.Padding = new Padding(24, 0, 0, 0);
            btnNavJobs.Size = new Size(230, 46);
            btnNavJobs.TabIndex = 3;
            btnNavJobs.Text = "My jobs";
            btnNavJobs.TextAlign = ContentAlignment.MiddleLeft;
            btnNavJobs.UseVisualStyleBackColor = false;
            btnNavJobs.Click += btnNavJobs_Click;
            // 
            // btnNavHistory
            // 
            btnNavHistory.BackColor = Color.FromArgb(18, 53, 36);
            btnNavHistory.Cursor = Cursors.Hand;
            btnNavHistory.FlatAppearance.BorderSize = 0;
            btnNavHistory.FlatAppearance.MouseOverBackColor = Color.FromArgb(30, 90, 60);
            btnNavHistory.FlatStyle = FlatStyle.Flat;
            btnNavHistory.Font = new Font("Segoe UI", 11F);
            btnNavHistory.ForeColor = Color.White;
            btnNavHistory.Location = new Point(0, 170);
            btnNavHistory.Name = "btnNavHistory";
            btnNavHistory.Padding = new Padding(24, 0, 0, 0);
            btnNavHistory.Size = new Size(230, 46);
            btnNavHistory.TabIndex = 4;
            btnNavHistory.Text = "Job history";
            btnNavHistory.TextAlign = ContentAlignment.MiddleLeft;
            btnNavHistory.UseVisualStyleBackColor = false;
            btnNavHistory.Click += btnNavHistory_Click;
            // 
            // lblHello
            // 
            lblHello.AutoSize = true;
            lblHello.Font = new Font("Segoe UI", 10F);
            lblHello.ForeColor = Color.White;
            lblHello.Location = new Point(22, 646);
            lblHello.Name = "lblHello";
            lblHello.TabIndex = 5;
            lblHello.Text = "Hello, name";
            // 
            // btnSignOut
            // 
            btnSignOut.BackColor = Color.FromArgb(18, 53, 36);
            btnSignOut.Cursor = Cursors.Hand;
            btnSignOut.FlatAppearance.BorderColor = Color.FromArgb(158, 208, 174);
            btnSignOut.FlatStyle = FlatStyle.Flat;
            btnSignOut.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnSignOut.ForeColor = Color.White;
            btnSignOut.Location = new Point(22, 680);
            btnSignOut.Name = "btnSignOut";
            btnSignOut.Size = new Size(186, 40);
            btnSignOut.TabIndex = 6;
            btnSignOut.Text = "Sign out";
            btnSignOut.UseVisualStyleBackColor = false;
            btnSignOut.Click += btnSignOut_Click;
            // 
            // tabJobs
            // 
            tabJobs.Controls.Add(lblJobsTitle);
            tabJobs.Controls.Add(lblJobsSummary);
            tabJobs.Controls.Add(dgvJobs);
            tabJobs.Controls.Add(pnlJob);
            tabJobs.BackColor = Color.FromArgb(243, 244, 239);
            tabJobs.Location = new Point(4, 32);
            tabJobs.Name = "tabJobs";
            tabJobs.Padding = new Padding(3);
            tabJobs.Size = new Size(1042, 724);
            tabJobs.Text = "My jobs";
            // 
            // tabHistory
            // 
            tabHistory.Controls.Add(lblHistoryTitle);
            tabHistory.Controls.Add(lblHistorySummary);
            tabHistory.Controls.Add(dgvHistory);
            tabHistory.BackColor = Color.FromArgb(243, 244, 239);
            tabHistory.Location = new Point(4, 32);
            tabHistory.Name = "tabHistory";
            tabHistory.Padding = new Padding(3);
            tabHistory.Size = new Size(1042, 724);
            tabHistory.Text = "Job history";
            // 
            // lblJobsTitle
            // 
            lblJobsTitle.AutoSize = true;
            lblJobsTitle.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            lblJobsTitle.ForeColor = Color.FromArgb(22, 32, 26);
            lblJobsTitle.Location = new Point(20, 14);
            lblJobsTitle.Name = "lblJobsTitle";
            lblJobsTitle.TabIndex = 0;
            lblJobsTitle.Text = "My jobs";
            // 
            // lblJobsSummary
            // 
            lblJobsSummary.AutoSize = true;
            lblJobsSummary.Font = new Font("Segoe UI", 10F);
            lblJobsSummary.ForeColor = Color.FromArgb(95, 107, 99);
            lblJobsSummary.Location = new Point(23, 54);
            lblJobsSummary.Name = "lblJobsSummary";
            lblJobsSummary.TabIndex = 1;
            lblJobsSummary.Text = "0 of 0 stops done";
            // 
            // dgvJobs
            // 
            dgvJobs.AllowUserToAddRows = false;
            dgvJobs.AllowUserToDeleteRows = false;
            dgvJobs.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvJobs.BackgroundColor = Color.White;
            dgvJobs.BorderStyle = BorderStyle.None;
            dgvJobs.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvJobs.Location = new Point(20, 90);
            dgvJobs.MultiSelect = false;
            dgvJobs.Name = "dgvJobs";
            dgvJobs.ReadOnly = true;
            dgvJobs.RowHeadersVisible = false;
            dgvJobs.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvJobs.Size = new Size(600, 590);
            dgvJobs.TabIndex = 4;
            dgvJobs.SelectionChanged += dgvJobs_SelectionChanged;
            // 
            // pnlJob
            // 
            pnlJob.Controls.Add(lblJobHeading);
            pnlJob.Controls.Add(lblJobAddress);
            pnlJob.Controls.Add(lblJobInfo);
            pnlJob.Controls.Add(lblJobStatus);
            pnlJob.Controls.Add(btnStartJob);
            pnlJob.Controls.Add(btnCompleteJob);
            pnlJob.Controls.Add(btnMissedJob);
            pnlJob.Controls.Add(lblJobHelp);
            pnlJob.BackColor = Color.White;
            pnlJob.BorderStyle = BorderStyle.FixedSingle;
            pnlJob.Location = new Point(640, 90);
            pnlJob.Name = "pnlJob";
            pnlJob.Size = new Size(380, 590);
            pnlJob.TabIndex = 5;
            // 
            // lblJobHeading
            // 
            lblJobHeading.AutoSize = true;
            lblJobHeading.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblJobHeading.ForeColor = Color.FromArgb(30, 90, 60);
            lblJobHeading.Location = new Point(16, 14);
            lblJobHeading.Name = "lblJobHeading";
            lblJobHeading.TabIndex = 0;
            lblJobHeading.Text = "SELECTED JOB";
            // 
            // lblJobAddress
            // 
            lblJobAddress.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            lblJobAddress.ForeColor = Color.FromArgb(22, 32, 26);
            lblJobAddress.Location = new Point(16, 40);
            lblJobAddress.Name = "lblJobAddress";
            lblJobAddress.Size = new Size(346, 64);
            lblJobAddress.TabIndex = 1;
            lblJobAddress.Text = "Select a job";
            // 
            // lblJobInfo
            // 
            lblJobInfo.Font = new Font("Segoe UI", 10.5F);
            lblJobInfo.ForeColor = Color.FromArgb(95, 107, 99);
            lblJobInfo.Location = new Point(16, 108);
            lblJobInfo.Name = "lblJobInfo";
            lblJobInfo.Size = new Size(346, 130);
            lblJobInfo.TabIndex = 2;
            lblJobInfo.Text = "";
            // 
            // lblJobStatus
            // 
            lblJobStatus.AutoSize = true;
            lblJobStatus.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblJobStatus.ForeColor = Color.FromArgb(30, 90, 60);
            lblJobStatus.Location = new Point(16, 244);
            lblJobStatus.Name = "lblJobStatus";
            lblJobStatus.TabIndex = 3;
            lblJobStatus.Text = "Status: -";
            // 
            // btnStartJob
            // 
            btnStartJob.BackColor = Color.FromArgb(30, 90, 60);
            btnStartJob.Cursor = Cursors.Hand;
            btnStartJob.FlatAppearance.BorderSize = 0;
            btnStartJob.FlatStyle = FlatStyle.Flat;
            btnStartJob.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnStartJob.ForeColor = Color.White;
            btnStartJob.Location = new Point(16, 284);
            btnStartJob.Name = "btnStartJob";
            btnStartJob.Size = new Size(346, 48);
            btnStartJob.TabIndex = 4;
            btnStartJob.Text = "Start job";
            btnStartJob.UseVisualStyleBackColor = false;
            btnStartJob.Click += btnStartJob_Click;
            // 
            // btnCompleteJob
            // 
            btnCompleteJob.BackColor = Color.FromArgb(30, 90, 60);
            btnCompleteJob.Cursor = Cursors.Hand;
            btnCompleteJob.FlatAppearance.BorderSize = 0;
            btnCompleteJob.FlatStyle = FlatStyle.Flat;
            btnCompleteJob.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnCompleteJob.ForeColor = Color.White;
            btnCompleteJob.Location = new Point(16, 342);
            btnCompleteJob.Name = "btnCompleteJob";
            btnCompleteJob.Size = new Size(346, 48);
            btnCompleteJob.TabIndex = 5;
            btnCompleteJob.Text = "Mark completed";
            btnCompleteJob.UseVisualStyleBackColor = false;
            btnCompleteJob.Click += btnCompleteJob_Click;
            // 
            // btnMissedJob
            // 
            btnMissedJob.BackColor = Color.White;
            btnMissedJob.Cursor = Cursors.Hand;
            btnMissedJob.FlatAppearance.BorderColor = Color.FromArgb(163, 33, 22);
            btnMissedJob.FlatStyle = FlatStyle.Flat;
            btnMissedJob.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnMissedJob.ForeColor = Color.FromArgb(163, 33, 22);
            btnMissedJob.Location = new Point(16, 400);
            btnMissedJob.Name = "btnMissedJob";
            btnMissedJob.Size = new Size(346, 48);
            btnMissedJob.TabIndex = 6;
            btnMissedJob.Text = "Couldn't collect";
            btnMissedJob.UseVisualStyleBackColor = false;
            btnMissedJob.Click += btnMissedJob_Click;
            // 
            // lblJobHelp
            // 
            lblJobHelp.Font = new Font("Segoe UI", 9.5F);
            lblJobHelp.ForeColor = Color.FromArgb(95, 107, 99);
            lblJobHelp.Location = new Point(16, 466);
            lblJobHelp.Name = "lblJobHelp";
            lblJobHelp.Size = new Size(346, 100);
            lblJobHelp.TabIndex = 7;
            lblJobHelp.Text = "Select a job on the left. Press Start job when you arrive, then Mark completed. If you can't collect, press Couldn't collect and pick a reason.";
            // 
            // lblHistoryTitle
            // 
            lblHistoryTitle.AutoSize = true;
            lblHistoryTitle.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            lblHistoryTitle.ForeColor = Color.FromArgb(22, 32, 26);
            lblHistoryTitle.Location = new Point(20, 14);
            lblHistoryTitle.Name = "lblHistoryTitle";
            lblHistoryTitle.TabIndex = 0;
            lblHistoryTitle.Text = "Job history";
            // 
            // lblHistorySummary
            // 
            lblHistorySummary.AutoSize = true;
            lblHistorySummary.Font = new Font("Segoe UI", 10F);
            lblHistorySummary.ForeColor = Color.FromArgb(95, 107, 99);
            lblHistorySummary.Location = new Point(23, 54);
            lblHistorySummary.Name = "lblHistorySummary";
            lblHistorySummary.TabIndex = 1;
            lblHistorySummary.Text = "";
            // 
            // dgvHistory
            // 
            dgvHistory.AllowUserToAddRows = false;
            dgvHistory.AllowUserToDeleteRows = false;
            dgvHistory.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvHistory.BackgroundColor = Color.White;
            dgvHistory.BorderStyle = BorderStyle.None;
            dgvHistory.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvHistory.Location = new Point(20, 90);
            dgvHistory.MultiSelect = false;
            dgvHistory.Name = "dgvHistory";
            dgvHistory.ReadOnly = true;
            dgvHistory.RowHeadersVisible = false;
            dgvHistory.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvHistory.Size = new Size(1000, 590);
            dgvHistory.TabIndex = 2;
            // 
            // StaffForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(243, 244, 239);
            ClientSize = new Size(1280, 760);
            MinimumSize = new Size(1296, 799);
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Smart Waste - Collection staff";
            Controls.Add(tabMain);
            Controls.Add(pnlSidebar);
            Name = "StaffForm";
            Load += StaffForm_Load;
            ((System.ComponentModel.ISupportInitialize)dgvHistory).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvJobs).EndInit();
            ((System.ComponentModel.ISupportInitialize)picLogo).EndInit();
            pnlJob.ResumeLayout(false);
            pnlJob.PerformLayout();
            tabHistory.ResumeLayout(false);
            tabHistory.PerformLayout();
            tabJobs.ResumeLayout(false);
            tabJobs.PerformLayout();
            pnlSidebar.ResumeLayout(false);
            pnlSidebar.PerformLayout();
            tabMain.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabMain;
        private Panel pnlSidebar;
        private PictureBox picLogo;
        private Label lblAppName;
        private Label lblRole;
        private Button btnNavJobs;
        private Button btnNavHistory;
        private Label lblHello;
        private Button btnSignOut;
        private TabPage tabJobs;
        private TabPage tabHistory;
        private Label lblJobsTitle;
        private Label lblJobsSummary;
        private DataGridView dgvJobs;
        private Panel pnlJob;
        private Label lblJobHeading;
        private Label lblJobAddress;
        private Label lblJobInfo;
        private Label lblJobStatus;
        private Button btnStartJob;
        private Button btnCompleteJob;
        private Button btnMissedJob;
        private Label lblJobHelp;
        private Label lblHistoryTitle;
        private Label lblHistorySummary;
        private DataGridView dgvHistory;
    }
}
