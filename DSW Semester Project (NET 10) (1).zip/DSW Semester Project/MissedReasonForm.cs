namespace DSW_Semester_Project
{
    // Small pop-up the driver sees when a pickup can't be done
    public partial class MissedReasonForm : Form
    {
        public string Reason { get; private set; } = "";

        public MissedReasonForm()
        {
            InitializeComponent();
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            if (cboReason.SelectedIndex == -1)
            {
                Theme.ShowError("Choose a reason.");
                return;
            }
            Reason = cboReason.Text;
            DialogResult = DialogResult.OK;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
    }
}
