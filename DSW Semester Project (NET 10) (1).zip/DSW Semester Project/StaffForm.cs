namespace DSW_Semester_Project
{
    // Collection staff see every job the admin assigned to them, and update it: Start -> Completed (or Missed).
    public partial class StaffForm : Form
    {
        private readonly StaffMember _staff;

        public StaffForm(StaffMember staff)
        {
            InitializeComponent();
            _staff = staff;
        }

        private void StaffForm_Load(object sender, EventArgs e)
        {
            lblHello.Text = "Hello, " + _staff.FullName;
            RefreshJobs();
            Theme.HighlightMenu(pnlSidebar, btnNavJobs);
        }

        // ---------------- menu ----------------

        private void btnNavJobs_Click(object sender, EventArgs e)
        {
            tabMain.SelectedTab = tabJobs;
            Theme.HighlightMenu(pnlSidebar, btnNavJobs);
        }

        private void btnNavHistory_Click(object sender, EventArgs e)
        {
            tabMain.SelectedTab = tabHistory;
            Theme.HighlightMenu(pnlSidebar, btnNavHistory);
        }

        private void tabMain_SelectedIndexChanged(object sender, EventArgs e)
        {
            RefreshJobs();
        }

        private void btnSignOut_Click(object sender, EventArgs e)
        {
            Close();
        }

        // ---------------- my jobs ----------------

        private void RefreshJobs()
        {
            List<WasteCollection> jobs = new List<WasteCollection>();      // still to do (any date)
            List<WasteCollection> history = new List<WasteCollection>();   // finished

            foreach (WasteCollection c in DataStore.Collections)
            {
                // Only this driver's jobs (ToLower so "Thabo" and "thabo" match)
                if (c.DriverUsername.ToLower() != _staff.Username.ToLower()) continue;

                if (c.Status == CollectionStatus.Assigned || c.Status == CollectionStatus.InProgress)
                    jobs.Add(c);
                else if (c.Status == CollectionStatus.Completed || c.Status == CollectionStatus.Missed)
                    history.Add(c);
            }

            lblJobsSummary.Text = jobs.Count == 0
                ? "No jobs assigned to you yet."
                : $"{jobs.Count} job(s) to do";
            Theme.ShowList(dgvJobs, jobs, "ResidentUsername", "DriverUsername", "RequestId", "Notes");
            Theme.ShowList(dgvHistory, history, "DriverUsername", "RequestId");
            lblHistorySummary.Text = $"{history.Count} finished job(s)";
            ShowSelectedJob();
        }

        private WasteCollection SelectedJob()
        {
            if (dgvJobs.CurrentRow == null) return null;
            return (WasteCollection)dgvJobs.CurrentRow.DataBoundItem;
        }

        private void dgvJobs_SelectionChanged(object sender, EventArgs e)
        {
            ShowSelectedJob();
        }

        // Shows the details of the selected job and only the buttons that make sense for its status
        private void ShowSelectedJob()
        {
            WasteCollection job = SelectedJob();
            if (job == null)
            {
                lblJobAddress.Text = "Select a job";
                lblJobInfo.Text = "";
                lblJobStatus.Text = "";
                btnStartJob.Enabled = btnCompleteJob.Enabled = btnMissedJob.Enabled = false;
                return;
            }

            User resident = DataStore.FindUser(job.ResidentUsername);
            string name = resident == null ? job.ResidentUsername : resident.FullName;
            string phone = resident == null ? "" : resident.Phone;

            lblJobAddress.Text = job.Address;
            lblJobInfo.Text = $"{job.CollectionType}\nResident: {name}  {phone}\nVehicle: {job.VehicleRegistration}\n" +
                              (job.Notes != "" ? "Note: " + job.Notes : "");

            lblJobStatus.Text = "Status: " + job.Status + "   |   Date: " + job.Date.ToString("dd MMM yyyy");
            btnStartJob.Enabled = job.Status == CollectionStatus.Assigned;
            btnCompleteJob.Enabled = job.Status == CollectionStatus.InProgress;
            btnMissedJob.Enabled = job.Status == CollectionStatus.Assigned || job.Status == CollectionStatus.InProgress;
        }

        private void btnStartJob_Click(object sender, EventArgs e)
        {
            UpdateJob("start");
        }

        private void btnCompleteJob_Click(object sender, EventArgs e)
        {
            UpdateJob("complete");
        }

        private void btnMissedJob_Click(object sender, EventArgs e)
        {
            UpdateJob("missed");
        }

        // One place that changes the status, saves and refreshes
        private void UpdateJob(string action)
        {
            WasteCollection job = SelectedJob();
            if (job == null) { Theme.ShowError("Select a job first."); return; }

            try
            {
                if (action == "start")
                {
                    job.Start();
                }
                else if (action == "complete")
                {
                    job.Complete();
                    MarkRecyclingCollected(job);
                }
                else
                {
                    MissedReasonForm reasonForm = new MissedReasonForm();
                    if (reasonForm.ShowDialog() != DialogResult.OK) return;
                    job.MarkMissed(reasonForm.Reason);
                }

                DataStore.SaveAll();
                RefreshJobs();
            }
            catch (Exception ex)
            {
                Theme.ShowError(ex.Message);
            }
        }

        // If the job came from a recycling request, that request is now collected too
        private void MarkRecyclingCollected(WasteCollection job)
        {
            if (job.RequestId == "") return;
            foreach (RecyclingRequest r in DataStore.RecyclingRequests)
            {
                if (r.Id == job.RequestId) r.MarkCollected();
            }
        }
    }
}
