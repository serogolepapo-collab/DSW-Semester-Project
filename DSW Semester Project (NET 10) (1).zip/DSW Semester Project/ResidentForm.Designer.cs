namespace DSW_Semester_Project
{
    partial class ResidentForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabMain = new TabControl();
            pnlSidebar = new Panel();
            picLogo = new PictureBox();
            lblAppName = new Label();
            lblRole = new Label();
            btnNavHome = new Button();
            btnNavCollections = new Button();
            btnNavRecycling = new Button();
            btnNavComplaints = new Button();
            btnNavAddresses = new Button();
            lblHello = new Label();
            btnSignOut = new Button();
            tabHome = new TabPage();
            tabCollections = new TabPage();
            tabRecycling = new TabPage();
            tabComplaints = new TabPage();
            tabAddresses = new TabPage();
            lblHomeTitle = new Label();
            lblHomeDate = new Label();
            pnlNext = new Panel();
            lblNextHeading = new Label();
            lblNextDate = new Label();
            lblNextDetails = new Label();
            lblNextStatus = new Label();
            pnlStatRecycling = new Panel();
            lblStatRecyclingTitle = new Label();
            lblStatRecycling = new Label();
            pnlStatComplaints = new Panel();
            lblStatComplaintsTitle = new Label();
            lblStatComplaints = new Label();
            lblRecentTitle = new Label();
            dgvHomeCollections = new DataGridView();
            lblCollectionsTitle = new Label();
            pnlRequest = new Panel();
            lblRequestHeading = new Label();
            lblRequestHint = new Label();
            lblColType = new Label();
            cboColType = new ComboBox();
            lblColAddress = new Label();
            cboColAddress = new ComboBox();
            lblColDate = new Label();
            dtpColDate = new DateTimePicker();
            lblColNotes = new Label();
            txtColNotes = new TextBox();
            btnRequestCollection = new Button();
            dgvMyCollections = new DataGridView();
            btnCancelCollection = new Button();
            lblRecyclingTitle = new Label();
            pnlRecycle = new Panel();
            lblRecycleHeading = new Label();
            lblRecycleHint = new Label();
            lblRecCategory = new Label();
            cboRecCategory = new ComboBox();
            lblRecBags = new Label();
            nudRecBags = new NumericUpDown();
            lblRecAddress = new Label();
            cboRecAddress = new ComboBox();
            lblRecDate = new Label();
            dtpRecDate = new DateTimePicker();
            btnSubmitRecycling = new Button();
            dgvMyRecycling = new DataGridView();
            lblComplaintsTitle = new Label();
            pnlComplaint = new Panel();
            lblComplaintHeading = new Label();
            lblComplaintHint = new Label();
            lblCompType = new Label();
            cboCompType = new ComboBox();
            lblCompCollection = new Label();
            cboCompCollection = new ComboBox();
            lblCompDescription = new Label();
            txtCompDescription = new TextBox();
            lblCharCount = new Label();
            btnSubmitComplaint = new Button();
            dgvMyComplaints = new DataGridView();
            lblResponseTitle = new Label();
            txtCompResponse = new TextBox();
            lblAddressesTitle = new Label();
            pnlAddress = new Panel();
            lblAddressHeading = new Label();
            lblAddrStreet = new Label();
            txtAddrStreet = new TextBox();
            lblAddrSuburb = new Label();
            txtAddrSuburb = new TextBox();
            lblAddrCity = new Label();
            txtAddrCity = new TextBox();
            lblAddrPostal = new Label();
            txtAddrPostal = new TextBox();
            btnSaveAddress = new Button();
            lblSavedTitle = new Label();
            lstAddresses = new ListBox();
            btnRemoveAddress = new Button();
            tabMain.SuspendLayout();
            pnlSidebar.SuspendLayout();
            tabHome.SuspendLayout();
            tabCollections.SuspendLayout();
            tabRecycling.SuspendLayout();
            tabComplaints.SuspendLayout();
            tabAddresses.SuspendLayout();
            pnlNext.SuspendLayout();
            pnlStatRecycling.SuspendLayout();
            pnlStatComplaints.SuspendLayout();
            pnlRequest.SuspendLayout();
            pnlRecycle.SuspendLayout();
            pnlComplaint.SuspendLayout();
            pnlAddress.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)picLogo).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvHomeCollections).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvMyCollections).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudRecBags).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvMyRecycling).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvMyComplaints).BeginInit();
            SuspendLayout();
            // 
            // tabMain
            // 
            tabMain.Controls.Add(tabHome);
            tabMain.Controls.Add(tabCollections);
            tabMain.Controls.Add(tabRecycling);
            tabMain.Controls.Add(tabComplaints);
            tabMain.Controls.Add(tabAddresses);
            tabMain.Dock = DockStyle.Fill;
            tabMain.Font = new Font("Segoe UI", 10F);
            tabMain.Name = "tabMain";
            tabMain.SelectedIndex = 0;
            tabMain.TabIndex = 0;
            tabMain.SelectedIndexChanged += tabMain_SelectedIndexChanged;
            // 
            // pnlSidebar
            // 
            pnlSidebar.Controls.Add(picLogo);
            pnlSidebar.Controls.Add(lblAppName);
            pnlSidebar.Controls.Add(lblRole);
            pnlSidebar.Controls.Add(btnNavHome);
            pnlSidebar.Controls.Add(btnNavCollections);
            pnlSidebar.Controls.Add(btnNavRecycling);
            pnlSidebar.Controls.Add(btnNavComplaints);
            pnlSidebar.Controls.Add(btnNavAddresses);
            pnlSidebar.Controls.Add(lblHello);
            pnlSidebar.Controls.Add(btnSignOut);
            pnlSidebar.BackColor = Color.FromArgb(18, 53, 36);
            pnlSidebar.Dock = DockStyle.Left;
            pnlSidebar.Name = "pnlSidebar";
            pnlSidebar.Size = new Size(230, 760);
            pnlSidebar.TabIndex = 1;
            // 
            // picLogo
            // 
            picLogo.Image = Properties.Resources.logo_white;
            picLogo.Location = new Point(20, 22);
            picLogo.Name = "picLogo";
            picLogo.Size = new Size(46, 52);
            picLogo.SizeMode = PictureBoxSizeMode.Zoom;
            picLogo.TabIndex = 0;
            picLogo.TabStop = false;
            // 
            // lblAppName
            // 
            lblAppName.AutoSize = true;
            lblAppName.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            lblAppName.ForeColor = Color.White;
            lblAppName.Location = new Point(72, 24);
            lblAppName.Name = "lblAppName";
            lblAppName.TabIndex = 1;
            lblAppName.Text = "Smart Waste";
            // 
            // lblRole
            // 
            lblRole.AutoSize = true;
            lblRole.Font = new Font("Segoe UI", 9.5F);
            lblRole.ForeColor = Color.FromArgb(158, 208, 174);
            lblRole.Location = new Point(74, 54);
            lblRole.Name = "lblRole";
            lblRole.TabIndex = 2;
            lblRole.Text = "Resident";
            // 
            // btnNavHome
            // 
            btnNavHome.BackColor = Color.FromArgb(18, 53, 36);
            btnNavHome.Cursor = Cursors.Hand;
            btnNavHome.FlatAppearance.BorderSize = 0;
            btnNavHome.FlatAppearance.MouseOverBackColor = Color.FromArgb(30, 90, 60);
            btnNavHome.FlatStyle = FlatStyle.Flat;
            btnNavHome.Font = new Font("Segoe UI", 11F);
            btnNavHome.ForeColor = Color.White;
            btnNavHome.Location = new Point(0, 120);
            btnNavHome.Name = "btnNavHome";
            btnNavHome.Padding = new Padding(24, 0, 0, 0);
            btnNavHome.Size = new Size(230, 46);
            btnNavHome.TabIndex = 3;
            btnNavHome.Text = "Home";
            btnNavHome.TextAlign = ContentAlignment.MiddleLeft;
            btnNavHome.UseVisualStyleBackColor = false;
            btnNavHome.Click += btnNavHome_Click;
            // 
            // btnNavCollections
            // 
            btnNavCollections.BackColor = Color.FromArgb(18, 53, 36);
            btnNavCollections.Cursor = Cursors.Hand;
            btnNavCollections.FlatAppearance.BorderSize = 0;
            btnNavCollections.FlatAppearance.MouseOverBackColor = Color.FromArgb(30, 90, 60);
            btnNavCollections.FlatStyle = FlatStyle.Flat;
            btnNavCollections.Font = new Font("Segoe UI", 11F);
            btnNavCollections.ForeColor = Color.White;
            btnNavCollections.Location = new Point(0, 170);
            btnNavCollections.Name = "btnNavCollections";
            btnNavCollections.Padding = new Padding(24, 0, 0, 0);
            btnNavCollections.Size = new Size(230, 46);
            btnNavCollections.TabIndex = 4;
            btnNavCollections.Text = "My collections";
            btnNavCollections.TextAlign = ContentAlignment.MiddleLeft;
            btnNavCollections.UseVisualStyleBackColor = false;
            btnNavCollections.Click += btnNavCollections_Click;
            // 
            // btnNavRecycling
            // 
            btnNavRecycling.BackColor = Color.FromArgb(18, 53, 36);
            btnNavRecycling.Cursor = Cursors.Hand;
            btnNavRecycling.FlatAppearance.BorderSize = 0;
            btnNavRecycling.FlatAppearance.MouseOverBackColor = Color.FromArgb(30, 90, 60);
            btnNavRecycling.FlatStyle = FlatStyle.Flat;
            btnNavRecycling.Font = new Font("Segoe UI", 11F);
            btnNavRecycling.ForeColor = Color.White;
            btnNavRecycling.Location = new Point(0, 220);
            btnNavRecycling.Name = "btnNavRecycling";
            btnNavRecycling.Padding = new Padding(24, 0, 0, 0);
            btnNavRecycling.Size = new Size(230, 46);
            btnNavRecycling.TabIndex = 5;
            btnNavRecycling.Text = "Recycling";
            btnNavRecycling.TextAlign = ContentAlignment.MiddleLeft;
            btnNavRecycling.UseVisualStyleBackColor = false;
            btnNavRecycling.Click += btnNavRecycling_Click;
            // 
            // btnNavComplaints
            // 
            btnNavComplaints.BackColor = Color.FromArgb(18, 53, 36);
            btnNavComplaints.Cursor = Cursors.Hand;
            btnNavComplaints.FlatAppearance.BorderSize = 0;
            btnNavComplaints.FlatAppearance.MouseOverBackColor = Color.FromArgb(30, 90, 60);
            btnNavComplaints.FlatStyle = FlatStyle.Flat;
            btnNavComplaints.Font = new Font("Segoe UI", 11F);
            btnNavComplaints.ForeColor = Color.White;
            btnNavComplaints.Location = new Point(0, 270);
            btnNavComplaints.Name = "btnNavComplaints";
            btnNavComplaints.Padding = new Padding(24, 0, 0, 0);
            btnNavComplaints.Size = new Size(230, 46);
            btnNavComplaints.TabIndex = 6;
            btnNavComplaints.Text = "Complaints";
            btnNavComplaints.TextAlign = ContentAlignment.MiddleLeft;
            btnNavComplaints.UseVisualStyleBackColor = false;
            btnNavComplaints.Click += btnNavComplaints_Click;
            // 
            // btnNavAddresses
            // 
            btnNavAddresses.BackColor = Color.FromArgb(18, 53, 36);
            btnNavAddresses.Cursor = Cursors.Hand;
            btnNavAddresses.FlatAppearance.BorderSize = 0;
            btnNavAddresses.FlatAppearance.MouseOverBackColor = Color.FromArgb(30, 90, 60);
            btnNavAddresses.FlatStyle = FlatStyle.Flat;
            btnNavAddresses.Font = new Font("Segoe UI", 11F);
            btnNavAddresses.ForeColor = Color.White;
            btnNavAddresses.Location = new Point(0, 320);
            btnNavAddresses.Name = "btnNavAddresses";
            btnNavAddresses.Padding = new Padding(24, 0, 0, 0);
            btnNavAddresses.Size = new Size(230, 46);
            btnNavAddresses.TabIndex = 7;
            btnNavAddresses.Text = "My addresses";
            btnNavAddresses.TextAlign = ContentAlignment.MiddleLeft;
            btnNavAddresses.UseVisualStyleBackColor = false;
            btnNavAddresses.Click += btnNavAddresses_Click;
            // 
            // lblHello
            // 
            lblHello.AutoSize = true;
            lblHello.Font = new Font("Segoe UI", 10F);
            lblHello.ForeColor = Color.White;
            lblHello.Location = new Point(22, 646);
            lblHello.Name = "lblHello";
            lblHello.TabIndex = 8;
            lblHello.Text = "Hello, name";
            // 
            // btnSignOut
            // 
            btnSignOut.BackColor = Color.FromArgb(18, 53, 36);
            btnSignOut.Cursor = Cursors.Hand;
            btnSignOut.FlatAppearance.BorderColor = Color.FromArgb(158, 208, 174);
            btnSignOut.FlatStyle = FlatStyle.Flat;
            btnSignOut.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnSignOut.ForeColor = Color.White;
            btnSignOut.Location = new Point(22, 680);
            btnSignOut.Name = "btnSignOut";
            btnSignOut.Size = new Size(186, 40);
            btnSignOut.TabIndex = 9;
            btnSignOut.Text = "Sign out";
            btnSignOut.UseVisualStyleBackColor = false;
            btnSignOut.Click += btnSignOut_Click;
            // 
            // tabHome
            // 
            tabHome.Controls.Add(lblHomeTitle);
            tabHome.Controls.Add(lblHomeDate);
            tabHome.Controls.Add(pnlNext);
            tabHome.Controls.Add(pnlStatRecycling);
            tabHome.Controls.Add(pnlStatComplaints);
            tabHome.Controls.Add(lblRecentTitle);
            tabHome.Controls.Add(dgvHomeCollections);
            tabHome.BackColor = Color.FromArgb(243, 244, 239);
            tabHome.Location = new Point(4, 32);
            tabHome.Name = "tabHome";
            tabHome.Padding = new Padding(3);
            tabHome.Size = new Size(1042, 724);
            tabHome.Text = "Home";
            // 
            // tabCollections
            // 
            tabCollections.Controls.Add(lblCollectionsTitle);
            tabCollections.Controls.Add(pnlRequest);
            tabCollections.Controls.Add(dgvMyCollections);
            tabCollections.Controls.Add(btnCancelCollection);
            tabCollections.BackColor = Color.FromArgb(243, 244, 239);
            tabCollections.Location = new Point(4, 32);
            tabCollections.Name = "tabCollections";
            tabCollections.Padding = new Padding(3);
            tabCollections.Size = new Size(1042, 724);
            tabCollections.Text = "My collections";
            // 
            // tabRecycling
            // 
            tabRecycling.Controls.Add(lblRecyclingTitle);
            tabRecycling.Controls.Add(pnlRecycle);
            tabRecycling.Controls.Add(dgvMyRecycling);
            tabRecycling.BackColor = Color.FromArgb(243, 244, 239);
            tabRecycling.Location = new Point(4, 32);
            tabRecycling.Name = "tabRecycling";
            tabRecycling.Padding = new Padding(3);
            tabRecycling.Size = new Size(1042, 724);
            tabRecycling.Text = "Recycling";
            // 
            // tabComplaints
            // 
            tabComplaints.Controls.Add(lblComplaintsTitle);
            tabComplaints.Controls.Add(pnlComplaint);
            tabComplaints.Controls.Add(dgvMyComplaints);
            tabComplaints.Controls.Add(lblResponseTitle);
            tabComplaints.Controls.Add(txtCompResponse);
            tabComplaints.BackColor = Color.FromArgb(243, 244, 239);
            tabComplaints.Location = new Point(4, 32);
            tabComplaints.Name = "tabComplaints";
            tabComplaints.Padding = new Padding(3);
            tabComplaints.Size = new Size(1042, 724);
            tabComplaints.Text = "Complaints";
            // 
            // tabAddresses
            // 
            tabAddresses.Controls.Add(lblAddressesTitle);
            tabAddresses.Controls.Add(pnlAddress);
            tabAddresses.Controls.Add(lblSavedTitle);
            tabAddresses.Controls.Add(lstAddresses);
            tabAddresses.Controls.Add(btnRemoveAddress);
            tabAddresses.BackColor = Color.FromArgb(243, 244, 239);
            tabAddresses.Location = new Point(4, 32);
            tabAddresses.Name = "tabAddresses";
            tabAddresses.Padding = new Padding(3);
            tabAddresses.Size = new Size(1042, 724);
            tabAddresses.Text = "My addresses";
            // 
            // lblHomeTitle
            // 
            lblHomeTitle.AutoSize = true;
            lblHomeTitle.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            lblHomeTitle.ForeColor = Color.FromArgb(22, 32, 26);
            lblHomeTitle.Location = new Point(20, 14);
            lblHomeTitle.Name = "lblHomeTitle";
            lblHomeTitle.TabIndex = 0;
            lblHomeTitle.Text = "Welcome back";
            // 
            // lblHomeDate
            // 
            lblHomeDate.AutoSize = true;
            lblHomeDate.Font = new Font("Segoe UI", 10F);
            lblHomeDate.ForeColor = Color.FromArgb(95, 107, 99);
            lblHomeDate.Location = new Point(23, 54);
            lblHomeDate.Name = "lblHomeDate";
            lblHomeDate.TabIndex = 1;
            lblHomeDate.Text = "Today";
            // 
            // pnlNext
            // 
            pnlNext.Controls.Add(lblNextHeading);
            pnlNext.Controls.Add(lblNextDate);
            pnlNext.Controls.Add(lblNextDetails);
            pnlNext.Controls.Add(lblNextStatus);
            pnlNext.BackColor = Color.White;
            pnlNext.BorderStyle = BorderStyle.FixedSingle;
            pnlNext.Location = new Point(20, 90);
            pnlNext.Name = "pnlNext";
            pnlNext.Size = new Size(640, 200);
            pnlNext.TabIndex = 2;
            // 
            // lblNextHeading
            // 
            lblNextHeading.AutoSize = true;
            lblNextHeading.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblNextHeading.ForeColor = Color.FromArgb(30, 90, 60);
            lblNextHeading.Location = new Point(18, 16);
            lblNextHeading.Name = "lblNextHeading";
            lblNextHeading.TabIndex = 0;
            lblNextHeading.Text = "NEXT COLLECTION";
            // 
            // lblNextDate
            // 
            lblNextDate.AutoSize = true;
            lblNextDate.Font = new Font("Segoe UI", 22F, FontStyle.Bold);
            lblNextDate.ForeColor = Color.FromArgb(22, 32, 26);
            lblNextDate.Location = new Point(16, 40);
            lblNextDate.Name = "lblNextDate";
            lblNextDate.TabIndex = 1;
            lblNextDate.Text = "No collection booked";
            // 
            // lblNextDetails
            // 
            lblNextDetails.Font = new Font("Segoe UI", 11F);
            lblNextDetails.ForeColor = Color.FromArgb(95, 107, 99);
            lblNextDetails.Location = new Point(18, 92);
            lblNextDetails.Name = "lblNextDetails";
            lblNextDetails.Size = new Size(600, 54);
            lblNextDetails.TabIndex = 2;
            lblNextDetails.Text = "";
            // 
            // lblNextStatus
            // 
            lblNextStatus.AutoSize = true;
            lblNextStatus.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblNextStatus.ForeColor = Color.FromArgb(30, 90, 60);
            lblNextStatus.Location = new Point(18, 152);
            lblNextStatus.Name = "lblNextStatus";
            lblNextStatus.TabIndex = 3;
            lblNextStatus.Text = "Status: -";
            // 
            // pnlStatRecycling
            // 
            pnlStatRecycling.Controls.Add(lblStatRecyclingTitle);
            pnlStatRecycling.Controls.Add(lblStatRecycling);
            pnlStatRecycling.BackColor = Color.White;
            pnlStatRecycling.BorderStyle = BorderStyle.FixedSingle;
            pnlStatRecycling.Location = new Point(680, 90);
            pnlStatRecycling.Name = "pnlStatRecycling";
            pnlStatRecycling.Size = new Size(340, 95);
            pnlStatRecycling.TabIndex = 3;
            // 
            // lblStatRecyclingTitle
            // 
            lblStatRecyclingTitle.AutoSize = true;
            lblStatRecyclingTitle.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblStatRecyclingTitle.ForeColor = Color.FromArgb(95, 107, 99);
            lblStatRecyclingTitle.Location = new Point(16, 12);
            lblStatRecyclingTitle.Name = "lblStatRecyclingTitle";
            lblStatRecyclingTitle.TabIndex = 0;
            lblStatRecyclingTitle.Text = "My recycling requests";
            // 
            // lblStatRecycling
            // 
            lblStatRecycling.AutoSize = true;
            lblStatRecycling.Font = new Font("Segoe UI", 24F, FontStyle.Bold);
            lblStatRecycling.ForeColor = Color.FromArgb(22, 32, 26);
            lblStatRecycling.Location = new Point(14, 38);
            lblStatRecycling.Name = "lblStatRecycling";
            lblStatRecycling.TabIndex = 1;
            lblStatRecycling.Text = "0";
            // 
            // pnlStatComplaints
            // 
            pnlStatComplaints.Controls.Add(lblStatComplaintsTitle);
            pnlStatComplaints.Controls.Add(lblStatComplaints);
            pnlStatComplaints.BackColor = Color.White;
            pnlStatComplaints.BorderStyle = BorderStyle.FixedSingle;
            pnlStatComplaints.Location = new Point(680, 195);
            pnlStatComplaints.Name = "pnlStatComplaints";
            pnlStatComplaints.Size = new Size(340, 95);
            pnlStatComplaints.TabIndex = 4;
            // 
            // lblStatComplaintsTitle
            // 
            lblStatComplaintsTitle.AutoSize = true;
            lblStatComplaintsTitle.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblStatComplaintsTitle.ForeColor = Color.FromArgb(95, 107, 99);
            lblStatComplaintsTitle.Location = new Point(16, 12);
            lblStatComplaintsTitle.Name = "lblStatComplaintsTitle";
            lblStatComplaintsTitle.TabIndex = 0;
            lblStatComplaintsTitle.Text = "My open complaints";
            // 
            // lblStatComplaints
            // 
            lblStatComplaints.AutoSize = true;
            lblStatComplaints.Font = new Font("Segoe UI", 24F, FontStyle.Bold);
            lblStatComplaints.ForeColor = Color.FromArgb(22, 32, 26);
            lblStatComplaints.Location = new Point(14, 38);
            lblStatComplaints.Name = "lblStatComplaints";
            lblStatComplaints.TabIndex = 1;
            lblStatComplaints.Text = "0";
            // 
            // lblRecentTitle
            // 
            lblRecentTitle.AutoSize = true;
            lblRecentTitle.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            lblRecentTitle.ForeColor = Color.FromArgb(22, 32, 26);
            lblRecentTitle.Location = new Point(20, 310);
            lblRecentTitle.Name = "lblRecentTitle";
            lblRecentTitle.TabIndex = 5;
            lblRecentTitle.Text = "My recent collections";
            // 
            // dgvHomeCollections
            // 
            dgvHomeCollections.AllowUserToAddRows = false;
            dgvHomeCollections.AllowUserToDeleteRows = false;
            dgvHomeCollections.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvHomeCollections.BackgroundColor = Color.White;
            dgvHomeCollections.BorderStyle = BorderStyle.None;
            dgvHomeCollections.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvHomeCollections.Location = new Point(20, 345);
            dgvHomeCollections.MultiSelect = false;
            dgvHomeCollections.Name = "dgvHomeCollections";
            dgvHomeCollections.ReadOnly = true;
            dgvHomeCollections.RowHeadersVisible = false;
            dgvHomeCollections.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvHomeCollections.Size = new Size(1000, 330);
            dgvHomeCollections.TabIndex = 6;
            // 
            // lblCollectionsTitle
            // 
            lblCollectionsTitle.AutoSize = true;
            lblCollectionsTitle.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            lblCollectionsTitle.ForeColor = Color.FromArgb(22, 32, 26);
            lblCollectionsTitle.Location = new Point(20, 14);
            lblCollectionsTitle.Name = "lblCollectionsTitle";
            lblCollectionsTitle.TabIndex = 0;
            lblCollectionsTitle.Text = "My collections";
            // 
            // pnlRequest
            // 
            pnlRequest.Controls.Add(lblRequestHeading);
            pnlRequest.Controls.Add(lblRequestHint);
            pnlRequest.Controls.Add(lblColType);
            pnlRequest.Controls.Add(cboColType);
            pnlRequest.Controls.Add(lblColAddress);
            pnlRequest.Controls.Add(cboColAddress);
            pnlRequest.Controls.Add(lblColDate);
            pnlRequest.Controls.Add(dtpColDate);
            pnlRequest.Controls.Add(lblColNotes);
            pnlRequest.Controls.Add(txtColNotes);
            pnlRequest.Controls.Add(btnRequestCollection);
            pnlRequest.BackColor = Color.White;
            pnlRequest.BorderStyle = BorderStyle.FixedSingle;
            pnlRequest.Location = new Point(20, 60);
            pnlRequest.Name = "pnlRequest";
            pnlRequest.Size = new Size(330, 500);
            pnlRequest.TabIndex = 1;
            // 
            // lblRequestHeading
            // 
            lblRequestHeading.AutoSize = true;
            lblRequestHeading.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            lblRequestHeading.ForeColor = Color.FromArgb(22, 32, 26);
            lblRequestHeading.Location = new Point(16, 14);
            lblRequestHeading.Name = "lblRequestHeading";
            lblRequestHeading.TabIndex = 0;
            lblRequestHeading.Text = "Request a collection";
            // 
            // lblRequestHint
            // 
            lblRequestHint.Font = new Font("Segoe UI", 9.5F);
            lblRequestHint.ForeColor = Color.FromArgb(95, 107, 99);
            lblRequestHint.Location = new Point(16, 44);
            lblRequestHint.Name = "lblRequestHint";
            lblRequestHint.Size = new Size(296, 40);
            lblRequestHint.TabIndex = 1;
            lblRequestHint.Text = "For bulky items, garden refuse or an extra pickup.";
            // 
            // lblColType
            // 
            lblColType.AutoSize = true;
            lblColType.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblColType.ForeColor = Color.FromArgb(22, 32, 26);
            lblColType.Location = new Point(16, 92);
            lblColType.Name = "lblColType";
            lblColType.TabIndex = 2;
            lblColType.Text = "Collection type";
            // 
            // cboColType
            // 
            cboColType.DropDownStyle = ComboBoxStyle.DropDownList;
            cboColType.Font = new Font("Segoe UI", 10.5F);
            cboColType.FormattingEnabled = true;
            cboColType.Items.AddRange(new object[] { "General waste", "Garden refuse", "Bulky items" });
            cboColType.Location = new Point(16, 116);
            cboColType.Name = "cboColType";
            cboColType.Size = new Size(296, 32);
            cboColType.TabIndex = 3;
            // 
            // lblColAddress
            // 
            lblColAddress.AutoSize = true;
            lblColAddress.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblColAddress.ForeColor = Color.FromArgb(22, 32, 26);
            lblColAddress.Location = new Point(16, 162);
            lblColAddress.Name = "lblColAddress";
            lblColAddress.TabIndex = 4;
            lblColAddress.Text = "Address";
            // 
            // cboColAddress
            // 
            cboColAddress.DropDownStyle = ComboBoxStyle.DropDownList;
            cboColAddress.Font = new Font("Segoe UI", 10.5F);
            cboColAddress.FormattingEnabled = true;
            cboColAddress.Location = new Point(16, 186);
            cboColAddress.Name = "cboColAddress";
            cboColAddress.Size = new Size(296, 32);
            cboColAddress.TabIndex = 5;
            // 
            // lblColDate
            // 
            lblColDate.AutoSize = true;
            lblColDate.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblColDate.ForeColor = Color.FromArgb(22, 32, 26);
            lblColDate.Location = new Point(16, 232);
            lblColDate.Name = "lblColDate";
            lblColDate.TabIndex = 6;
            lblColDate.Text = "Date";
            // 
            // dtpColDate
            // 
            dtpColDate.Font = new Font("Segoe UI", 10.5F);
            dtpColDate.Location = new Point(16, 256);
            dtpColDate.Name = "dtpColDate";
            dtpColDate.Size = new Size(296, 32);
            dtpColDate.TabIndex = 7;
            // 
            // lblColNotes
            // 
            lblColNotes.AutoSize = true;
            lblColNotes.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblColNotes.ForeColor = Color.FromArgb(22, 32, 26);
            lblColNotes.Location = new Point(16, 302);
            lblColNotes.Name = "lblColNotes";
            lblColNotes.TabIndex = 8;
            lblColNotes.Text = "Notes for the driver (optional)";
            // 
            // txtColNotes
            // 
            txtColNotes.Font = new Font("Segoe UI", 11F);
            txtColNotes.Location = new Point(16, 326);
            txtColNotes.Multiline = true;
            txtColNotes.Name = "txtColNotes";
            txtColNotes.Size = new Size(296, 90);
            txtColNotes.TabIndex = 9;
            // 
            // btnRequestCollection
            // 
            btnRequestCollection.BackColor = Color.FromArgb(30, 90, 60);
            btnRequestCollection.Cursor = Cursors.Hand;
            btnRequestCollection.FlatAppearance.BorderSize = 0;
            btnRequestCollection.FlatStyle = FlatStyle.Flat;
            btnRequestCollection.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnRequestCollection.ForeColor = Color.White;
            btnRequestCollection.Location = new Point(16, 436);
            btnRequestCollection.Name = "btnRequestCollection";
            btnRequestCollection.Size = new Size(296, 46);
            btnRequestCollection.TabIndex = 10;
            btnRequestCollection.Text = "Request collection";
            btnRequestCollection.UseVisualStyleBackColor = false;
            btnRequestCollection.Click += btnRequestCollection_Click;
            // 
            // dgvMyCollections
            // 
            dgvMyCollections.AllowUserToAddRows = false;
            dgvMyCollections.AllowUserToDeleteRows = false;
            dgvMyCollections.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvMyCollections.BackgroundColor = Color.White;
            dgvMyCollections.BorderStyle = BorderStyle.None;
            dgvMyCollections.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvMyCollections.Location = new Point(370, 60);
            dgvMyCollections.MultiSelect = false;
            dgvMyCollections.Name = "dgvMyCollections";
            dgvMyCollections.ReadOnly = true;
            dgvMyCollections.RowHeadersVisible = false;
            dgvMyCollections.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvMyCollections.Size = new Size(650, 560);
            dgvMyCollections.TabIndex = 2;
            // 
            // btnCancelCollection
            // 
            btnCancelCollection.BackColor = Color.White;
            btnCancelCollection.Cursor = Cursors.Hand;
            btnCancelCollection.FlatAppearance.BorderColor = Color.FromArgb(163, 33, 22);
            btnCancelCollection.FlatStyle = FlatStyle.Flat;
            btnCancelCollection.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnCancelCollection.ForeColor = Color.FromArgb(163, 33, 22);
            btnCancelCollection.Location = new Point(370, 632);
            btnCancelCollection.Name = "btnCancelCollection";
            btnCancelCollection.Size = new Size(220, 40);
            btnCancelCollection.TabIndex = 3;
            btnCancelCollection.Text = "Cancel selected";
            btnCancelCollection.UseVisualStyleBackColor = false;
            btnCancelCollection.Click += btnCancelCollection_Click;
            // 
            // lblRecyclingTitle
            // 
            lblRecyclingTitle.AutoSize = true;
            lblRecyclingTitle.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            lblRecyclingTitle.ForeColor = Color.FromArgb(22, 32, 26);
            lblRecyclingTitle.Location = new Point(20, 14);
            lblRecyclingTitle.Name = "lblRecyclingTitle";
            lblRecyclingTitle.TabIndex = 0;
            lblRecyclingTitle.Text = "Recycling";
            // 
            // pnlRecycle
            // 
            pnlRecycle.Controls.Add(lblRecycleHeading);
            pnlRecycle.Controls.Add(lblRecycleHint);
            pnlRecycle.Controls.Add(lblRecCategory);
            pnlRecycle.Controls.Add(cboRecCategory);
            pnlRecycle.Controls.Add(lblRecBags);
            pnlRecycle.Controls.Add(nudRecBags);
            pnlRecycle.Controls.Add(lblRecAddress);
            pnlRecycle.Controls.Add(cboRecAddress);
            pnlRecycle.Controls.Add(lblRecDate);
            pnlRecycle.Controls.Add(dtpRecDate);
            pnlRecycle.Controls.Add(btnSubmitRecycling);
            pnlRecycle.BackColor = Color.White;
            pnlRecycle.BorderStyle = BorderStyle.FixedSingle;
            pnlRecycle.Location = new Point(20, 60);
            pnlRecycle.Name = "pnlRecycle";
            pnlRecycle.Size = new Size(330, 445);
            pnlRecycle.TabIndex = 1;
            // 
            // lblRecycleHeading
            // 
            lblRecycleHeading.AutoSize = true;
            lblRecycleHeading.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            lblRecycleHeading.ForeColor = Color.FromArgb(22, 32, 26);
            lblRecycleHeading.Location = new Point(16, 14);
            lblRecycleHeading.Name = "lblRecycleHeading";
            lblRecycleHeading.TabIndex = 0;
            lblRecycleHeading.Text = "Request a recycling pickup";
            // 
            // lblRecycleHint
            // 
            lblRecycleHint.Font = new Font("Segoe UI", 9.5F);
            lblRecycleHint.ForeColor = Color.FromArgb(95, 107, 99);
            lblRecycleHint.Location = new Point(16, 44);
            lblRecycleHint.Name = "lblRecycleHint";
            lblRecycleHint.Size = new Size(296, 40);
            lblRecycleHint.TabIndex = 1;
            lblRecycleHint.Text = "Sorted recyclables only, please.";
            // 
            // lblRecCategory
            // 
            lblRecCategory.AutoSize = true;
            lblRecCategory.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblRecCategory.ForeColor = Color.FromArgb(22, 32, 26);
            lblRecCategory.Location = new Point(16, 92);
            lblRecCategory.Name = "lblRecCategory";
            lblRecCategory.TabIndex = 2;
            lblRecCategory.Text = "Category";
            // 
            // cboRecCategory
            // 
            cboRecCategory.DropDownStyle = ComboBoxStyle.DropDownList;
            cboRecCategory.Font = new Font("Segoe UI", 10.5F);
            cboRecCategory.FormattingEnabled = true;
            cboRecCategory.Items.AddRange(new object[] { "Plastic", "Glass", "Paper", "Metal" });
            cboRecCategory.Location = new Point(16, 116);
            cboRecCategory.Name = "cboRecCategory";
            cboRecCategory.Size = new Size(296, 32);
            cboRecCategory.TabIndex = 3;
            // 
            // lblRecBags
            // 
            lblRecBags.AutoSize = true;
            lblRecBags.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblRecBags.ForeColor = Color.FromArgb(22, 32, 26);
            lblRecBags.Location = new Point(16, 162);
            lblRecBags.Name = "lblRecBags";
            lblRecBags.TabIndex = 4;
            lblRecBags.Text = "Number of bags";
            // 
            // nudRecBags
            // 
            nudRecBags.Font = new Font("Segoe UI", 10.5F);
            nudRecBags.Location = new Point(16, 186);
            nudRecBags.Maximum = new decimal(new int[] { 20, 0, 0, 0 });
            nudRecBags.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            nudRecBags.Name = "nudRecBags";
            nudRecBags.Size = new Size(120, 32);
            nudRecBags.TabIndex = 5;
            nudRecBags.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // lblRecAddress
            // 
            lblRecAddress.AutoSize = true;
            lblRecAddress.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblRecAddress.ForeColor = Color.FromArgb(22, 32, 26);
            lblRecAddress.Location = new Point(16, 232);
            lblRecAddress.Name = "lblRecAddress";
            lblRecAddress.TabIndex = 6;
            lblRecAddress.Text = "Pickup address";
            // 
            // cboRecAddress
            // 
            cboRecAddress.DropDownStyle = ComboBoxStyle.DropDownList;
            cboRecAddress.Font = new Font("Segoe UI", 10.5F);
            cboRecAddress.FormattingEnabled = true;
            cboRecAddress.Location = new Point(16, 256);
            cboRecAddress.Name = "cboRecAddress";
            cboRecAddress.Size = new Size(296, 32);
            cboRecAddress.TabIndex = 7;
            // 
            // lblRecDate
            // 
            lblRecDate.AutoSize = true;
            lblRecDate.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblRecDate.ForeColor = Color.FromArgb(22, 32, 26);
            lblRecDate.Location = new Point(16, 302);
            lblRecDate.Name = "lblRecDate";
            lblRecDate.TabIndex = 8;
            lblRecDate.Text = "Preferred date";
            // 
            // dtpRecDate
            // 
            dtpRecDate.Font = new Font("Segoe UI", 10.5F);
            dtpRecDate.Location = new Point(16, 326);
            dtpRecDate.Name = "dtpRecDate";
            dtpRecDate.Size = new Size(296, 32);
            dtpRecDate.TabIndex = 9;
            // 
            // btnSubmitRecycling
            // 
            btnSubmitRecycling.BackColor = Color.FromArgb(30, 90, 60);
            btnSubmitRecycling.Cursor = Cursors.Hand;
            btnSubmitRecycling.FlatAppearance.BorderSize = 0;
            btnSubmitRecycling.FlatStyle = FlatStyle.Flat;
            btnSubmitRecycling.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnSubmitRecycling.ForeColor = Color.White;
            btnSubmitRecycling.Location = new Point(16, 378);
            btnSubmitRecycling.Name = "btnSubmitRecycling";
            btnSubmitRecycling.Size = new Size(296, 46);
            btnSubmitRecycling.TabIndex = 10;
            btnSubmitRecycling.Text = "Submit request";
            btnSubmitRecycling.UseVisualStyleBackColor = false;
            btnSubmitRecycling.Click += btnSubmitRecycling_Click;
            // 
            // dgvMyRecycling
            // 
            dgvMyRecycling.AllowUserToAddRows = false;
            dgvMyRecycling.AllowUserToDeleteRows = false;
            dgvMyRecycling.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvMyRecycling.BackgroundColor = Color.White;
            dgvMyRecycling.BorderStyle = BorderStyle.None;
            dgvMyRecycling.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvMyRecycling.Location = new Point(370, 60);
            dgvMyRecycling.MultiSelect = false;
            dgvMyRecycling.Name = "dgvMyRecycling";
            dgvMyRecycling.ReadOnly = true;
            dgvMyRecycling.RowHeadersVisible = false;
            dgvMyRecycling.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvMyRecycling.Size = new Size(650, 610);
            dgvMyRecycling.TabIndex = 2;
            // 
            // lblComplaintsTitle
            // 
            lblComplaintsTitle.AutoSize = true;
            lblComplaintsTitle.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            lblComplaintsTitle.ForeColor = Color.FromArgb(22, 32, 26);
            lblComplaintsTitle.Location = new Point(20, 14);
            lblComplaintsTitle.Name = "lblComplaintsTitle";
            lblComplaintsTitle.TabIndex = 0;
            lblComplaintsTitle.Text = "Complaints";
            // 
            // pnlComplaint
            // 
            pnlComplaint.Controls.Add(lblComplaintHeading);
            pnlComplaint.Controls.Add(lblComplaintHint);
            pnlComplaint.Controls.Add(lblCompType);
            pnlComplaint.Controls.Add(cboCompType);
            pnlComplaint.Controls.Add(lblCompCollection);
            pnlComplaint.Controls.Add(cboCompCollection);
            pnlComplaint.Controls.Add(lblCompDescription);
            pnlComplaint.Controls.Add(txtCompDescription);
            pnlComplaint.Controls.Add(lblCharCount);
            pnlComplaint.Controls.Add(btnSubmitComplaint);
            pnlComplaint.BackColor = Color.White;
            pnlComplaint.BorderStyle = BorderStyle.FixedSingle;
            pnlComplaint.Location = new Point(20, 60);
            pnlComplaint.Name = "pnlComplaint";
            pnlComplaint.Size = new Size(330, 500);
            pnlComplaint.TabIndex = 1;
            // 
            // lblComplaintHeading
            // 
            lblComplaintHeading.AutoSize = true;
            lblComplaintHeading.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            lblComplaintHeading.ForeColor = Color.FromArgb(22, 32, 26);
            lblComplaintHeading.Location = new Point(16, 14);
            lblComplaintHeading.Name = "lblComplaintHeading";
            lblComplaintHeading.TabIndex = 0;
            lblComplaintHeading.Text = "Report a problem";
            // 
            // lblComplaintHint
            // 
            lblComplaintHint.Font = new Font("Segoe UI", 9.5F);
            lblComplaintHint.ForeColor = Color.FromArgb(95, 107, 99);
            lblComplaintHint.Location = new Point(16, 44);
            lblComplaintHint.Name = "lblComplaintHint";
            lblComplaintHint.Size = new Size(296, 40);
            lblComplaintHint.TabIndex = 1;
            lblComplaintHint.Text = "We reply within 2 working days.";
            // 
            // lblCompType
            // 
            lblCompType.AutoSize = true;
            lblCompType.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblCompType.ForeColor = Color.FromArgb(22, 32, 26);
            lblCompType.Location = new Point(16, 92);
            lblCompType.Name = "lblCompType";
            lblCompType.TabIndex = 2;
            lblCompType.Text = "Type of problem";
            // 
            // cboCompType
            // 
            cboCompType.DropDownStyle = ComboBoxStyle.DropDownList;
            cboCompType.Font = new Font("Segoe UI", 10.5F);
            cboCompType.FormattingEnabled = true;
            cboCompType.Items.AddRange(new object[] { "Missed collection", "Illegal dumping", "Damaged bin", "Staff conduct", "Other" });
            cboCompType.Location = new Point(16, 116);
            cboCompType.Name = "cboCompType";
            cboCompType.Size = new Size(296, 32);
            cboCompType.TabIndex = 3;
            cboCompType.SelectedIndexChanged += cboCompType_SelectedIndexChanged;
            // 
            // lblCompCollection
            // 
            lblCompCollection.AutoSize = true;
            lblCompCollection.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblCompCollection.ForeColor = Color.FromArgb(22, 32, 26);
            lblCompCollection.Location = new Point(16, 162);
            lblCompCollection.Name = "lblCompCollection";
            lblCompCollection.TabIndex = 4;
            lblCompCollection.Text = "Which collection was missed?";
            // 
            // cboCompCollection
            // 
            cboCompCollection.DropDownStyle = ComboBoxStyle.DropDownList;
            cboCompCollection.Font = new Font("Segoe UI", 10.5F);
            cboCompCollection.FormattingEnabled = true;
            cboCompCollection.Location = new Point(16, 186);
            cboCompCollection.Name = "cboCompCollection";
            cboCompCollection.Size = new Size(296, 32);
            cboCompCollection.TabIndex = 5;
            // 
            // lblCompDescription
            // 
            lblCompDescription.AutoSize = true;
            lblCompDescription.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblCompDescription.ForeColor = Color.FromArgb(22, 32, 26);
            lblCompDescription.Location = new Point(16, 232);
            lblCompDescription.Name = "lblCompDescription";
            lblCompDescription.TabIndex = 6;
            lblCompDescription.Text = "Description";
            // 
            // txtCompDescription
            // 
            txtCompDescription.Font = new Font("Segoe UI", 11F);
            txtCompDescription.Location = new Point(16, 256);
            txtCompDescription.MaxLength = 300;
            txtCompDescription.Multiline = true;
            txtCompDescription.Name = "txtCompDescription";
            txtCompDescription.Size = new Size(296, 150);
            txtCompDescription.TabIndex = 7;
            txtCompDescription.TextChanged += txtCompDescription_TextChanged;
            // 
            // lblCharCount
            // 
            lblCharCount.Font = new Font("Segoe UI", 9F);
            lblCharCount.ForeColor = Color.FromArgb(95, 107, 99);
            lblCharCount.Location = new Point(16, 408);
            lblCharCount.Name = "lblCharCount";
            lblCharCount.Size = new Size(296, 20);
            lblCharCount.TabIndex = 8;
            lblCharCount.Text = "0 / 300";
            lblCharCount.TextAlign = ContentAlignment.MiddleRight;
            // 
            // btnSubmitComplaint
            // 
            btnSubmitComplaint.BackColor = Color.FromArgb(30, 90, 60);
            btnSubmitComplaint.Cursor = Cursors.Hand;
            btnSubmitComplaint.FlatAppearance.BorderSize = 0;
            btnSubmitComplaint.FlatStyle = FlatStyle.Flat;
            btnSubmitComplaint.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnSubmitComplaint.ForeColor = Color.White;
            btnSubmitComplaint.Location = new Point(16, 436);
            btnSubmitComplaint.Name = "btnSubmitComplaint";
            btnSubmitComplaint.Size = new Size(296, 46);
            btnSubmitComplaint.TabIndex = 9;
            btnSubmitComplaint.Text = "Submit complaint";
            btnSubmitComplaint.UseVisualStyleBackColor = false;
            btnSubmitComplaint.Click += btnSubmitComplaint_Click;
            // 
            // dgvMyComplaints
            // 
            dgvMyComplaints.AllowUserToAddRows = false;
            dgvMyComplaints.AllowUserToDeleteRows = false;
            dgvMyComplaints.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvMyComplaints.BackgroundColor = Color.White;
            dgvMyComplaints.BorderStyle = BorderStyle.None;
            dgvMyComplaints.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvMyComplaints.Location = new Point(370, 60);
            dgvMyComplaints.MultiSelect = false;
            dgvMyComplaints.Name = "dgvMyComplaints";
            dgvMyComplaints.ReadOnly = true;
            dgvMyComplaints.RowHeadersVisible = false;
            dgvMyComplaints.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvMyComplaints.Size = new Size(650, 400);
            dgvMyComplaints.TabIndex = 2;
            dgvMyComplaints.SelectionChanged += dgvMyComplaints_SelectionChanged;
            // 
            // lblResponseTitle
            // 
            lblResponseTitle.AutoSize = true;
            lblResponseTitle.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lblResponseTitle.ForeColor = Color.FromArgb(22, 32, 26);
            lblResponseTitle.Location = new Point(370, 476);
            lblResponseTitle.Name = "lblResponseTitle";
            lblResponseTitle.TabIndex = 3;
            lblResponseTitle.Text = "Reply from the office";
            // 
            // txtCompResponse
            // 
            txtCompResponse.BackColor = Color.White;
            txtCompResponse.Font = new Font("Segoe UI", 11F);
            txtCompResponse.Location = new Point(370, 506);
            txtCompResponse.Multiline = true;
            txtCompResponse.Name = "txtCompResponse";
            txtCompResponse.ReadOnly = true;
            txtCompResponse.Size = new Size(650, 120);
            txtCompResponse.TabIndex = 4;
            // 
            // lblAddressesTitle
            // 
            lblAddressesTitle.AutoSize = true;
            lblAddressesTitle.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            lblAddressesTitle.ForeColor = Color.FromArgb(22, 32, 26);
            lblAddressesTitle.Location = new Point(20, 14);
            lblAddressesTitle.Name = "lblAddressesTitle";
            lblAddressesTitle.TabIndex = 0;
            lblAddressesTitle.Text = "My addresses";
            // 
            // pnlAddress
            // 
            pnlAddress.Controls.Add(lblAddressHeading);
            pnlAddress.Controls.Add(lblAddrStreet);
            pnlAddress.Controls.Add(txtAddrStreet);
            pnlAddress.Controls.Add(lblAddrSuburb);
            pnlAddress.Controls.Add(txtAddrSuburb);
            pnlAddress.Controls.Add(lblAddrCity);
            pnlAddress.Controls.Add(txtAddrCity);
            pnlAddress.Controls.Add(lblAddrPostal);
            pnlAddress.Controls.Add(txtAddrPostal);
            pnlAddress.Controls.Add(btnSaveAddress);
            pnlAddress.BackColor = Color.White;
            pnlAddress.BorderStyle = BorderStyle.FixedSingle;
            pnlAddress.Location = new Point(20, 60);
            pnlAddress.Name = "pnlAddress";
            pnlAddress.Size = new Size(420, 340);
            pnlAddress.TabIndex = 1;
            // 
            // lblAddressHeading
            // 
            lblAddressHeading.AutoSize = true;
            lblAddressHeading.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            lblAddressHeading.ForeColor = Color.FromArgb(22, 32, 26);
            lblAddressHeading.Location = new Point(16, 14);
            lblAddressHeading.Name = "lblAddressHeading";
            lblAddressHeading.TabIndex = 0;
            lblAddressHeading.Text = "Add an address";
            // 
            // lblAddrStreet
            // 
            lblAddrStreet.AutoSize = true;
            lblAddrStreet.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblAddrStreet.ForeColor = Color.FromArgb(22, 32, 26);
            lblAddrStreet.Location = new Point(16, 56);
            lblAddrStreet.Name = "lblAddrStreet";
            lblAddrStreet.TabIndex = 1;
            lblAddrStreet.Text = "Street address";
            // 
            // txtAddrStreet
            // 
            txtAddrStreet.Font = new Font("Segoe UI", 11F);
            txtAddrStreet.Location = new Point(16, 80);
            txtAddrStreet.Name = "txtAddrStreet";
            txtAddrStreet.PlaceholderText = "e.g. 14 Kingsway Ave";
            txtAddrStreet.Size = new Size(386, 31);
            txtAddrStreet.TabIndex = 2;
            // 
            // lblAddrSuburb
            // 
            lblAddrSuburb.AutoSize = true;
            lblAddrSuburb.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblAddrSuburb.ForeColor = Color.FromArgb(22, 32, 26);
            lblAddrSuburb.Location = new Point(16, 125);
            lblAddrSuburb.Name = "lblAddrSuburb";
            lblAddrSuburb.TabIndex = 3;
            lblAddrSuburb.Text = "Suburb";
            // 
            // txtAddrSuburb
            // 
            txtAddrSuburb.Font = new Font("Segoe UI", 11F);
            txtAddrSuburb.Location = new Point(16, 149);
            txtAddrSuburb.Name = "txtAddrSuburb";
            txtAddrSuburb.PlaceholderText = "e.g. Auckland Park";
            txtAddrSuburb.Size = new Size(386, 31);
            txtAddrSuburb.TabIndex = 4;
            // 
            // lblAddrCity
            // 
            lblAddrCity.AutoSize = true;
            lblAddrCity.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblAddrCity.ForeColor = Color.FromArgb(22, 32, 26);
            lblAddrCity.Location = new Point(16, 194);
            lblAddrCity.Name = "lblAddrCity";
            lblAddrCity.TabIndex = 5;
            lblAddrCity.Text = "City";
            // 
            // txtAddrCity
            // 
            txtAddrCity.Font = new Font("Segoe UI", 11F);
            txtAddrCity.Location = new Point(16, 218);
            txtAddrCity.Name = "txtAddrCity";
            txtAddrCity.PlaceholderText = "e.g. Johannesburg";
            txtAddrCity.Size = new Size(250, 31);
            txtAddrCity.TabIndex = 6;
            // 
            // lblAddrPostal
            // 
            lblAddrPostal.AutoSize = true;
            lblAddrPostal.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblAddrPostal.ForeColor = Color.FromArgb(22, 32, 26);
            lblAddrPostal.Location = new Point(282, 194);
            lblAddrPostal.Name = "lblAddrPostal";
            lblAddrPostal.TabIndex = 7;
            lblAddrPostal.Text = "Postal code";
            // 
            // txtAddrPostal
            // 
            txtAddrPostal.Font = new Font("Segoe UI", 11F);
            txtAddrPostal.Location = new Point(282, 218);
            txtAddrPostal.MaxLength = 4;
            txtAddrPostal.Name = "txtAddrPostal";
            txtAddrPostal.PlaceholderText = "2092";
            txtAddrPostal.Size = new Size(120, 31);
            txtAddrPostal.TabIndex = 8;
            // 
            // btnSaveAddress
            // 
            btnSaveAddress.BackColor = Color.FromArgb(30, 90, 60);
            btnSaveAddress.Cursor = Cursors.Hand;
            btnSaveAddress.FlatAppearance.BorderSize = 0;
            btnSaveAddress.FlatStyle = FlatStyle.Flat;
            btnSaveAddress.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnSaveAddress.ForeColor = Color.White;
            btnSaveAddress.Location = new Point(16, 269);
            btnSaveAddress.Name = "btnSaveAddress";
            btnSaveAddress.Size = new Size(386, 46);
            btnSaveAddress.TabIndex = 9;
            btnSaveAddress.Text = "Save address";
            btnSaveAddress.UseVisualStyleBackColor = false;
            btnSaveAddress.Click += btnSaveAddress_Click;
            // 
            // lblSavedTitle
            // 
            lblSavedTitle.AutoSize = true;
            lblSavedTitle.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            lblSavedTitle.ForeColor = Color.FromArgb(22, 32, 26);
            lblSavedTitle.Location = new Point(470, 60);
            lblSavedTitle.Name = "lblSavedTitle";
            lblSavedTitle.TabIndex = 2;
            lblSavedTitle.Text = "Addresses saved";
            // 
            // lstAddresses
            // 
            lstAddresses.Font = new Font("Segoe UI", 11F);
            lstAddresses.FormattingEnabled = true;
            lstAddresses.ItemHeight = 25;
            lstAddresses.Location = new Point(470, 92);
            lstAddresses.Name = "lstAddresses";
            lstAddresses.Size = new Size(550, 300);
            lstAddresses.TabIndex = 3;
            // 
            // btnRemoveAddress
            // 
            btnRemoveAddress.BackColor = Color.White;
            btnRemoveAddress.Cursor = Cursors.Hand;
            btnRemoveAddress.FlatAppearance.BorderColor = Color.FromArgb(163, 33, 22);
            btnRemoveAddress.FlatStyle = FlatStyle.Flat;
            btnRemoveAddress.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnRemoveAddress.ForeColor = Color.FromArgb(163, 33, 22);
            btnRemoveAddress.Location = new Point(470, 404);
            btnRemoveAddress.Name = "btnRemoveAddress";
            btnRemoveAddress.Size = new Size(220, 40);
            btnRemoveAddress.TabIndex = 4;
            btnRemoveAddress.Text = "Remove selected";
            btnRemoveAddress.UseVisualStyleBackColor = false;
            btnRemoveAddress.Click += btnRemoveAddress_Click;
            // 
            // ResidentForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(243, 244, 239);
            ClientSize = new Size(1280, 760);
            MinimumSize = new Size(1296, 799);
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Smart Waste - Resident";
            Controls.Add(tabMain);
            Controls.Add(pnlSidebar);
            Name = "ResidentForm";
            Load += ResidentForm_Load;
            ((System.ComponentModel.ISupportInitialize)dgvMyComplaints).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvMyRecycling).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudRecBags).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvMyCollections).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvHomeCollections).EndInit();
            ((System.ComponentModel.ISupportInitialize)picLogo).EndInit();
            pnlAddress.ResumeLayout(false);
            pnlAddress.PerformLayout();
            pnlComplaint.ResumeLayout(false);
            pnlComplaint.PerformLayout();
            pnlRecycle.ResumeLayout(false);
            pnlRecycle.PerformLayout();
            pnlRequest.ResumeLayout(false);
            pnlRequest.PerformLayout();
            pnlStatComplaints.ResumeLayout(false);
            pnlStatComplaints.PerformLayout();
            pnlStatRecycling.ResumeLayout(false);
            pnlStatRecycling.PerformLayout();
            pnlNext.ResumeLayout(false);
            pnlNext.PerformLayout();
            tabAddresses.ResumeLayout(false);
            tabAddresses.PerformLayout();
            tabComplaints.ResumeLayout(false);
            tabComplaints.PerformLayout();
            tabRecycling.ResumeLayout(false);
            tabRecycling.PerformLayout();
            tabCollections.ResumeLayout(false);
            tabCollections.PerformLayout();
            tabHome.ResumeLayout(false);
            tabHome.PerformLayout();
            pnlSidebar.ResumeLayout(false);
            pnlSidebar.PerformLayout();
            tabMain.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabMain;
        private Panel pnlSidebar;
        private PictureBox picLogo;
        private Label lblAppName;
        private Label lblRole;
        private Button btnNavHome;
        private Button btnNavCollections;
        private Button btnNavRecycling;
        private Button btnNavComplaints;
        private Button btnNavAddresses;
        private Label lblHello;
        private Button btnSignOut;
        private TabPage tabHome;
        private TabPage tabCollections;
        private TabPage tabRecycling;
        private TabPage tabComplaints;
        private TabPage tabAddresses;
        private Label lblHomeTitle;
        private Label lblHomeDate;
        private Panel pnlNext;
        private Label lblNextHeading;
        private Label lblNextDate;
        private Label lblNextDetails;
        private Label lblNextStatus;
        private Panel pnlStatRecycling;
        private Label lblStatRecyclingTitle;
        private Label lblStatRecycling;
        private Panel pnlStatComplaints;
        private Label lblStatComplaintsTitle;
        private Label lblStatComplaints;
        private Label lblRecentTitle;
        private DataGridView dgvHomeCollections;
        private Label lblCollectionsTitle;
        private Panel pnlRequest;
        private Label lblRequestHeading;
        private Label lblRequestHint;
        private Label lblColType;
        private ComboBox cboColType;
        private Label lblColAddress;
        private ComboBox cboColAddress;
        private Label lblColDate;
        private DateTimePicker dtpColDate;
        private Label lblColNotes;
        private TextBox txtColNotes;
        private Button btnRequestCollection;
        private DataGridView dgvMyCollections;
        private Button btnCancelCollection;
        private Label lblRecyclingTitle;
        private Panel pnlRecycle;
        private Label lblRecycleHeading;
        private Label lblRecycleHint;
        private Label lblRecCategory;
        private ComboBox cboRecCategory;
        private Label lblRecBags;
        private NumericUpDown nudRecBags;
        private Label lblRecAddress;
        private ComboBox cboRecAddress;
        private Label lblRecDate;
        private DateTimePicker dtpRecDate;
        private Button btnSubmitRecycling;
        private DataGridView dgvMyRecycling;
        private Label lblComplaintsTitle;
        private Panel pnlComplaint;
        private Label lblComplaintHeading;
        private Label lblComplaintHint;
        private Label lblCompType;
        private ComboBox cboCompType;
        private Label lblCompCollection;
        private ComboBox cboCompCollection;
        private Label lblCompDescription;
        private TextBox txtCompDescription;
        private Label lblCharCount;
        private Button btnSubmitComplaint;
        private DataGridView dgvMyComplaints;
        private Label lblResponseTitle;
        private TextBox txtCompResponse;
        private Label lblAddressesTitle;
        private Panel pnlAddress;
        private Label lblAddressHeading;
        private Label lblAddrStreet;
        private TextBox txtAddrStreet;
        private Label lblAddrSuburb;
        private TextBox txtAddrSuburb;
        private Label lblAddrCity;
        private TextBox txtAddrCity;
        private Label lblAddrPostal;
        private TextBox txtAddrPostal;
        private Button btnSaveAddress;
        private Label lblSavedTitle;
        private ListBox lstAddresses;
        private Button btnRemoveAddress;
    }
}
