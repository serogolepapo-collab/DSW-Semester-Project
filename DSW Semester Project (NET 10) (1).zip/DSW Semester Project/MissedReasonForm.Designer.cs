namespace DSW_Semester_Project
{
    partial class MissedReasonForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblQuestion = new Label();
            lblQuestionHint = new Label();
            cboReason = new ComboBox();
            btnReport = new Button();
            btnCancel = new Button();
            SuspendLayout();
            // 
            // lblQuestion
            // 
            lblQuestion.AutoSize = true;
            lblQuestion.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            lblQuestion.ForeColor = Color.FromArgb(22, 32, 26);
            lblQuestion.Location = new Point(24, 20);
            lblQuestion.Name = "lblQuestion";
            lblQuestion.TabIndex = 0;
            lblQuestion.Text = "Why couldn't you collect?";
            // 
            // lblQuestionHint
            // 
            lblQuestionHint.AutoSize = true;
            lblQuestionHint.Font = new Font("Segoe UI", 9.5F);
            lblQuestionHint.ForeColor = Color.FromArgb(95, 107, 99);
            lblQuestionHint.Location = new Point(26, 52);
            lblQuestionHint.Name = "lblQuestionHint";
            lblQuestionHint.TabIndex = 1;
            lblQuestionHint.Text = "The resident and the office will see this.";
            // 
            // cboReason
            // 
            cboReason.DropDownStyle = ComboBoxStyle.DropDownList;
            cboReason.Font = new Font("Segoe UI", 10.5F);
            cboReason.FormattingEnabled = true;
            cboReason.Items.AddRange(new object[] { "Bin not put out", "Access blocked", "Wrong waste in bin", "Vehicle breakdown", "Unsafe to stop" });
            cboReason.Location = new Point(26, 90);
            cboReason.Name = "cboReason";
            cboReason.Size = new Size(368, 32);
            cboReason.TabIndex = 2;
            // 
            // btnReport
            // 
            btnReport.BackColor = Color.FromArgb(30, 90, 60);
            btnReport.Cursor = Cursors.Hand;
            btnReport.FlatAppearance.BorderSize = 0;
            btnReport.FlatStyle = FlatStyle.Flat;
            btnReport.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnReport.ForeColor = Color.White;
            btnReport.Location = new Point(26, 160);
            btnReport.Name = "btnReport";
            btnReport.Size = new Size(180, 44);
            btnReport.TabIndex = 3;
            btnReport.Text = "Report";
            btnReport.UseVisualStyleBackColor = false;
            btnReport.Click += btnReport_Click;
            // 
            // btnCancel
            // 
            btnCancel.BackColor = Color.White;
            btnCancel.Cursor = Cursors.Hand;
            btnCancel.FlatAppearance.BorderColor = Color.FromArgb(30, 90, 60);
            btnCancel.FlatStyle = FlatStyle.Flat;
            btnCancel.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnCancel.ForeColor = Color.FromArgb(30, 90, 60);
            btnCancel.Location = new Point(214, 160);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(180, 44);
            btnCancel.TabIndex = 4;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = false;
            btnCancel.Click += btnCancel_Click;
            // 
            // MissedReasonForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AcceptButton = btnReport;
            BackColor = Color.White;
            CancelButton = btnCancel;
            ClientSize = new Size(420, 230);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterParent;
            Text = "Couldn't collect";
            Controls.Add(lblQuestion);
            Controls.Add(lblQuestionHint);
            Controls.Add(cboReason);
            Controls.Add(btnReport);
            Controls.Add(btnCancel);
            Name = "MissedReasonForm";
            ResumeLayout(false);
        }

        #endregion

        private Label lblQuestion;
        private Label lblQuestionHint;
        private ComboBox cboReason;
        private Button btnReport;
        private Button btnCancel;
    }
}
