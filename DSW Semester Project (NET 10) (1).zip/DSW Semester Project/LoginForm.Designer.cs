namespace DSW_Semester_Project
{
    partial class LoginForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pnlLoginCard = new Panel();
            pnlBrand = new Panel();
            lblBrandTitle = new Label();
            lblBrandSubtitle = new Label();
            lblBrandText = new Label();
            picBrandIcon = new PictureBox();
            picLoginLogo = new PictureBox();
            lblWelcome = new Label();
            lblSignInHint = new Label();
            lblUsername = new Label();
            txtUsername = new TextBox();
            lblPassword = new Label();
            txtPassword = new TextBox();
            chkShowPassword = new CheckBox();
            btnLogin = new Button();
            lblNoAccount = new Label();
            btnRegister = new Button();
            lblRoleHint = new Label();
            pnlLoginCard.SuspendLayout();
            pnlBrand.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)picBrandIcon).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picLoginLogo).BeginInit();
            SuspendLayout();
            // 
            // pnlLoginCard
            // 
            pnlLoginCard.Controls.Add(picLoginLogo);
            pnlLoginCard.Controls.Add(lblWelcome);
            pnlLoginCard.Controls.Add(lblSignInHint);
            pnlLoginCard.Controls.Add(lblUsername);
            pnlLoginCard.Controls.Add(txtUsername);
            pnlLoginCard.Controls.Add(lblPassword);
            pnlLoginCard.Controls.Add(txtPassword);
            pnlLoginCard.Controls.Add(chkShowPassword);
            pnlLoginCard.Controls.Add(btnLogin);
            pnlLoginCard.Controls.Add(lblNoAccount);
            pnlLoginCard.Controls.Add(btnRegister);
            pnlLoginCard.Controls.Add(lblRoleHint);
            pnlLoginCard.BackColor = Color.White;
            pnlLoginCard.BorderStyle = BorderStyle.FixedSingle;
            pnlLoginCard.Location = new Point(590, 60);
            pnlLoginCard.Name = "pnlLoginCard";
            pnlLoginCard.Size = new Size(470, 560);
            pnlLoginCard.TabIndex = 0;
            // 
            // pnlBrand
            // 
            pnlBrand.Controls.Add(lblBrandTitle);
            pnlBrand.Controls.Add(lblBrandSubtitle);
            pnlBrand.Controls.Add(lblBrandText);
            pnlBrand.Controls.Add(picBrandIcon);
            pnlBrand.BackgroundImage = Properties.Resources.brand;
            pnlBrand.BackgroundImageLayout = ImageLayout.Stretch;
            pnlBrand.Dock = DockStyle.Left;
            pnlBrand.Name = "pnlBrand";
            pnlBrand.Size = new Size(540, 680);
            pnlBrand.TabIndex = 1;
            // 
            // lblBrandTitle
            // 
            lblBrandTitle.AutoSize = true;
            lblBrandTitle.BackColor = Color.Transparent;
            lblBrandTitle.Font = new Font("Segoe UI", 40F, FontStyle.Bold);
            lblBrandTitle.ForeColor = Color.FromArgb(232, 224, 203);
            lblBrandTitle.Location = new Point(34, 120);
            lblBrandTitle.Name = "lblBrandTitle";
            lblBrandTitle.TabIndex = 0;
            lblBrandTitle.Text = "SMART WASTE";
            // 
            // lblBrandSubtitle
            // 
            lblBrandSubtitle.AutoSize = true;
            lblBrandSubtitle.BackColor = Color.Transparent;
            lblBrandSubtitle.Font = new Font("Segoe UI", 24F);
            lblBrandSubtitle.ForeColor = Color.FromArgb(232, 224, 203);
            lblBrandSubtitle.Location = new Point(40, 200);
            lblBrandSubtitle.Name = "lblBrandSubtitle";
            lblBrandSubtitle.TabIndex = 1;
            lblBrandSubtitle.Text = "COLLECTION && RECYCLING";
            // 
            // lblBrandText
            // 
            lblBrandText.BackColor = Color.Transparent;
            lblBrandText.Font = new Font("Segoe UI", 15F);
            lblBrandText.ForeColor = Color.White;
            lblBrandText.Location = new Point(42, 280);
            lblBrandText.Name = "lblBrandText";
            lblBrandText.Size = new Size(440, 130);
            lblBrandText.TabIndex = 2;
            lblBrandText.Text = "Connecting Residents, Collection Staff, and Administrators in One Centralised Waste Management Platform.";
            // 
            // picBrandIcon
            // 
            picBrandIcon.BackColor = Color.Transparent;
            picBrandIcon.Image = Properties.Resources.logo_white;
            picBrandIcon.Location = new Point(44, 500);
            picBrandIcon.Name = "picBrandIcon";
            picBrandIcon.Size = new Size(96, 106);
            picBrandIcon.SizeMode = PictureBoxSizeMode.Zoom;
            picBrandIcon.TabIndex = 3;
            picBrandIcon.TabStop = false;
            // 
            // picLoginLogo
            // 
            picLoginLogo.Image = Properties.Resources.logo_green;
            picLoginLogo.Location = new Point(196, 22);
            picLoginLogo.Name = "picLoginLogo";
            picLoginLogo.Size = new Size(76, 84);
            picLoginLogo.SizeMode = PictureBoxSizeMode.Zoom;
            picLoginLogo.TabIndex = 0;
            picLoginLogo.TabStop = false;
            // 
            // lblWelcome
            // 
            lblWelcome.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            lblWelcome.ForeColor = Color.FromArgb(22, 32, 26);
            lblWelcome.Location = new Point(0, 116);
            lblWelcome.Name = "lblWelcome";
            lblWelcome.Size = new Size(468, 40);
            lblWelcome.TabIndex = 1;
            lblWelcome.Text = "Welcome to Smart Recycling!";
            lblWelcome.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblSignInHint
            // 
            lblSignInHint.Font = new Font("Segoe UI", 10F);
            lblSignInHint.ForeColor = Color.FromArgb(95, 107, 99);
            lblSignInHint.Location = new Point(0, 156);
            lblSignInHint.Name = "lblSignInHint";
            lblSignInHint.Size = new Size(468, 24);
            lblSignInHint.TabIndex = 2;
            lblSignInHint.Text = "Sign in to continue";
            lblSignInHint.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblUsername
            // 
            lblUsername.AutoSize = true;
            lblUsername.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblUsername.ForeColor = Color.FromArgb(22, 32, 26);
            lblUsername.Location = new Point(44, 200);
            lblUsername.Name = "lblUsername";
            lblUsername.TabIndex = 3;
            lblUsername.Text = "Username:";
            // 
            // txtUsername
            // 
            txtUsername.Font = new Font("Segoe UI", 11F);
            txtUsername.Location = new Point(44, 224);
            txtUsername.Name = "txtUsername";
            txtUsername.PlaceholderText = "Username";
            txtUsername.Size = new Size(380, 31);
            txtUsername.TabIndex = 4;
            // 
            // lblPassword
            // 
            lblPassword.AutoSize = true;
            lblPassword.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblPassword.ForeColor = Color.FromArgb(22, 32, 26);
            lblPassword.Location = new Point(44, 269);
            lblPassword.Name = "lblPassword";
            lblPassword.TabIndex = 5;
            lblPassword.Text = "Password:";
            // 
            // txtPassword
            // 
            txtPassword.Font = new Font("Segoe UI", 11F);
            txtPassword.Location = new Point(44, 293);
            txtPassword.Name = "txtPassword";
            txtPassword.PlaceholderText = "Password";
            txtPassword.Size = new Size(380, 31);
            txtPassword.TabIndex = 6;
            txtPassword.UseSystemPasswordChar = true;
            // 
            // chkShowPassword
            // 
            chkShowPassword.AutoSize = true;
            chkShowPassword.Font = new Font("Segoe UI", 9F);
            chkShowPassword.ForeColor = Color.FromArgb(95, 107, 99);
            chkShowPassword.Location = new Point(44, 330);
            chkShowPassword.Name = "chkShowPassword";
            chkShowPassword.TabIndex = 7;
            chkShowPassword.Text = "Show password";
            chkShowPassword.CheckedChanged += chkShowPassword_CheckedChanged;
            // 
            // btnLogin
            // 
            btnLogin.BackColor = Color.FromArgb(30, 90, 60);
            btnLogin.Cursor = Cursors.Hand;
            btnLogin.FlatAppearance.BorderSize = 0;
            btnLogin.FlatStyle = FlatStyle.Flat;
            btnLogin.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnLogin.ForeColor = Color.White;
            btnLogin.Location = new Point(44, 364);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(380, 46);
            btnLogin.TabIndex = 8;
            btnLogin.Text = "Login";
            btnLogin.UseVisualStyleBackColor = false;
            btnLogin.Click += btnLogin_Click;
            // 
            // lblNoAccount
            // 
            lblNoAccount.AutoSize = true;
            lblNoAccount.Font = new Font("Segoe UI", 10.5F);
            lblNoAccount.ForeColor = Color.FromArgb(22, 32, 26);
            lblNoAccount.Location = new Point(44, 436);
            lblNoAccount.Name = "lblNoAccount";
            lblNoAccount.TabIndex = 9;
            lblNoAccount.Text = "Don't have an account yet?";
            // 
            // btnRegister
            // 
            btnRegister.BackColor = Color.White;
            btnRegister.Cursor = Cursors.Hand;
            btnRegister.FlatAppearance.BorderColor = Color.FromArgb(30, 90, 60);
            btnRegister.FlatStyle = FlatStyle.Flat;
            btnRegister.Font = new Font("Segoe UI", 10.5F, FontStyle.Bold);
            btnRegister.ForeColor = Color.FromArgb(30, 90, 60);
            btnRegister.Location = new Point(280, 428);
            btnRegister.Name = "btnRegister";
            btnRegister.Size = new Size(144, 38);
            btnRegister.TabIndex = 10;
            btnRegister.Text = "Register";
            btnRegister.UseVisualStyleBackColor = false;
            btnRegister.Click += btnRegister_Click;
            // 
            // lblRoleHint
            // 
            lblRoleHint.Font = new Font("Segoe UI", 9F);
            lblRoleHint.ForeColor = Color.FromArgb(95, 107, 99);
            lblRoleHint.Location = new Point(44, 484);
            lblRoleHint.Name = "lblRoleHint";
            lblRoleHint.Size = new Size(380, 70);
            lblRoleHint.TabIndex = 11;
            lblRoleHint.Text = "Residents: create an account with Register.\r\nAdministrators: any name + Admin@123\r\nCollection staff: any name + Staff@123";
            // 
            // LoginForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AcceptButton = btnLogin;
            BackColor = Color.FromArgb(243, 244, 239);
            ClientSize = new Size(1100, 680);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Smart Waste Collection & Recycling - Login";
            Controls.Add(pnlLoginCard);
            Controls.Add(pnlBrand);
            Name = "LoginForm";
            ((System.ComponentModel.ISupportInitialize)picLoginLogo).EndInit();
            ((System.ComponentModel.ISupportInitialize)picBrandIcon).EndInit();
            pnlBrand.ResumeLayout(false);
            pnlBrand.PerformLayout();
            pnlLoginCard.ResumeLayout(false);
            pnlLoginCard.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel pnlLoginCard;
        private Panel pnlBrand;
        private Label lblBrandTitle;
        private Label lblBrandSubtitle;
        private Label lblBrandText;
        private PictureBox picBrandIcon;
        private PictureBox picLoginLogo;
        private Label lblWelcome;
        private Label lblSignInHint;
        private Label lblUsername;
        private TextBox txtUsername;
        private Label lblPassword;
        private TextBox txtPassword;
        private CheckBox chkShowPassword;
        private Button btnLogin;
        private Label lblNoAccount;
        private Button btnRegister;
        private Label lblRoleHint;
    }
}
