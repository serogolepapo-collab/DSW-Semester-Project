namespace DSW_Semester_Project
{
    // A driver / collection worker. Only on-duty staff can be given jobs.
    public class StaffMember : User
    {
        public bool IsOnDuty { get; set; } = true;

        public StaffMember(string username, string fullName, string email, string phone, string password, bool isOnDuty)
            : base(username, fullName, email, phone, password)
        {
            IsOnDuty = isOnDuty;
        }

        public override string GetRole()
        {
            return "Staff";
        }

        public override Form OpenDashboard()
        {
            return new StaffForm(this);
        }

        // Adds the extra field to the end of the parent's line
        public override string ToFileLine()
        {
            return base.ToFileLine() + "|" + IsOnDuty;
        }

        // Shown in combo boxes
        public override string ToString()
        {
            string duty = IsOnDuty ? "on duty" : "off duty";
            return $"{FullName} ({duty})";
        }
    }
}
