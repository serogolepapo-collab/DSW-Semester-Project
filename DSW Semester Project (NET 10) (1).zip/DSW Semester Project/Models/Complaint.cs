namespace DSW_Semester_Project
{
    // A problem reported by a resident.
    // Submitted -> UnderReview -> Resolved (steps can't be skipped).
    public class Complaint
    {
        private string _description = "";

        public string Id { get; set; } = "";
        public string ResidentUsername { get; set; } = "";
        public string ComplaintType { get; set; } = "";
        public string CollectionId { get; set; } = "";    // only for missed collections
        public DateTime DateReported { get; set; }
        public ComplaintStatus Status { get; set; } = ComplaintStatus.Submitted;
        public string Response { get; set; } = "";

        public string Description
        {
            get { return _description; }
            set
            {
                string text = (value ?? "").Trim();
                if (text.Length < 10)
                    throw new ArgumentException("Please describe the problem (at least 10 characters).");
                if (text.Length > 300)
                    throw new ArgumentException("Keep the description under 300 characters.");
                // New lines and | would break our one-line-per-record file
                _description = text.Replace("|", "/").Replace(Environment.NewLine, " ");
            }
        }

        public Complaint(string id, string residentUsername, string complaintType, string collectionId, string description)
        {
            if (string.IsNullOrWhiteSpace(complaintType))
                throw new ArgumentException("Choose the type of problem.");
            if (complaintType == "Missed collection" && string.IsNullOrWhiteSpace(collectionId))
                throw new ArgumentException("Choose which collection was missed.");

            Id = id;
            ResidentUsername = residentUsername;
            ComplaintType = complaintType;
            CollectionId = collectionId;
            Description = description;
            DateReported = DateTime.Today;
        }

        public void StartReview()
        {
            if (Status != ComplaintStatus.Submitted)
                throw new InvalidOperationException("This complaint is already being reviewed or resolved.");
            Status = ComplaintStatus.UnderReview;
        }

        public void Resolve(string response)
        {
            if (Status != ComplaintStatus.UnderReview)
                throw new InvalidOperationException("Start the review before resolving.");
            if (string.IsNullOrWhiteSpace(response))
                throw new ArgumentException("Write a reply to the resident.");
            Status = ComplaintStatus.Resolved;
            Response = response.Trim().Replace("|", "/").Replace(Environment.NewLine, " ");
        }

        public string ToFileLine()
        {
            return $"{Id}|{ResidentUsername}|{ComplaintType}|{CollectionId}|{Description}|{DateReported:yyyy-MM-dd}|{Status}|{Response}";
        }

        public static Complaint FromFileLine(string line)
        {
            string[] p = line.Split('|');
            Complaint c = new Complaint(p[0], p[1], p[2], p[3], p[4]);
            c.DateReported = DateTime.Parse(p[5]);
            c.Status = Enum.Parse<ComplaintStatus>(p[6]);
            c.Response = p[7];
            return c;
        }
    }
}
