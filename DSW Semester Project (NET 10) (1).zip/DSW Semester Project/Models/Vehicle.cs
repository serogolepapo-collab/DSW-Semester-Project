namespace DSW_Semester_Project
{
    // A collection truck. A vehicle in maintenance can't be given to a collection.
    public class Vehicle
    {
        private int _capacityTons;

        public string Registration { get; set; } = "";
        public string VehicleType { get; set; } = "";
        public VehicleStatus Status { get; set; } = VehicleStatus.Available;
        public string DriverUsername { get; set; } = "";   // the staff member who usually drives it

        public int CapacityTons
        {
            get { return _capacityTons; }
            set
            {
                if (value < 1 || value > 40)
                    throw new ArgumentException("Capacity must be between 1 and 40 tons.");
                _capacityTons = value;
            }
        }

        public Vehicle(string registration, string vehicleType, int capacityTons)
        {
            if (registration == null || registration.Trim().Length < 5)
                throw new ArgumentException("Enter a valid registration, e.g. CA 452-118.");

            Registration = registration.Trim().ToUpper();
            VehicleType = vehicleType;
            CapacityTons = capacityTons;
        }

        public void SendToMaintenance()
        {
            Status = VehicleStatus.Maintenance;
        }

        public void MakeAvailable()
        {
            Status = VehicleStatus.Available;
        }

        public override string ToString()
        {
            return $"{Registration} ({Status})";
        }

        public string ToFileLine()
        {
            return $"{Registration}|{VehicleType}|{CapacityTons}|{Status}|{DriverUsername}";
        }

        public static Vehicle FromFileLine(string line)
        {
            string[] p = line.Split('|');
            Vehicle v = new Vehicle(p[0], p[1], int.Parse(p[2]));
            v.Status = Enum.Parse<VehicleStatus>(p[3]);
            v.DriverUsername = p[4];
            return v;
        }
    }
}
