namespace DSW_Semester_Project
{
    // A place where waste is collected. A resident can save more than one.
    public class Address
    {
        private string _postalCode = "";

        public string ResidentUsername { get; set; } = "";
        public string Street { get; set; } = "";
        public string Suburb { get; set; } = "";
        public string City { get; set; } = "";

        public string PostalCode
        {
            get { return _postalCode; }
            set
            {
                if (!Validator.IsValidPostalCode(value))
                    throw new ArgumentException("Postal code must be 4 digits, e.g. 2092.");
                _postalCode = value.Trim();
            }
        }

        public Address(string residentUsername, string street, string suburb, string city, string postalCode)
        {
            if (string.IsNullOrWhiteSpace(street) || string.IsNullOrWhiteSpace(suburb) || string.IsNullOrWhiteSpace(city))
                throw new ArgumentException("Please fill in the street, suburb and city.");

            ResidentUsername = residentUsername;
            Street = street.Trim();
            Suburb = suburb.Trim();
            City = city.Trim();
            PostalCode = postalCode;
        }

        // Used by combo boxes and list boxes to show the address
        public override string ToString()
        {
            return $"{Street}, {Suburb}, {City} {PostalCode}";
        }

        public string ToFileLine()
        {
            return $"{ResidentUsername}|{Street}|{Suburb}|{City}|{PostalCode}";
        }

        public static Address FromFileLine(string line)
        {
            string[] p = line.Split('|');
            return new Address(p[0], p[1], p[2], p[3], p[4]);
        }
    }
}
