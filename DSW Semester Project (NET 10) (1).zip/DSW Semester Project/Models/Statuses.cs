namespace DSW_Semester_Project
{
    // An enum is a fixed list of allowed values (not in the slides, but it stops typing mistakes like "Complete" vs "Completed").

    // Scheduled -> Assigned -> InProgress -> Completed   (or Missed / Cancelled)
    public enum CollectionStatus { Scheduled, Assigned, InProgress, Completed, Missed, Cancelled }

    // Pending -> Approved -> Collected   (or Rejected)
    public enum RequestStatus { Pending, Approved, Collected, Rejected }

    // Submitted -> UnderReview -> Resolved
    public enum ComplaintStatus { Submitted, UnderReview, Resolved }

    public enum VehicleStatus { Available, Maintenance }
}
