namespace DSW_Semester_Project
{
    // A household that receives waste-collection services.
    public class Resident : User
    {
        public Resident(string username, string fullName, string email, string phone, string password)
            : base(username, fullName, email, phone, password)
        {
        }

        public override string GetRole()
        {
            return "Resident";
        }

        public override Form OpenDashboard()
        {
            return new ResidentForm(this);
        }
    }
}
