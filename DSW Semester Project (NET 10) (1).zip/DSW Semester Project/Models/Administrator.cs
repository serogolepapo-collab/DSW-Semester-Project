namespace DSW_Semester_Project
{
    // Municipal / company staff who manage the whole system.
    public class Administrator : User
    {
        public Administrator(string username, string fullName, string email, string phone, string password)
            : base(username, fullName, email, phone, password)
        {
        }

        public override string GetRole()
        {
            return "Admin";
        }

        public override Form OpenDashboard()
        {
            return new AdminForm(this);
        }
    }
}
