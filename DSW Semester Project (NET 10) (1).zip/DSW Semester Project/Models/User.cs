namespace DSW_Semester_Project
{
    // Parent class for everyone who can log in.
    // Resident, StaffMember and Administrator inherit from it (Unit 7: inheritance).
    public class User
    {
        // Private fields: only reachable through the properties below (Unit 6 + 7: encapsulation)
        private string _username = "";
        private string _password = "";

        public string FullName { get; set; } = "";
        public string Email { get; set; } = "";
        public string Phone { get; set; } = "";

        public string Username
        {
            get { return _username; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Username cannot be empty.");
                _username = value.Trim();
            }
        }

        public string Password
        {
            get { return _password; }
            set
            {
                if (value == null || value.Length < 8)
                    throw new ArgumentException("Password must be at least 8 characters.");
                _password = value;
            }
        }

        // Default constructor
        public User()
        {
        }

        // Parameterised constructor
        public User(string username, string fullName, string email, string phone, string password)
        {
            Username = username;
            FullName = fullName;
            Email = email;
            Phone = phone;
            Password = password;
        }

        public bool CheckPassword(string password)
        {
            return Password == password;
        }

        // Polymorphism: every child class overrides these methods (Unit 7: virtual / override)
        public virtual string GetRole()
        {
            return "User";
        }

        // Each child returns the screen it should see after login
        public virtual Form OpenDashboard()
        {
            return null;
        }

        // One line for users.txt, fields separated by |
        // Note: a real system would store a hashed password, not plain text.
        public virtual string ToFileLine()
        {
            return $"{GetRole()}|{Username}|{FullName}|{Email}|{Phone}|{Password}";
        }
    }
}
