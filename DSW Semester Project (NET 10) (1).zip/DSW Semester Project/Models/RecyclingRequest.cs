namespace DSW_Semester_Project
{
    // A resident asks for sorted recyclables to be collected.
    // Pending -> Approved (a collection is scheduled) -> Collected, or Rejected.
    public class RecyclingRequest
    {
        private int _bags;

        public string Id { get; set; } = "";
        public string ResidentUsername { get; set; } = "";
        public string Address { get; set; } = "";
        public string Category { get; set; } = "";       // Plastic, Glass, Paper or Metal
        public DateTime PreferredDate { get; set; }
        public RequestStatus Status { get; set; } = RequestStatus.Pending;
        public string CollectionId { get; set; } = "";
        public string AdminNote { get; set; } = "";

        public int Bags
        {
            get { return _bags; }
            set
            {
                if (value < 1 || value > 20)
                    throw new ArgumentException("Number of bags must be between 1 and 20.");
                _bags = value;
            }
        }

        public RecyclingRequest(string id, string residentUsername, string address, string category, int bags, DateTime preferredDate)
        {
            if (string.IsNullOrWhiteSpace(category))
                throw new ArgumentException("Choose a recycling category.");
            if (string.IsNullOrWhiteSpace(address))
                throw new ArgumentException("Choose an address.");

            Id = id;
            ResidentUsername = residentUsername;
            Address = address;
            Category = category;
            Bags = bags;
            PreferredDate = preferredDate.Date;
        }

        public void Approve(string collectionId)
        {
            if (Status != RequestStatus.Pending)
                throw new InvalidOperationException("Only pending requests can be approved.");
            Status = RequestStatus.Approved;
            CollectionId = collectionId;
            AdminNote = "Scheduled as " + collectionId;
        }

        public void Reject(string reason)
        {
            if (Status != RequestStatus.Pending)
                throw new InvalidOperationException("Only pending requests can be rejected.");
            if (string.IsNullOrWhiteSpace(reason))
                throw new ArgumentException("Give the resident a reason.");
            Status = RequestStatus.Rejected;
            AdminNote = reason.Trim().Replace("|", "/");
        }

        public void MarkCollected()
        {
            Status = RequestStatus.Collected;
            AdminNote = "Collected";
        }

        public string ToFileLine()
        {
            return $"{Id}|{ResidentUsername}|{Address}|{Category}|{Bags}|{PreferredDate:yyyy-MM-dd}|{Status}|{CollectionId}|{AdminNote}";
        }

        public static RecyclingRequest FromFileLine(string line)
        {
            string[] p = line.Split('|');
            RecyclingRequest r = new RecyclingRequest(p[0], p[1], p[2], p[3], int.Parse(p[4]), DateTime.Parse(p[5]));
            r.Status = Enum.Parse<RequestStatus>(p[6]);
            r.CollectionId = p[7];
            r.AdminNote = p[8];
            return r;
        }
    }
}
