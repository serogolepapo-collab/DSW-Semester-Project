namespace DSW_Semester_Project
{
    // One pickup. The status can only move forward through the lifecycle:
    // Scheduled -> Assigned -> InProgress -> Completed (or Missed / Cancelled)
    public class WasteCollection
    {
        public string Id { get; set; } = "";
        public string ResidentUsername { get; set; } = "";
        public string Address { get; set; } = "";
        public string CollectionType { get; set; } = "";
        public DateTime Date { get; set; }
        public string DriverUsername { get; set; } = "";
        public string VehicleRegistration { get; set; } = "";
        public CollectionStatus Status { get; set; } = CollectionStatus.Scheduled;
        public string Notes { get; set; } = "";
        public string RequestId { get; set; } = "";   // filled in when it came from a recycling request

        public WasteCollection(string id, string residentUsername, string address, string collectionType, DateTime date, string notes)
        {
            if (string.IsNullOrWhiteSpace(collectionType))
                throw new ArgumentException("Choose a collection type.");
            if (string.IsNullOrWhiteSpace(address))
                throw new ArgumentException("Choose an address.");
            if (date.Date < DateTime.Today)
                throw new ArgumentException("The collection date can't be in the past.");

            Id = id;
            ResidentUsername = residentUsername;
            Address = address;
            CollectionType = collectionType;
            Date = date.Date;
            Notes = notes.Replace("|", "/");   // | is our separator in the file
        }

        // ---------- lifecycle methods (Unit 7: abstraction - callers just call Assign, Start, ...) ----------

        public void Assign(StaffMember driver, Vehicle vehicle)
        {
            if (Status != CollectionStatus.Scheduled && Status != CollectionStatus.Assigned)
                throw new InvalidOperationException($"This collection is {Status} and can't be assigned.");
            if (driver == null)
                throw new ArgumentException("Choose a driver.");
            if (vehicle == null)
                throw new ArgumentException("Choose a vehicle.");
            if (!driver.IsOnDuty)
                throw new InvalidOperationException($"{driver.FullName} is off duty.");
            if (vehicle.Status != VehicleStatus.Available)
                throw new InvalidOperationException($"{vehicle.Registration} is in maintenance. Choose another vehicle.");

            DriverUsername = driver.Username;
            VehicleRegistration = vehicle.Registration;
            Status = CollectionStatus.Assigned;
        }

        public void Start()
        {
            if (Status != CollectionStatus.Assigned)
                throw new InvalidOperationException("Only an assigned job can be started.");
            Status = CollectionStatus.InProgress;
        }

        public void Complete()
        {
            if (Status != CollectionStatus.InProgress)
                throw new InvalidOperationException("Start the job before marking it completed.");
            Status = CollectionStatus.Completed;
        }

        public void MarkMissed(string reason)
        {
            if (Status != CollectionStatus.Assigned && Status != CollectionStatus.InProgress)
                throw new InvalidOperationException("Only an assigned or started job can be marked as missed.");
            if (string.IsNullOrWhiteSpace(reason))
                throw new ArgumentException("Choose a reason.");
            Status = CollectionStatus.Missed;
            Notes = "Missed: " + reason.Replace("|", "/");
        }

        public void Cancel()
        {
            if (Status != CollectionStatus.Scheduled && Status != CollectionStatus.Assigned)
                throw new InvalidOperationException("Only collections that haven't started can be cancelled.");
            Status = CollectionStatus.Cancelled;
        }

        // ---------- saving / loading ----------

        public string ToFileLine()
        {
            return $"{Id}|{ResidentUsername}|{Address}|{CollectionType}|{Date:yyyy-MM-dd}|{DriverUsername}|{VehicleRegistration}|{Status}|{Notes}|{RequestId}";
        }

        public static WasteCollection FromFileLine(string line)
        {
            string[] p = line.Split('|');
            // Old dates are allowed when loading, so we build it with today's date first and then set the real one.
            WasteCollection c = new WasteCollection(p[0], p[1], p[2], p[3], DateTime.Today, p[8]);
            c.Date = DateTime.Parse(p[4]);
            c.DriverUsername = p[5];
            c.VehicleRegistration = p[6];
            c.Status = Enum.Parse<CollectionStatus>(p[7]);
            c.RequestId = p[9];
            return c;
        }
    }
}
