# Smart Waste Collection & Recycling (C# WinForms, .NET 10)

## How to run

1. Open `DSW Semester Project.sln` in Visual Studio.
2. Press **F5**.

The app starts **blank**: no users, no collections. The data is saved in `bin\Debug\net10.0-windows\*.txt`.

| Role | Username | Password |
|---|---|---|
| Resident | Register on the login screen | Your own |
| Administrator | Any name | `Admin@123` |
| Collection staff | Any name | `Staff@123` |

How a job reaches the driver:

1. The driver logs in once (any name + `Staff@123`), so the admin can choose them.
2. The resident registers and requests a collection.
3. The admin opens **Collections**, selects the request, picks that driver and a truck, and clicks **Assign**.
4. The driver logs in with the **same name** and sees the job on **My jobs**.

To start again from blank, close the app and delete the `.txt` files in `bin\Debug\net10.0-windows`.

## Folders

- **Models**
  - `User` is the parent class, with `Resident`, `StaffMember` and `Administrator` as its children.
  - The other models are `Address`, `WasteCollection`, `RecyclingRequest`, `Complaint`, `Vehicle` and the status enums.
- **Data**
  - `DataStore` reads and writes the `.txt` files.
  - `AccountManager` handles login and registration.
  - `Validator` checks passwords, emails, phone numbers and postal codes.
  - `SampleData` adds two trucks on the first run.
  - `Theme` has the shared colours and grid styling.
- **Forms**
  - `LoginForm` and `RegisterForm` are the sign-in screens.
  - `ResidentForm`, `AdminForm` and `StaffForm` are the three dashboards.
  - `MissedReasonForm` is the pop-up that asks staff why a collection was missed.
  - Every form has a `.Designer.cs` file, so you can open it in the designer.

## UML (inheritance)

```
                 User
  - _username, _password
  + Username, Password, FullName, Email, Phone
  + CheckPassword()
  + virtual GetRole(), OpenDashboard(), ToFileLine()
        ^              ^                 ^
        |              |                 |
    Resident      StaffMember       Administrator
                  + IsOnDuty
  (each one overrides GetRole() and OpenDashboard())
```

## Where each OOP idea is

| Idea | Where |
|---|---|
| Encapsulation | Private fields with validating properties: `User.Password`, `Address.PostalCode`, `Vehicle.CapacityTons`, `RecyclingRequest.Bags`, `Complaint.Description` |
| Abstraction | `WasteCollection.Assign()`, `Start()`, `Complete()`, `MarkMissed()`, `Cancel()`, and `Complaint.Resolve()` |
| Inheritance | `Resident : User`, `StaffMember : User`, `Administrator : User` |
| Polymorphism | `user.OpenDashboard()` in `LoginForm` opens a different screen for each role |
| Constructors | Default and parameterised constructors in `User`, and `base(...)` in the child classes |
| Text files | `DataStore`: `File.Exists`, `ReadAllLines`, `WriteAllLines`, `Split('|')`, try-catch |
