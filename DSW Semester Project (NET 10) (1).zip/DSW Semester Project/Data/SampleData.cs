namespace DSW_Semester_Project
{
    // Runs the first time the app starts (when users.txt doesn't exist yet).
    // There are no demo users or collections: everything starts blank.
    // We only add two trucks so the admin can assign a job straight away
    // (more can be added on the Vehicles & staff page).
    public static class SampleData
    {
        public static void Create()
        {
            DataStore.Vehicles.Add(new Vehicle("CA 452-118", "Compactor truck", 10));
            DataStore.Vehicles.Add(new Vehicle("CA 318-907", "Recycling truck", 6));
        }
    }
}
