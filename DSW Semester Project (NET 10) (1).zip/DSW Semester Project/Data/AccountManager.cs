namespace DSW_Semester_Project
{
    // Login and registration rules.
    public static class AccountManager
    {
        // Shared passwords: any name + this password logs in as an administrator / collection staff.
        public const string AdminPassword = "Admin@123";
        public const string StaffPassword = "Staff@123";

        public static User Login(string username, string password)
        {
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrEmpty(password))
                throw new ArgumentException("Enter your username and password.");

            User user = DataStore.FindUser(username);

            // A new name with a shared password: create that admin / staff account and save it
            if (user == null && (password == AdminPassword || password == StaffPassword))
            {
                if (!Validator.IsValidUsername(username))
                    throw new ArgumentException("Use 3 to 30 letters or numbers for your name.");

                string name = username.Trim();
                if (password == AdminPassword)
                    user = new Administrator(name, name, "", "", password);
                else
                    user = new StaffMember(name, name, "", "", password, true);

                DataStore.Users.Add(user);
                DataStore.SaveAll();
                return user;
            }

            if (user == null || !user.CheckPassword(password))
                throw new ArgumentException("Wrong username or password.");

            return user;
        }

        // Creates a resident and their first address. Throws an exception with a clear message if anything is wrong.
        public static Resident Register(string fullName, string email, string phone, string username, string password, string confirm,
                                        string street, string suburb, string city, string postalCode)
        {
            if (string.IsNullOrWhiteSpace(fullName) || fullName.Trim().Length < 3)
                throw new ArgumentException("Enter your full name.");
            if (!Validator.IsValidEmail(email))
                throw new ArgumentException("Enter a valid email, e.g. name@example.com.");
            if (!Validator.IsValidPhone(phone))
                throw new ArgumentException("Enter a 10-digit phone number, e.g. 071 234 5678.");
            if (!Validator.IsValidUsername(username))
                throw new ArgumentException("Username must be 3 to 30 letters or numbers.");
            if (DataStore.FindUser(username) != null)
                throw new ArgumentException("That username is already taken.");
            foreach (User u in DataStore.Users)
            {
                if (u.Email.ToLower() == email.Trim().ToLower())
                    throw new ArgumentException("An account with this email already exists.");
            }
            if (!Validator.IsValidPassword(password))
                throw new ArgumentException("Password needs 8+ characters with an uppercase letter, a lowercase letter and a number.");
            if (password == AdminPassword || password == StaffPassword)
                throw new ArgumentException("Please choose a different password.");
            if (password != confirm)
                throw new ArgumentException("The passwords don't match.");

            // The Address constructor checks the address fields
            Address address = new Address(username.Trim(), street, suburb, city, postalCode);
            Resident resident = new Resident(username.Trim(), fullName.Trim(), email.Trim(), phone.Replace(" ", ""), password);

            DataStore.Users.Add(resident);
            DataStore.Addresses.Add(address);
            DataStore.SaveAll();
            return resident;
        }
    }
}
