namespace DSW_Semester_Project
{
    // Input checks used by the forms (Unit 3: string methods, loops over characters).
    // "static" means we call them on the class itself: Validator.IsValidEmail(...)
    public static class Validator
    {
        // At least 8 characters with an uppercase letter, a lowercase letter and a number
        public static bool IsValidPassword(string password)
        {
            if (password == null || password.Length < 8) return false;

            bool hasUpper = false, hasLower = false, hasDigit = false;
            foreach (char c in password)
            {
                if (char.IsUpper(c)) hasUpper = true;
                if (char.IsLower(c)) hasLower = true;
                if (char.IsDigit(c)) hasDigit = true;
            }
            return hasUpper && hasLower && hasDigit;
        }

        // Must contain @ and a . after it, and no spaces
        public static bool IsValidEmail(string email)
        {
            string text = (email ?? "").Trim();
            int at = text.IndexOf('@');
            return at > 0 && text.LastIndexOf('.') > at + 1 && !text.EndsWith(".") && !text.Contains(" ");
        }

        // 10 digits starting with 0, e.g. 0712345678 (spaces are ignored)
        public static bool IsValidPhone(string phone)
        {
            string digits = (phone ?? "").Replace(" ", "");
            if (digits.Length != 10 || digits[0] != '0') return false;
            foreach (char c in digits)
            {
                if (!char.IsDigit(c)) return false;
            }
            return true;
        }

        // 4 digits, e.g. 2092
        public static bool IsValidPostalCode(string code)
        {
            string text = (code ?? "").Trim();
            return text.Length == 4 && int.TryParse(text, out _);
        }

        // Letters, numbers and spaces only, 3 to 30 characters
        public static bool IsValidUsername(string username)
        {
            string text = (username ?? "").Trim();
            if (text.Length < 3 || text.Length > 30) return false;
            foreach (char c in text)
            {
                if (!char.IsLetterOrDigit(c) && c != ' ') return false;
            }
            return true;
        }
    }
}
