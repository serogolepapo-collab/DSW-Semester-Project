namespace DSW_Semester_Project
{
    // Small helpers so every screen looks the same.
    public static class Theme
    {
        public static readonly Color Deep = Color.FromArgb(18, 53, 36);      // sidebar
        public static readonly Color Forest = Color.FromArgb(30, 90, 60);    // buttons, active menu item
        public static readonly Color Mint = Color.FromArgb(227, 239, 230);   // selected grid row

        // Shows a list in a grid, nicer column titles, and hides the columns we don't need
        public static void ShowList<T>(DataGridView grid, List<T> list, params string[] hiddenColumns)
        {
            grid.DataSource = null;
            grid.DataSource = list;

            grid.EnableHeadersVisualStyles = false;
            grid.ColumnHeadersDefaultCellStyle.BackColor = Deep;
            grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            grid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            grid.DefaultCellStyle.SelectionBackColor = Mint;
            grid.DefaultCellStyle.SelectionForeColor = Color.Black;
            grid.RowTemplate.Height = 30;

            foreach (DataGridViewColumn column in grid.Columns)
            {
                column.HeaderText = AddSpaces(column.HeaderText);
                if (column.ValueType == typeof(DateTime))
                    column.DefaultCellStyle.Format = "dd MMM yyyy";   // show the date without the time
            }
            foreach (string name in hiddenColumns)
            {
                if (grid.Columns.Contains(name)) grid.Columns[name].Visible = false;
            }
        }

        // "ResidentUsername" -> "Resident Username" (Unit 3: looping over the characters of a string)
        public static string AddSpaces(string text)
        {
            string result = "";
            for (int i = 0; i < text.Length; i++)
            {
                if (i > 0 && char.IsUpper(text[i])) result += " ";
                result += text[i];
            }
            return result;
        }

        // Colours the clicked sidebar button and resets the others
        public static void HighlightMenu(Panel sidebar, Button active)
        {
            foreach (Control control in sidebar.Controls)
            {
                if (control is Button button && button.Name.StartsWith("btnNav"))
                    button.BackColor = (button == active) ? Forest : Deep;
            }
        }

        public static void ShowError(string message)
        {
            MessageBox.Show(message, "Please check", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        public static void ShowInfo(string message)
        {
            MessageBox.Show(message, "Smart Waste", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
