namespace DSW_Semester_Project
{
    // Small helpers so every screen looks the same.
    public static class Theme
    {
        public static readonly Color Deep = Color.FromArgb(18, 53, 36);      // sidebar
        public static readonly Color Forest = Color.FromArgb(30, 90, 60);    // buttons, active menu item
        public static readonly Color Mint = Color.FromArgb(227, 239, 230);   // selected grid row

        // Shows a list in a grid, nicer column titles, and hides the columns we don't need
        public static void ShowList<T>(DataGridView grid, List<T> list, params string[] hiddenColumns)
        {
            grid.DataSource = null;
            grid.DataSource = list;

            grid.EnableHeadersVisualStyles = false;
            grid.ColumnHeadersDefaultCellStyle.BackColor = Deep;
            grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            grid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            grid.DefaultCellStyle.SelectionBackColor = Mint;
            grid.DefaultCellStyle.SelectionForeColor = Color.Black;
            grid.RowTemplate.Height = 30;

            foreach (DataGridViewColumn column in grid.Columns)
            {
                column.HeaderText = AddSpaces(column.HeaderText);
                if (column.ValueType == typeof(DateTime))
                    column.DefaultCellStyle.Format = "dd MMM yyyy";   // show the date without the time
            }
            foreach (string name in hiddenColumns)
            {
                if (grid.Columns.Contains(name)) grid.Columns[name].Visible = false;
            }
        }

        // "ResidentUsername" -> "Resident Username" (Unit 3: looping over the characters of a string)
        public static string AddSpaces(string text)
        {
            string result = "";
            for (int i = 0; i < text.Length; i++)
            {
                if (i > 0 && char.IsUpper(text[i])) result += " ";
                result += text[i];
            }
            return result;
        }

        // ---------- resizing (so a maximized window fills the screen properly) ----------

        // For the dashboards: when the window grows, every control is moved and stretched in
        // proportion, so the layout always matches the page. Call it once from the form's Load event.
        // All the scaling uses the FORM's own size (never a tab page's size, which isn't reliable yet).
        public static void MakeResponsive(Form form)
        {
            form.MinimumSize = form.Size;   // don't let the window get smaller than the design
            Size design = form.ClientSize;

            // Width taken by the docked sidebar(s). That part never grows.
            int fixedWidth = 0;
            foreach (Control c in form.Controls)
            {
                if (c.Dock == DockStyle.Left || c.Dock == DockStyle.Right) fixedWidth += c.Width;
            }

            // Remember the starting position and size of every control that is placed by hand
            List<ScaledItem> items = new List<ScaledItem>();
            foreach (Control top in form.Controls)
            {
                bool inSidebar = top.Dock == DockStyle.Left || top.Dock == DockStyle.Right;
                CollectItems(top, inSidebar, items);
            }

            form.SizeChanged += (sender, e) =>
            {
                if (form.WindowState == FormWindowState.Minimized) return;

                float sx = (float)(form.ClientSize.Width - fixedWidth) / Math.Max(1, design.Width - fixedWidth);
                float sy = (float)form.ClientSize.Height / Math.Max(1, design.Height);

                foreach (ScaledItem item in items)
                {
                    Control c = item.Control;
                    Rectangle r = item.Bounds;
                    float fx = item.InSidebar ? 1f : sx;   // the sidebar keeps its width

                    // Text boxes, buttons and labels keep their height so the text stays readable
                    bool keepHeight = c is Button || c is Label || c is TextBox || c is ComboBox ||
                                      c is DateTimePicker || c is NumericUpDown || c is CheckBox || c is RadioButton;

                    c.SetBounds((int)(r.Left * fx), (int)(r.Top * sy),
                                (int)(r.Width * fx), keepHeight ? r.Height : (int)(r.Height * sy));
                }
            };
        }

        private class ScaledItem
        {
            public Control Control;
            public Rectangle Bounds;
            public bool InSidebar;
        }

        // Walks into panels and tab pages and records the controls that sit at a fixed position
        private static void CollectItems(Control container, bool inSidebar, List<ScaledItem> items)
        {
            if (container is FlowLayoutPanel || container is TableLayoutPanel) return;   // they arrange themselves

            foreach (Control child in container.Controls)
            {
                if (child.Dock == DockStyle.None && child.Anchor == (AnchorStyles.Top | AnchorStyles.Left))
                    items.Add(new ScaledItem { Control = child, Bounds = child.Bounds, InSidebar = inSidebar });

                if (child is Panel || child is TabControl || child is TabPage || child is GroupBox)
                    CollectItems(child, inSidebar, items);
            }
        }

        // For Login and Register: the content keeps its size and stays centred when the window grows.
        public static void CenterContent(Form form)
        {
            form.MinimumSize = form.Size;
            Size design = form.ClientSize;
            List<KeyValuePair<Control, Point>> items = new List<KeyValuePair<Control, Point>>();

            foreach (Control child in form.Controls)
            {
                if (child.Dock == DockStyle.None)
                    items.Add(new KeyValuePair<Control, Point>(child, child.Location));
            }

            form.SizeChanged += (sender, e) =>
            {
                int dx = (form.ClientSize.Width - design.Width) / 2;
                int dy = (form.ClientSize.Height - design.Height) / 2;
                foreach (KeyValuePair<Control, Point> item in items)
                    item.Key.Location = new Point(item.Value.X + dx, item.Value.Y + dy);
            };
        }

        // Colours the clicked sidebar button and resets the others
        public static void HighlightMenu(Panel sidebar, Button active)
        {
            foreach (Control control in sidebar.Controls)
            {
                if (control is Button button && button.Name.StartsWith("btnNav"))
                    button.BackColor = (button == active) ? Forest : Deep;
            }
        }

        public static void ShowError(string message)
        {
            MessageBox.Show(message, "Please check", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        public static void ShowInfo(string message)
        {
            MessageBox.Show(message, "Smart Waste", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
