namespace DSW_Semester_Project
{
    // Demo records created the first time the app runs (when users.txt doesn't exist).
    // Delete the .txt files in bin\Debug\net10.0-windows to start again.
    public static class SampleData
    {
        public static void Create()
        {
            DateTime today = DateTime.Today;

            // Users
            DataStore.Users.Add(new Administrator("admin", "Salome Papo", "admin@smartwaste.co.za", "0115550100", "Admin@123"));
            DataStore.Users.Add(new StaffMember("thabo", "Thabo Mokoena", "thabo@smartwaste.co.za", "0725550193", "Staff@123", true));
            DataStore.Users.Add(new StaffMember("lindiwe", "Lindiwe Dlamini", "lindiwe@smartwaste.co.za", "0835550144", "Staff@123", true));
            DataStore.Users.Add(new Resident("michael", "Michael Kazadi", "michael@example.com", "0715550111", "Resident@123"));
            DataStore.Users.Add(new Resident("aisha", "Aisha Naidoo", "aisha@example.com", "0825550122", "Resident@123"));

            // Addresses
            Address michaelHome = new Address("michael", "14 Kingsway Ave", "Auckland Park", "Johannesburg", "2092");
            Address aishaHome = new Address("aisha", "3 Main Rd", "Melville", "Johannesburg", "2092");
            DataStore.Addresses.Add(michaelHome);
            DataStore.Addresses.Add(aishaHome);

            // Vehicles
            Vehicle truck1 = new Vehicle("CA 452-118", "Compactor truck", 10);
            truck1.DriverUsername = "thabo";
            Vehicle truck2 = new Vehicle("CA 318-907", "Recycling truck", 6);
            truck2.DriverUsername = "lindiwe";
            Vehicle truck3 = new Vehicle("CA 771-204", "Compactor truck", 10);
            truck3.SendToMaintenance();
            DataStore.Vehicles.Add(truck1);
            DataStore.Vehicles.Add(truck2);
            DataStore.Vehicles.Add(truck3);

            StaffMember thabo = (StaffMember)DataStore.FindUser("thabo");

            // Collections for today: two for Thabo, one not assigned yet
            WasteCollection c1 = new WasteCollection("WC1001", "michael", michaelHome.ToString(), "General waste", today, "Bin is inside the gate");
            c1.Assign(thabo, truck1);
            WasteCollection c2 = new WasteCollection("WC1002", "aisha", aishaHome.ToString(), "Garden refuse", today, "");
            c2.Assign(thabo, truck1);
            WasteCollection c3 = new WasteCollection("WC1003", "michael", michaelHome.ToString(), "Bulky items", today.AddDays(2), "Old fridge");
            DataStore.Collections.Add(c1);
            DataStore.Collections.Add(c2);
            DataStore.Collections.Add(c3);

            // Older completed collections so the dashboard chart has bars
            for (int month = 1; month <= 5; month++)
            {
                for (int i = 0; i < month + 2; i++)
                {
                    string id = DataStore.NextId("WC", DataStore.Collections.Count);
                    WasteCollection old = new WasteCollection(id, "aisha", aishaHome.ToString(), "General waste", today, "");
                    old.Date = today.AddMonths(-month).AddDays(-i);   // set after the constructor because it's in the past
                    old.DriverUsername = "thabo";
                    old.VehicleRegistration = truck1.Registration;
                    old.Status = CollectionStatus.Completed;
                    DataStore.Collections.Add(old);
                }
            }

            // Recycling request and complaint
            DataStore.RecyclingRequests.Add(new RecyclingRequest("RR1001", "michael", michaelHome.ToString(), "Plastic", 2, today.AddDays(3)));
            DataStore.Complaints.Add(new Complaint("CP1001", "aisha", "Damaged bin", "", "The wheel of my bin broke during the last collection."));
        }
    }
}
