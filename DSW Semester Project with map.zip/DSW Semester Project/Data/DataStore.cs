namespace DSW_Semester_Project
{
    // Keeps all records in Lists while the app runs and saves them to .txt files (Unit 4).
    // The files are created next to the .exe (bin\Debug\net10.0-windows), one record per line.
    public static class DataStore
    {
        public static List<User> Users = new List<User>();
        public static List<Address> Addresses = new List<Address>();
        public static List<Vehicle> Vehicles = new List<Vehicle>();
        public static List<WasteCollection> Collections = new List<WasteCollection>();
        public static List<RecyclingRequest> RecyclingRequests = new List<RecyclingRequest>();
        public static List<Complaint> Complaints = new List<Complaint>();

        private const string UsersFile = "users.txt";
        private const string AddressesFile = "addresses.txt";
        private const string VehiclesFile = "vehicles.txt";
        private const string CollectionsFile = "collections.txt";
        private const string RecyclingFile = "recycling.txt";
        private const string ComplaintsFile = "complaints.txt";

        // ---------------- LOAD ----------------

        public static void LoadAll()
        {
            if (!File.Exists(UsersFile))
            {
                SampleData.Create();   // first run: add demo records so every screen has data
                SaveAll();
                return;
            }

            foreach (string line in ReadLines(UsersFile))
            {
                try { Users.Add(UserFromLine(line)); }
                catch (Exception) { /* skip a damaged line instead of crashing */ }
            }
            foreach (string line in ReadLines(AddressesFile))
            {
                try { Addresses.Add(Address.FromFileLine(line)); } catch (Exception) { }
            }
            foreach (string line in ReadLines(VehiclesFile))
            {
                try { Vehicles.Add(Vehicle.FromFileLine(line)); } catch (Exception) { }
            }
            foreach (string line in ReadLines(CollectionsFile))
            {
                try { Collections.Add(WasteCollection.FromFileLine(line)); } catch (Exception) { }
            }
            foreach (string line in ReadLines(RecyclingFile))
            {
                try { RecyclingRequests.Add(RecyclingRequest.FromFileLine(line)); } catch (Exception) { }
            }
            foreach (string line in ReadLines(ComplaintsFile))
            {
                try { Complaints.Add(Complaint.FromFileLine(line)); } catch (Exception) { }
            }
        }

        // The first field says which class to create (polymorphism: all are stored in one List<User>)
        private static User UserFromLine(string line)
        {
            string[] p = line.Split('|');
            if (p[0] == "Resident") return new Resident(p[1], p[2], p[3], p[4], p[5]);
            if (p[0] == "Staff") return new StaffMember(p[1], p[2], p[3], p[4], p[5], bool.Parse(p[6]));
            return new Administrator(p[1], p[2], p[3], p[4], p[5]);
        }

        private static string[] ReadLines(string fileName)
        {
            try
            {
                if (File.Exists(fileName))
                    return File.ReadAllLines(fileName);
            }
            catch (IOException ex)
            {
                MessageBox.Show($"Could not read {fileName}.\n{ex.Message}", "File error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return new string[0];
        }

        // ---------------- SAVE ----------------

        public static void SaveAll()
        {
            List<string> lines = new List<string>();
            foreach (User u in Users) lines.Add(u.ToFileLine());
            WriteLines(UsersFile, lines);

            lines = new List<string>();
            foreach (Address a in Addresses) lines.Add(a.ToFileLine());
            WriteLines(AddressesFile, lines);

            lines = new List<string>();
            foreach (Vehicle v in Vehicles) lines.Add(v.ToFileLine());
            WriteLines(VehiclesFile, lines);

            lines = new List<string>();
            foreach (WasteCollection c in Collections) lines.Add(c.ToFileLine());
            WriteLines(CollectionsFile, lines);

            lines = new List<string>();
            foreach (RecyclingRequest r in RecyclingRequests) lines.Add(r.ToFileLine());
            WriteLines(RecyclingFile, lines);

            lines = new List<string>();
            foreach (Complaint c in Complaints) lines.Add(c.ToFileLine());
            WriteLines(ComplaintsFile, lines);
        }

        private static void WriteLines(string fileName, List<string> lines)
        {
            try
            {
                File.WriteAllLines(fileName, lines);
            }
            catch (IOException ex)
            {
                MessageBox.Show($"Could not save {fileName}. Is it open in another program?\n{ex.Message}", "File error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (UnauthorizedAccessException)
            {
                MessageBox.Show($"No permission to save {fileName}.", "File error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ---------------- FIND HELPERS ----------------

        public static User FindUser(string username)
        {
            foreach (User u in Users)
            {
                if (u.Username.ToLower() == username.Trim().ToLower()) return u;
            }
            return null;
        }

        public static Vehicle FindVehicle(string registration)
        {
            foreach (Vehicle v in Vehicles)
            {
                if (v.Registration == registration) return v;
            }
            return null;
        }

        public static WasteCollection FindCollection(string id)
        {
            foreach (WasteCollection c in Collections)
            {
                if (c.Id == id) return c;
            }
            return null;
        }

        public static List<Address> AddressesOf(string username)
        {
            List<Address> result = new List<Address>();
            foreach (Address a in Addresses)
            {
                if (a.ResidentUsername == username) result.Add(a);
            }
            return result;
        }

        public static List<StaffMember> StaffMembers()
        {
            List<StaffMember> result = new List<StaffMember>();
            foreach (User u in Users)
            {
                if (u is StaffMember s) result.Add(s);
            }
            return result;
        }

        public static List<Resident> Residents()
        {
            List<Resident> result = new List<Resident>();
            foreach (User u in Users)
            {
                if (u is Resident r) result.Add(r);
            }
            return result;
        }

        // Next id like WC1004: prefix + (1001 + how many already exist)
        public static string NextId(string prefix, int count)
        {
            return prefix + (1001 + count);
        }
    }
}
