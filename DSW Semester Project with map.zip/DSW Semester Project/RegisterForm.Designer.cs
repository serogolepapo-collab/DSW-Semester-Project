namespace DSW_Semester_Project
{
    partial class RegisterForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            picRoles = new PictureBox();
            lblTitle = new Label();
            lblIntro = new Label();
            lblSectionPersonal = new Label();
            lblFullName = new Label();
            txtFullName = new TextBox();
            lblPhone = new Label();
            txtPhone = new TextBox();
            lblEmail = new Label();
            txtEmail = new TextBox();
            lblNewUsername = new Label();
            txtNewUsername = new TextBox();
            lblNewPassword = new Label();
            txtNewPassword = new TextBox();
            lblConfirm = new Label();
            txtConfirm = new TextBox();
            chkShowPasswords = new CheckBox();
            lblSectionAddress = new Label();
            lblStreet = new Label();
            txtStreet = new TextBox();
            lblSuburb = new Label();
            txtSuburb = new TextBox();
            lblCity = new Label();
            txtCity = new TextBox();
            lblPostalCode = new Label();
            txtPostalCode = new TextBox();
            lblError = new Label();
            btnCreateAccount = new Button();
            btnBackToLogin = new Button();
            ((System.ComponentModel.ISupportInitialize)picRoles).BeginInit();
            SuspendLayout();
            // 
            // picRoles
            // 
            picRoles.Dock = DockStyle.Right;
            picRoles.Image = Properties.Resources.roles;
            picRoles.Name = "picRoles";
            picRoles.Size = new Size(640, 700);
            picRoles.SizeMode = PictureBoxSizeMode.StretchImage;
            picRoles.TabIndex = 0;
            picRoles.TabStop = false;
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 22F, FontStyle.Bold);
            lblTitle.ForeColor = Color.FromArgb(22, 32, 26);
            lblTitle.Location = new Point(38, 20);
            lblTitle.Name = "lblTitle";
            lblTitle.TabIndex = 1;
            lblTitle.Text = "Create an Account";
            // 
            // lblIntro
            // 
            lblIntro.AutoSize = true;
            lblIntro.Font = new Font("Segoe UI", 10F);
            lblIntro.ForeColor = Color.FromArgb(95, 107, 99);
            lblIntro.Location = new Point(42, 66);
            lblIntro.Name = "lblIntro";
            lblIntro.TabIndex = 2;
            lblIntro.Text = "Fill in your details and the address where we must collect.";
            // 
            // lblSectionPersonal
            // 
            lblSectionPersonal.AutoSize = true;
            lblSectionPersonal.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblSectionPersonal.ForeColor = Color.FromArgb(30, 90, 60);
            lblSectionPersonal.Location = new Point(42, 102);
            lblSectionPersonal.Name = "lblSectionPersonal";
            lblSectionPersonal.TabIndex = 3;
            lblSectionPersonal.Text = "PERSONAL DETAILS";
            // 
            // lblFullName
            // 
            lblFullName.AutoSize = true;
            lblFullName.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblFullName.ForeColor = Color.FromArgb(22, 32, 26);
            lblFullName.Location = new Point(42, 126);
            lblFullName.Name = "lblFullName";
            lblFullName.TabIndex = 4;
            lblFullName.Text = "Full name";
            // 
            // txtFullName
            // 
            txtFullName.Font = new Font("Segoe UI", 11F);
            txtFullName.Location = new Point(42, 150);
            txtFullName.Name = "txtFullName";
            txtFullName.PlaceholderText = "e.g. Michael Kazadi";
            txtFullName.Size = new Size(250, 31);
            txtFullName.TabIndex = 5;
            // 
            // lblPhone
            // 
            lblPhone.AutoSize = true;
            lblPhone.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblPhone.ForeColor = Color.FromArgb(22, 32, 26);
            lblPhone.Location = new Point(312, 126);
            lblPhone.Name = "lblPhone";
            lblPhone.TabIndex = 6;
            lblPhone.Text = "Phone number";
            // 
            // txtPhone
            // 
            txtPhone.Font = new Font("Segoe UI", 11F);
            txtPhone.Location = new Point(312, 150);
            txtPhone.Name = "txtPhone";
            txtPhone.PlaceholderText = "e.g. 071 234 5678";
            txtPhone.Size = new Size(250, 31);
            txtPhone.TabIndex = 7;
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblEmail.ForeColor = Color.FromArgb(22, 32, 26);
            lblEmail.Location = new Point(42, 194);
            lblEmail.Name = "lblEmail";
            lblEmail.TabIndex = 8;
            lblEmail.Text = "Email";
            // 
            // txtEmail
            // 
            txtEmail.Font = new Font("Segoe UI", 11F);
            txtEmail.Location = new Point(42, 218);
            txtEmail.Name = "txtEmail";
            txtEmail.PlaceholderText = "name@example.com";
            txtEmail.Size = new Size(250, 31);
            txtEmail.TabIndex = 9;
            // 
            // lblNewUsername
            // 
            lblNewUsername.AutoSize = true;
            lblNewUsername.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblNewUsername.ForeColor = Color.FromArgb(22, 32, 26);
            lblNewUsername.Location = new Point(312, 194);
            lblNewUsername.Name = "lblNewUsername";
            lblNewUsername.TabIndex = 10;
            lblNewUsername.Text = "Username";
            // 
            // txtNewUsername
            // 
            txtNewUsername.Font = new Font("Segoe UI", 11F);
            txtNewUsername.Location = new Point(312, 218);
            txtNewUsername.Name = "txtNewUsername";
            txtNewUsername.PlaceholderText = "Choose a username";
            txtNewUsername.Size = new Size(250, 31);
            txtNewUsername.TabIndex = 11;
            // 
            // lblNewPassword
            // 
            lblNewPassword.AutoSize = true;
            lblNewPassword.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblNewPassword.ForeColor = Color.FromArgb(22, 32, 26);
            lblNewPassword.Location = new Point(42, 262);
            lblNewPassword.Name = "lblNewPassword";
            lblNewPassword.TabIndex = 12;
            lblNewPassword.Text = "Password";
            // 
            // txtNewPassword
            // 
            txtNewPassword.Font = new Font("Segoe UI", 11F);
            txtNewPassword.Location = new Point(42, 286);
            txtNewPassword.Name = "txtNewPassword";
            txtNewPassword.PlaceholderText = "8+ characters";
            txtNewPassword.Size = new Size(250, 31);
            txtNewPassword.TabIndex = 13;
            txtNewPassword.UseSystemPasswordChar = true;
            // 
            // lblConfirm
            // 
            lblConfirm.AutoSize = true;
            lblConfirm.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblConfirm.ForeColor = Color.FromArgb(22, 32, 26);
            lblConfirm.Location = new Point(312, 262);
            lblConfirm.Name = "lblConfirm";
            lblConfirm.TabIndex = 14;
            lblConfirm.Text = "Confirm password";
            // 
            // txtConfirm
            // 
            txtConfirm.Font = new Font("Segoe UI", 11F);
            txtConfirm.Location = new Point(312, 286);
            txtConfirm.Name = "txtConfirm";
            txtConfirm.PlaceholderText = "Type it again";
            txtConfirm.Size = new Size(250, 31);
            txtConfirm.TabIndex = 15;
            txtConfirm.UseSystemPasswordChar = true;
            // 
            // chkShowPasswords
            // 
            chkShowPasswords.AutoSize = true;
            chkShowPasswords.Font = new Font("Segoe UI", 9F);
            chkShowPasswords.ForeColor = Color.FromArgb(95, 107, 99);
            chkShowPasswords.Location = new Point(42, 334);
            chkShowPasswords.Name = "chkShowPasswords";
            chkShowPasswords.TabIndex = 16;
            chkShowPasswords.Text = "Show passwords";
            chkShowPasswords.CheckedChanged += chkShowPasswords_CheckedChanged;
            // 
            // lblSectionAddress
            // 
            lblSectionAddress.AutoSize = true;
            lblSectionAddress.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblSectionAddress.ForeColor = Color.FromArgb(30, 90, 60);
            lblSectionAddress.Location = new Point(42, 372);
            lblSectionAddress.Name = "lblSectionAddress";
            lblSectionAddress.TabIndex = 17;
            lblSectionAddress.Text = "COLLECTION ADDRESS";
            // 
            // lblStreet
            // 
            lblStreet.AutoSize = true;
            lblStreet.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblStreet.ForeColor = Color.FromArgb(22, 32, 26);
            lblStreet.Location = new Point(42, 396);
            lblStreet.Name = "lblStreet";
            lblStreet.TabIndex = 18;
            lblStreet.Text = "Street address";
            // 
            // txtStreet
            // 
            txtStreet.Font = new Font("Segoe UI", 11F);
            txtStreet.Location = new Point(42, 420);
            txtStreet.Name = "txtStreet";
            txtStreet.PlaceholderText = "e.g. 14 Kingsway Ave";
            txtStreet.Size = new Size(520, 31);
            txtStreet.TabIndex = 19;
            // 
            // lblSuburb
            // 
            lblSuburb.AutoSize = true;
            lblSuburb.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblSuburb.ForeColor = Color.FromArgb(22, 32, 26);
            lblSuburb.Location = new Point(42, 464);
            lblSuburb.Name = "lblSuburb";
            lblSuburb.TabIndex = 20;
            lblSuburb.Text = "Suburb";
            // 
            // txtSuburb
            // 
            txtSuburb.Font = new Font("Segoe UI", 11F);
            txtSuburb.Location = new Point(42, 488);
            txtSuburb.Name = "txtSuburb";
            txtSuburb.PlaceholderText = "e.g. Auckland Park";
            txtSuburb.Size = new Size(250, 31);
            txtSuburb.TabIndex = 21;
            // 
            // lblCity
            // 
            lblCity.AutoSize = true;
            lblCity.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblCity.ForeColor = Color.FromArgb(22, 32, 26);
            lblCity.Location = new Point(312, 464);
            lblCity.Name = "lblCity";
            lblCity.TabIndex = 22;
            lblCity.Text = "City";
            // 
            // txtCity
            // 
            txtCity.Font = new Font("Segoe UI", 11F);
            txtCity.Location = new Point(312, 488);
            txtCity.Name = "txtCity";
            txtCity.PlaceholderText = "e.g. Johannesburg";
            txtCity.Size = new Size(250, 31);
            txtCity.TabIndex = 23;
            // 
            // lblPostalCode
            // 
            lblPostalCode.AutoSize = true;
            lblPostalCode.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblPostalCode.ForeColor = Color.FromArgb(22, 32, 26);
            lblPostalCode.Location = new Point(42, 532);
            lblPostalCode.Name = "lblPostalCode";
            lblPostalCode.TabIndex = 24;
            lblPostalCode.Text = "Postal code";
            // 
            // txtPostalCode
            // 
            txtPostalCode.Font = new Font("Segoe UI", 11F);
            txtPostalCode.Location = new Point(42, 556);
            txtPostalCode.MaxLength = 4;
            txtPostalCode.Name = "txtPostalCode";
            txtPostalCode.PlaceholderText = "2092";
            txtPostalCode.Size = new Size(120, 31);
            txtPostalCode.TabIndex = 25;
            // 
            // lblError
            // 
            lblError.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            lblError.ForeColor = Color.FromArgb(163, 33, 22);
            lblError.Location = new Point(190, 556);
            lblError.Name = "lblError";
            lblError.Size = new Size(372, 44);
            lblError.TabIndex = 26;
            lblError.Text = "";
            // 
            // btnCreateAccount
            // 
            btnCreateAccount.BackColor = Color.FromArgb(30, 90, 60);
            btnCreateAccount.Cursor = Cursors.Hand;
            btnCreateAccount.FlatAppearance.BorderSize = 0;
            btnCreateAccount.FlatStyle = FlatStyle.Flat;
            btnCreateAccount.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnCreateAccount.ForeColor = Color.White;
            btnCreateAccount.Location = new Point(42, 620);
            btnCreateAccount.Name = "btnCreateAccount";
            btnCreateAccount.Size = new Size(330, 48);
            btnCreateAccount.TabIndex = 27;
            btnCreateAccount.Text = "Create account";
            btnCreateAccount.UseVisualStyleBackColor = false;
            btnCreateAccount.Click += btnCreateAccount_Click;
            // 
            // btnBackToLogin
            // 
            btnBackToLogin.BackColor = Color.White;
            btnBackToLogin.Cursor = Cursors.Hand;
            btnBackToLogin.FlatAppearance.BorderColor = Color.FromArgb(30, 90, 60);
            btnBackToLogin.FlatStyle = FlatStyle.Flat;
            btnBackToLogin.Font = new Font("Segoe UI", 10.5F, FontStyle.Bold);
            btnBackToLogin.ForeColor = Color.FromArgb(30, 90, 60);
            btnBackToLogin.Location = new Point(392, 620);
            btnBackToLogin.Name = "btnBackToLogin";
            btnBackToLogin.Size = new Size(170, 48);
            btnBackToLogin.TabIndex = 28;
            btnBackToLogin.Text = "Back to login";
            btnBackToLogin.UseVisualStyleBackColor = false;
            btnBackToLogin.Click += btnBackToLogin_Click;
            // 
            // RegisterForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AcceptButton = btnCreateAccount;
            BackColor = Color.White;
            ClientSize = new Size(1240, 700);
                        MinimizeBox = false;
            StartPosition = FormStartPosition.CenterParent;
            Text = "Create an Account";
            Controls.Add(picRoles);
            Controls.Add(lblTitle);
            Controls.Add(lblIntro);
            Controls.Add(lblSectionPersonal);
            Controls.Add(lblFullName);
            Controls.Add(txtFullName);
            Controls.Add(lblPhone);
            Controls.Add(txtPhone);
            Controls.Add(lblEmail);
            Controls.Add(txtEmail);
            Controls.Add(lblNewUsername);
            Controls.Add(txtNewUsername);
            Controls.Add(lblNewPassword);
            Controls.Add(txtNewPassword);
            Controls.Add(lblConfirm);
            Controls.Add(txtConfirm);
            Controls.Add(chkShowPasswords);
            Controls.Add(lblSectionAddress);
            Controls.Add(lblStreet);
            Controls.Add(txtStreet);
            Controls.Add(lblSuburb);
            Controls.Add(txtSuburb);
            Controls.Add(lblCity);
            Controls.Add(txtCity);
            Controls.Add(lblPostalCode);
            Controls.Add(txtPostalCode);
            Controls.Add(lblError);
            Controls.Add(btnCreateAccount);
            Controls.Add(btnBackToLogin);
            Name = "RegisterForm";
            ((System.ComponentModel.ISupportInitialize)picRoles).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox picRoles;
        private Label lblTitle;
        private Label lblIntro;
        private Label lblSectionPersonal;
        private Label lblFullName;
        private TextBox txtFullName;
        private Label lblPhone;
        private TextBox txtPhone;
        private Label lblEmail;
        private TextBox txtEmail;
        private Label lblNewUsername;
        private TextBox txtNewUsername;
        private Label lblNewPassword;
        private TextBox txtNewPassword;
        private Label lblConfirm;
        private TextBox txtConfirm;
        private CheckBox chkShowPasswords;
        private Label lblSectionAddress;
        private Label lblStreet;
        private TextBox txtStreet;
        private Label lblSuburb;
        private TextBox txtSuburb;
        private Label lblCity;
        private TextBox txtCity;
        private Label lblPostalCode;
        private TextBox txtPostalCode;
        private Label lblError;
        private Button btnCreateAccount;
        private Button btnBackToLogin;
    }
}
