namespace DSW_Semester_Project
{
    public partial class ResidentForm : Form
    {
        private readonly Resident _resident;   // the resident who is logged in

        public ResidentForm(Resident resident)
        {
            InitializeComponent();
            Load += (s, e) => Theme.MakeResponsive(this);
            _resident = resident;
        }

        private void ResidentForm_Load(object sender, EventArgs e)
        {
            lblHello.Text = "Hello, " + _resident.FullName.Split(' ')[0];
            dtpColDate.MinDate = DateTime.Today.AddDays(1);
            dtpRecDate.MinDate = DateTime.Today.AddDays(1);
            RefreshAll();
            cboCompType_SelectedIndexChanged(sender, e);   // hide the "which collection" box until it's needed
            Theme.HighlightMenu(pnlSidebar, btnNavHome);
        }

        // ---------------- menu ----------------

        private void btnNavHome_Click(object sender, EventArgs e) { ShowPage(tabHome, btnNavHome); }
        private void btnNavCollections_Click(object sender, EventArgs e) { ShowPage(tabCollections, btnNavCollections); }
        private void btnNavRecycling_Click(object sender, EventArgs e) { ShowPage(tabRecycling, btnNavRecycling); }
        private void btnNavComplaints_Click(object sender, EventArgs e) { ShowPage(tabComplaints, btnNavComplaints); }
        private void btnNavAddresses_Click(object sender, EventArgs e) { ShowPage(tabAddresses, btnNavAddresses); }

        private void ShowPage(TabPage page, Button menuButton)
        {
            tabMain.SelectedTab = page;
            Theme.HighlightMenu(pnlSidebar, menuButton);
        }

        private void tabMain_SelectedIndexChanged(object sender, EventArgs e)
        {
            RefreshAll();
        }

        private void btnSignOut_Click(object sender, EventArgs e)
        {
            Close();   // the login screen shows again
        }

        // ---------------- loading data into the screen ----------------

        private void RefreshAll()
        {
            // Lists with only this resident's records
            List<WasteCollection> myCollections = new List<WasteCollection>();
            foreach (WasteCollection c in DataStore.Collections)
                if (c.ResidentUsername == _resident.Username) myCollections.Add(c);

            List<RecyclingRequest> myRequests = new List<RecyclingRequest>();
            foreach (RecyclingRequest r in DataStore.RecyclingRequests)
                if (r.ResidentUsername == _resident.Username) myRequests.Add(r);

            List<Complaint> myComplaints = new List<Complaint>();
            int openComplaints = 0;
            foreach (Complaint c in DataStore.Complaints)
            {
                if (c.ResidentUsername != _resident.Username) continue;
                myComplaints.Add(c);
                if (c.Status != ComplaintStatus.Resolved) openComplaints++;
            }

            // Home
            lblHomeTitle.Text = "Welcome back, " + _resident.FullName.Split(' ')[0];
            lblHomeDate.Text = DateTime.Today.ToString("dddd, d MMMM yyyy");
            lblStatRecycling.Text = myRequests.Count.ToString();
            lblStatComplaints.Text = openComplaints.ToString();
            ShowNextCollection(myCollections);
            Theme.ShowList(dgvHomeCollections, myCollections, "ResidentUsername", "RequestId");

            // Other tabs
            Theme.ShowList(dgvMyCollections, myCollections, "ResidentUsername", "RequestId");
            Theme.ShowList(dgvMyRecycling, myRequests, "ResidentUsername", "CollectionId");
            Theme.ShowList(dgvMyComplaints, myComplaints, "ResidentUsername", "Response");

            // Address lists
            List<Address> myAddresses = DataStore.AddressesOf(_resident.Username);
            cboColAddress.DataSource = new List<Address>(myAddresses);
            cboRecAddress.DataSource = new List<Address>(myAddresses);
            lstAddresses.DataSource = new List<Address>(myAddresses);

            // Collections that could have been missed (last 30 days)
            cboCompCollection.Items.Clear();
            foreach (WasteCollection c in myCollections)
            {
                if (c.Date <= DateTime.Today && c.Date >= DateTime.Today.AddDays(-30))
                    cboCompCollection.Items.Add(c.Id);
            }
        }

        // Finds the soonest collection that hasn't happened yet
        private void ShowNextCollection(List<WasteCollection> myCollections)
        {
            WasteCollection next = null;
            foreach (WasteCollection c in myCollections)
            {
                bool open = c.Status == CollectionStatus.Scheduled || c.Status == CollectionStatus.Assigned || c.Status == CollectionStatus.InProgress;
                if (open && c.Date >= DateTime.Today && (next == null || c.Date < next.Date))
                    next = c;
            }

            if (next == null)
            {
                lblNextDate.Text = "No collection booked";
                lblNextDetails.Text = "Request one on the My collections page.";
                lblNextStatus.Text = "";
                return;
            }

            string driver = next.DriverUsername == "" ? "not assigned yet" : next.DriverUsername;
            lblNextDate.Text = next.Date.ToString("dddd, d MMMM");
            lblNextDetails.Text = $"{next.CollectionType} at {next.Address}\nDriver: {driver}   Vehicle: {next.VehicleRegistration}";
            lblNextStatus.Text = "Status: " + next.Status;
        }

        // ---------------- My collections ----------------

        private void btnRequestCollection_Click(object sender, EventArgs e)
        {
            try
            {
                string id = DataStore.NextId("WC", DataStore.Collections.Count);
                WasteCollection collection = new WasteCollection(id, _resident.Username, cboColAddress.Text,
                                                                 cboColType.Text, dtpColDate.Value, txtColNotes.Text);
                DataStore.Collections.Add(collection);
                DataStore.SaveAll();

                txtColNotes.Clear();
                RefreshAll();
                Theme.ShowInfo($"Collection {id} requested. The office will assign a driver.");
            }
            catch (ArgumentException ex)
            {
                Theme.ShowError(ex.Message);
            }
        }

        private void btnCancelCollection_Click(object sender, EventArgs e)
        {
            if (dgvMyCollections.CurrentRow == null) { Theme.ShowError("Select a collection first."); return; }
            WasteCollection selected = (WasteCollection)dgvMyCollections.CurrentRow.DataBoundItem;

            try
            {
                selected.Cancel();
                DataStore.SaveAll();
                RefreshAll();
            }
            catch (InvalidOperationException ex)
            {
                Theme.ShowError(ex.Message);
            }
        }

        // ---------------- Recycling ----------------

        private void btnSubmitRecycling_Click(object sender, EventArgs e)
        {
            try
            {
                string id = DataStore.NextId("RR", DataStore.RecyclingRequests.Count);
                RecyclingRequest request = new RecyclingRequest(id, _resident.Username, cboRecAddress.Text,
                                                                cboRecCategory.Text, (int)nudRecBags.Value, dtpRecDate.Value);
                DataStore.RecyclingRequests.Add(request);
                DataStore.SaveAll();

                RefreshAll();
                Theme.ShowInfo($"Request {id} sent. You'll see here when it's approved.");
            }
            catch (ArgumentException ex)
            {
                Theme.ShowError(ex.Message);
            }
        }

        // ---------------- Complaints ----------------

        private void cboCompType_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Only a missed collection needs the collection number
            bool missed = cboCompType.Text == "Missed collection";
            lblCompCollection.Visible = missed;
            cboCompCollection.Visible = missed;
        }

        private void txtCompDescription_TextChanged(object sender, EventArgs e)
        {
            lblCharCount.Text = $"{txtCompDescription.Text.Length} / 300";
        }

        private void btnSubmitComplaint_Click(object sender, EventArgs e)
        {
            try
            {
                string collectionId = cboCompCollection.Visible ? cboCompCollection.Text : "";
                string id = DataStore.NextId("CP", DataStore.Complaints.Count);
                Complaint complaint = new Complaint(id, _resident.Username, cboCompType.Text, collectionId, txtCompDescription.Text);
                DataStore.Complaints.Add(complaint);
                DataStore.SaveAll();

                txtCompDescription.Clear();
                RefreshAll();
                Theme.ShowInfo($"Thank you. Your reference number is {id}.");
            }
            catch (ArgumentException ex)
            {
                Theme.ShowError(ex.Message);
            }
        }

        private void dgvMyComplaints_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvMyComplaints.CurrentRow == null) { txtCompResponse.Text = ""; return; }
            Complaint selected = (Complaint)dgvMyComplaints.CurrentRow.DataBoundItem;
            txtCompResponse.Text = selected.Response == "" ? "No reply yet. Status: " + selected.Status : selected.Response;
        }

        // ---------------- My addresses ----------------

        private void btnSaveAddress_Click(object sender, EventArgs e)
        {
            try
            {
                Address address = new Address(_resident.Username, txtAddrStreet.Text, txtAddrSuburb.Text, txtAddrCity.Text, txtAddrPostal.Text);
                DataStore.Addresses.Add(address);
                DataStore.SaveAll();

                txtAddrStreet.Clear();
                txtAddrSuburb.Clear();
                txtAddrCity.Clear();
                txtAddrPostal.Clear();
                RefreshAll();
            }
            catch (ArgumentException ex)
            {
                Theme.ShowError(ex.Message);
            }
        }

        private void btnRemoveAddress_Click(object sender, EventArgs e)
        {
            if (lstAddresses.SelectedItem == null) { Theme.ShowError("Select an address first."); return; }
            if (lstAddresses.Items.Count == 1) { Theme.ShowError("You need at least one address so we know where to collect."); return; }

            DataStore.Addresses.Remove((Address)lstAddresses.SelectedItem);
            DataStore.SaveAll();
            RefreshAll();
        }
    }
}
