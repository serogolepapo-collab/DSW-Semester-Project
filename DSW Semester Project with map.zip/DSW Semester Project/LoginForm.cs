namespace DSW_Semester_Project
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
            Load += (s, e) => Theme.CenterContent(this);
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                User user = AccountManager.Login(txtUsername.Text, txtPassword.Text);

                // Polymorphism: Resident, StaffMember and Administrator each open their own dashboard
                Form dashboard = user.OpenDashboard();

                Hide();
                dashboard.ShowDialog();   // waits here until the user signs out or closes the dashboard

                // Back to the login screen
                txtPassword.Clear();
                Show();
            }
            catch (ArgumentException ex)
            {
                Theme.ShowError(ex.Message);
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            RegisterForm registerForm = new RegisterForm();
            if (registerForm.ShowDialog() == DialogResult.OK)
            {
                // Fill in the new username so they only type the password
                txtUsername.Text = registerForm.NewUsername;
                txtPassword.Clear();
                txtPassword.Focus();
                Theme.ShowInfo("Your account is ready. Please log in.");
            }
        }

        private void chkShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            txtPassword.UseSystemPasswordChar = !chkShowPassword.Checked;
        }
    }
}
