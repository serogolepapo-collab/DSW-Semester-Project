﻿namespace DSW_Semester_Project
{
    partial class Request_collection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Request_collection));
            panel1 = new Panel();
            btnCollection = new Button();
            btnHelpANdSupport = new Button();
            btnReports = new Button();
            btnSchedule = new Button();
            btnLOgout = new Button();
            label7 = new Label();
            lblRequestWaste = new Label();
            lblAddress = new Label();
            lblPrefferedTime = new Label();
            lblPrefferdDate = new Label();
            lblCollectionType = new Label();
            lblUserInfo = new Label();
            lblWasteDescription = new Label();
            cmbCollectionType = new ComboBox();
            dtpPrefDate = new DateTimePicker();
            dtpPrefTime = new DateTimePicker();
            txtAddress = new TextBox();
            pictureBox1 = new PictureBox();
            txtWasteDesc = new TextBox();
            lblUploadTittle = new Label();
            btnUploadPicture = new Button();
            pictureBox2 = new PictureBox();
            pictureBox5 = new PictureBox();
            btnSubmitRequest = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(0, 64, 0);
            panel1.Controls.Add(btnCollection);
            panel1.Controls.Add(btnHelpANdSupport);
            panel1.Controls.Add(btnReports);
            panel1.Controls.Add(btnSchedule);
            panel1.Controls.Add(btnLOgout);
            panel1.Controls.Add(label7);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(250, 556);
            panel1.TabIndex = 0;
            // 
            // btnCollection
            // 
            btnCollection.Location = new Point(25, 110);
            btnCollection.Name = "btnCollection";
            btnCollection.Size = new Size(177, 39);
            btnCollection.TabIndex = 19;
            btnCollection.Text = "Collection";
            btnCollection.UseVisualStyleBackColor = true;
            // 
            // btnHelpANdSupport
            // 
            btnHelpANdSupport.Location = new Point(25, 271);
            btnHelpANdSupport.Name = "btnHelpANdSupport";
            btnHelpANdSupport.Size = new Size(177, 45);
            btnHelpANdSupport.TabIndex = 21;
            btnHelpANdSupport.Text = "Help and Support";
            btnHelpANdSupport.UseVisualStyleBackColor = true;
            // 
            // btnReports
            // 
            btnReports.Location = new Point(25, 217);
            btnReports.Name = "btnReports";
            btnReports.Size = new Size(177, 38);
            btnReports.TabIndex = 20;
            btnReports.Text = "Reports";
            btnReports.UseVisualStyleBackColor = true;
            // 
            // btnSchedule
            // 
            btnSchedule.Location = new Point(25, 159);
            btnSchedule.Name = "btnSchedule";
            btnSchedule.Size = new Size(177, 43);
            btnSchedule.TabIndex = 18;
            btnSchedule.Text = "Schedule";
            btnSchedule.UseVisualStyleBackColor = true;
            // 
            // btnLOgout
            // 
            btnLOgout.Location = new Point(143, 514);
            btnLOgout.Name = "btnLOgout";
            btnLOgout.Size = new Size(94, 29);
            btnLOgout.TabIndex = 17;
            btnLOgout.Text = "Log out";
            btnLOgout.UseVisualStyleBackColor = true;
            btnLOgout.Click += btnLOgout_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.White;
            label7.Location = new Point(10, 42);
            label7.Name = "label7";
            label7.Size = new Size(227, 31);
            label7.TabIndex = 7;
            label7.Text = "Waste Management";
            // 
            // lblRequestWaste
            // 
            lblRequestWaste.AutoSize = true;
            lblRequestWaste.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblRequestWaste.ForeColor = SystemColors.ActiveCaptionText;
            lblRequestWaste.Location = new Point(272, 21);
            lblRequestWaste.Name = "lblRequestWaste";
            lblRequestWaste.Size = new Size(253, 28);
            lblRequestWaste.TabIndex = 1;
            lblRequestWaste.Text = "Request Waste Collection";
            // 
            // lblAddress
            // 
            lblAddress.AutoSize = true;
            lblAddress.Location = new Point(291, 226);
            lblAddress.Name = "lblAddress";
            lblAddress.Size = new Size(62, 20);
            lblAddress.TabIndex = 2;
            lblAddress.Text = "Address";
            // 
            // lblPrefferedTime
            // 
            lblPrefferedTime.AutoSize = true;
            lblPrefferedTime.Location = new Point(533, 170);
            lblPrefferedTime.Name = "lblPrefferedTime";
            lblPrefferedTime.Size = new Size(99, 20);
            lblPrefferedTime.TabIndex = 3;
            lblPrefferedTime.Text = "Prefferd Time";
            // 
            // lblPrefferdDate
            // 
            lblPrefferdDate.AutoSize = true;
            lblPrefferdDate.Location = new Point(282, 170);
            lblPrefferdDate.Name = "lblPrefferdDate";
            lblPrefferdDate.Size = new Size(106, 20);
            lblPrefferdDate.TabIndex = 4;
            lblPrefferdDate.Text = "Preffered Date";
            // 
            // lblCollectionType
            // 
            lblCollectionType.AutoSize = true;
            lblCollectionType.Location = new Point(282, 110);
            lblCollectionType.Name = "lblCollectionType";
            lblCollectionType.Size = new Size(111, 20);
            lblCollectionType.TabIndex = 5;
            lblCollectionType.Text = "Collection Type";
            // 
            // lblUserInfo
            // 
            lblUserInfo.AutoSize = true;
            lblUserInfo.Location = new Point(282, 53);
            lblUserInfo.Name = "lblUserInfo";
            lblUserInfo.Size = new Size(483, 20);
            lblUserInfo.TabIndex = 6;
            lblUserInfo.Text = "Fill in the details below to schedule a waste collection for your  location";
            // 
            // lblWasteDescription
            // 
            lblWasteDescription.AutoSize = true;
            lblWasteDescription.Location = new Point(287, 283);
            lblWasteDescription.Name = "lblWasteDescription";
            lblWasteDescription.Size = new Size(129, 20);
            lblWasteDescription.TabIndex = 7;
            lblWasteDescription.Text = "Waste Description";
            // 
            // cmbCollectionType
            // 
            cmbCollectionType.FormattingEnabled = true;
            cmbCollectionType.Location = new Point(282, 133);
            cmbCollectionType.Name = "cmbCollectionType";
            cmbCollectionType.Size = new Size(388, 28);
            cmbCollectionType.TabIndex = 10;
            // 
            // dtpPrefDate
            // 
            dtpPrefDate.CustomFormat = "dd MMMM  yyyy";
            dtpPrefDate.Format = DateTimePickerFormat.Custom;
            dtpPrefDate.Location = new Point(282, 193);
            dtpPrefDate.MinDate = new DateTime(2026, 9, 21, 0, 0, 0, 0);
            dtpPrefDate.Name = "dtpPrefDate";
            dtpPrefDate.Size = new Size(233, 27);
            dtpPrefDate.TabIndex = 11;
            // 
            // dtpPrefTime
            // 
            dtpPrefTime.CustomFormat = "hh:mm tt";
            dtpPrefTime.Format = DateTimePickerFormat.Custom;
            dtpPrefTime.Location = new Point(533, 193);
            dtpPrefTime.MinDate = new DateTime(2026, 9, 21, 0, 0, 0, 0);
            dtpPrefTime.Name = "dtpPrefTime";
            dtpPrefTime.ShowUpDown = true;
            dtpPrefTime.Size = new Size(250, 27);
            dtpPrefTime.TabIndex = 12;
            // 
            // txtAddress
            // 
            txtAddress.Location = new Point(282, 246);
            txtAddress.Multiline = true;
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(350, 34);
            txtAddress.TabIndex = 13;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(272, 343);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(593, 139);
            pictureBox1.TabIndex = 14;
            pictureBox1.TabStop = false;
            // 
            // txtWasteDesc
            // 
            txtWasteDesc.Location = new Point(282, 306);
            txtWasteDesc.Multiline = true;
            txtWasteDesc.Name = "txtWasteDesc";
            txtWasteDesc.Size = new Size(501, 31);
            txtWasteDesc.TabIndex = 16;
            // 
            // lblUploadTittle
            // 
            lblUploadTittle.AutoSize = true;
            lblUploadTittle.Location = new Point(443, 420);
            lblUploadTittle.Name = "lblUploadTittle";
            lblUploadTittle.Size = new Size(227, 20);
            lblUploadTittle.TabIndex = 17;
            lblUploadTittle.Text = "Click to upload or drag and drop";
            // 
            // btnUploadPicture
            // 
            btnUploadPicture.Location = new Point(452, 443);
            btnUploadPicture.Name = "btnUploadPicture";
            btnUploadPicture.Size = new Size(201, 29);
            btnUploadPicture.TabIndex = 18;
            btnUploadPicture.Text = "Upload Picture";
            btnUploadPicture.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            pictureBox2.Location = new Point(282, 133);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(24, 28);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 22;
            pictureBox2.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.BackColor = Color.FromArgb(0, 64, 0);
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(508, 343);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(85, 65);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 25;
            pictureBox5.TabStop = false;
            // 
            // btnSubmitRequest
            // 
            btnSubmitRequest.BackColor = Color.Green;
            btnSubmitRequest.Location = new Point(376, 488);
            btnSubmitRequest.Name = "btnSubmitRequest";
            btnSubmitRequest.Size = new Size(438, 41);
            btnSubmitRequest.TabIndex = 26;
            btnSubmitRequest.Text = "Submit Request";
            btnSubmitRequest.UseVisualStyleBackColor = false;
            btnSubmitRequest.Click += btnSubmitRequest_Click;
            // 
            // Request_collection
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(877, 555);
            Controls.Add(btnSubmitRequest);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox2);
            Controls.Add(btnUploadPicture);
            Controls.Add(lblUploadTittle);
            Controls.Add(txtWasteDesc);
            Controls.Add(pictureBox1);
            Controls.Add(txtAddress);
            Controls.Add(dtpPrefTime);
            Controls.Add(dtpPrefDate);
            Controls.Add(cmbCollectionType);
            Controls.Add(lblWasteDescription);
            Controls.Add(lblUserInfo);
            Controls.Add(lblCollectionType);
            Controls.Add(lblPrefferdDate);
            Controls.Add(lblPrefferedTime);
            Controls.Add(lblAddress);
            Controls.Add(lblRequestWaste);
            Controls.Add(panel1);
            Name = "Request_collection";
            Text = "Request_collection";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label lblRequestWaste;
        private Label lblAddress;
        private Label lblPrefferedTime;
        private Label lblPrefferdDate;
        private Label lblCollectionType;
        private Label lblUserInfo;
        private Label label7;
        private Label lblWasteDescription;
        private Label label2;
        private Label label3;
        private ComboBox cmbCollectionType;
        private DateTimePicker dtpPrefDate;
        private DateTimePicker dtpPrefTime;
        private TextBox txtAddress;
        private PictureBox pictureBox1;
        private TextBox txtWasteDesc;
        private Button btnLOgout;
        private Button btnReports;
        private Button button3;
        private Button btnSchedule;
        private Button btnHelpANdSupport;
        private Label lblUploadTittle;
        private Button btnCollection;
        private Button btnUploadPicture;
        private PictureBox pictureBox2;
        private PictureBox pictureBox5;
        private Button btnSubmitRequest;
    }
}