﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DSW_Semester_Project
{
    public partial class Request_collection : Form
    {
        public Request_collection()
        {
            InitializeComponent();
        }



        private void btnSubmitRequest_Click(object sender, EventArgs e)
        {
            // 1. Validation
            if (cmbCollectionType.SelectedIndex == -1)
            {
                MessageBox.Show("Please select Collection Type");
                return;
            }
            if (string.IsNullOrWhiteSpace(txtAddress.Text))
            {
                MessageBox.Show("Please enter Address");
                return;
            }

            // 2. Get values from form
            string collectionType = cmbCollectionType.Text;
            string prefDate = dtpPrefDate.Value.ToString("yyyy-MM-dd");
            string prefTime = dtpPrefTime.Value.ToString("HH:mm");
            string address = txtAddress.Text.Trim();
            string wasteDesc = txtWasteDesc.Text.Trim();


            try
            {
                // 3. Save to TXT file
                string folderPath = Path.Combine(Application.StartupPath, "Requests");
                Directory.CreateDirectory(folderPath); // create folder if not exists

                string filePath = Path.Combine(folderPath, "WasteRequests.txt");

                // Format to save
                string dataToSave = "=====================================" + Environment.NewLine +
                                    $"Date Submitted: {DateTime.Now}" + Environment.NewLine +
                                    $"Collection Type: {collectionType}" + Environment.NewLine +
                                    $"Preferred Date: {prefDate}" + Environment.NewLine +
                                    $"Preferred Time: {prefTime}" + Environment.NewLine +
                                    $"Address: {address}" + Environment.NewLine +
                                    $"Waste Description: {wasteDesc}" + Environment.NewLine +
                                    //$"Image Path: {imagePath}" + Environment.NewLine +
                                    $"Status: Pending" + Environment.NewLine +
                                    "=====================================" + Environment.NewLine + Environment.NewLine;

                File.AppendAllText(filePath, dataToSave);

                // 4. Success
                MessageBox.Show("Request Saved Successfully to TXT File!\n\nFile Location:\n" + filePath, "Waste Management", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // 5. Clear form
                cmbCollectionType.SelectedIndex = -1;
                txtAddress.Clear();
                txtWasteDesc.Clear();
              

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }

        }

        private void btnLOgout_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to logout?", "Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                // Go back to Login Form
                FrmSmartWasteRecycling Residents = new FrmSmartWasteRecycling();
                //FrmSmartWasteRecycling.show();



                this.Close(); // close current form
            }
        }
    }
}
