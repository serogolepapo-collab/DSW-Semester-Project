﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DSW_Semester_Project
{
    internal class WasteCollection
    {
        public string CollectionId { get; set; }
        public string StreetAddress { get; set; }
        public string Suburb { get; set; }
        public string City { get; set; }
        public string CollectionTime { get; set; }
        public string CollectionDate { get; set; }
        public string Status { get; set; }
        public string Reason { get; set; }
        public WasteCollection(string collectionId, string streetAddress, string suburb, string city, string collectionTime, string status,
            string collectionDate, string reason)
        {
            CollectionId = collectionId;
            StreetAddress = streetAddress;
            Suburb = suburb;
            City = city;
            CollectionTime = collectionTime;
            Status = status;
            CollectionDate = collectionDate;
            Reason = reason;
        }
    }
}
