﻿namespace DSW_Semester_Project
{
    public partial class CollectionStaff : Form
    {

        private StaffMember currentStaff;
        public CollectionStaff(StaffMember staff)
        {
            InitializeComponent();
            currentStaff = staff;
            lblHelloDriver.Text = "Hello, " + currentStaff.FullName + " (" + currentStaff.Position + ")";
            lblCollectionStaff.Text = $"{currentStaff.FullName}";
        }

        private void btnSignOut2_Click(object sender, EventArgs e)
        {
            DialogResult answer = MessageBox.Show("Are you sure you want to sign out?", "Confirm",
               MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (answer == DialogResult.Yes)
            {
                FrmSmartWasteRecycling loginForm = new FrmSmartWasteRecycling();
                loginForm.Show();
                this.Close();
            }
        }
        List<WasteCollection> waste = new List<WasteCollection>();

        private void btnUpdateStatus_Click(object sender, EventArgs e)
        {

            string streetAddress = txtStreetAddress.Text.Trim();
            string suburb = txtSuburb.Text.Trim();
            string time = txtTime.Text.Trim();
            string city = txtCity.Text.Trim();
            string date = txtDate.Text.Trim();

            // Check that the basic collection information was entered
            if (string.IsNullOrWhiteSpace(streetAddress) ||
                string.IsNullOrWhiteSpace(suburb) ||
                string.IsNullOrWhiteSpace(time) ||
                string.IsNullOrWhiteSpace(city) ||
                string.IsNullOrWhiteSpace(date))
            {
                MessageBox.Show(
                    "Please complete all collection details.",
                    "Missing Information",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            // Check that a collection status was selected
            if (!rbCollected.Checked && !rbNotCollected.Checked)
            {
                MessageBox.Show(
                    "Please select whether the collection was collected or not collected.",
                    "Collection Status",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            string status;
            string reason = "";

            if (rbCollected.Checked)
            {
                status = "Collected";
            }
            else
            {
                status = "Not Collected";

                // A reason is required when the collection was not collected
                if (cmbReasons.SelectedIndex == -1)
                {
                    MessageBox.Show(
                        "Please select a reason for the collection not being completed.",
                        "Reason Required",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }
                reason = cmbReasons.SelectedItem.ToString();

            }

            // Create the WasteCollection object
            WasteCollection collection = new WasteCollection(
                Guid.NewGuid().ToString(),
                streetAddress,
                suburb,
                city,
                time,
                date,
                status,
                reason
            );

            // Add the collection to the DataGridView
            dgvTasks.Rows.Add(
                collection.StreetAddress,
                collection.Suburb,
                collection.CollectionTime,
                collection.City,       
                collection.CollectionDate,
                 collection.Status,
                collection.Reason
            );

            waste.Add(collection);
            dgvTasks.Rows.Clear();

            foreach (WasteCollection item in waste)
            {
                dgvTasks.Rows.Add(item.StreetAddress, item.Status, item.Reason, item.CollectionDate);
            }

            MessageBox.Show(
                "Collection status updated successfully.",
                "Success",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }
    }
}