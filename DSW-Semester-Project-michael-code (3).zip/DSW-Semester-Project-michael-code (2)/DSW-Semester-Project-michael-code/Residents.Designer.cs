﻿namespace DSW_Semester_Project
{
    partial class Residents
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabControlCollection = new TabControl();
            tabPage1 = new TabPage();
            btnAddRequest = new Button();
            lblUserAddress = new Label();
            lblGreetings = new Label();
            tabPage2 = new TabPage();
            label8 = new Label();
            listView1 = new ListView();
            label7 = new Label();
            label5 = new Label();
            label4 = new Label();
            tabPage3 = new TabPage();
            pictureBox2 = new PictureBox();
            LstAddressSaved = new ListBox();
            lblAddressSaved = new Label();
            pictureBox1 = new PictureBox();
            lblAddress = new Label();
            label3 = new Label();
            lblPickupsNumber = new Label();
            lblCompletedNumber = new Label();
            label2 = new Label();
            label1 = new Label();
            lblUpcomingPickupsNumber = new Label();
            textBox1 = new TextBox();
            btnSubmit = new Button();
            cmbComplaintsAndReview = new ComboBox();
            label6 = new Label();
            lblZipCode = new Label();
            lblStateOrProvince = new Label();
            lblCity = new Label();
            lblBuldingName = new Label();
            lblStreetAddress = new Label();
            lblLocationDetails = new Label();
            panelSideBar = new Panel();
            panelUserDisplay = new Panel();
            btnSignOut = new Button();
            lblUser = new Label();
            lblResidentFullName = new Label();
            pictureBoxIcon = new PictureBox();
            lblUserType = new Label();
            lblTitle = new Label();
            tabControlCollection.SuspendLayout();
            tabPage1.SuspendLayout();
            tabPage2.SuspendLayout();
            tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panelSideBar.SuspendLayout();
            panelUserDisplay.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxIcon).BeginInit();
            SuspendLayout();
            // 
            // tabControlCollection
            // 
            tabControlCollection.Controls.Add(tabPage1);
            tabControlCollection.Controls.Add(tabPage2);
            tabControlCollection.Controls.Add(tabPage3);
            tabControlCollection.Location = new Point(289, 12);
            tabControlCollection.Multiline = true;
            tabControlCollection.Name = "tabControlCollection";
            tabControlCollection.SelectedIndex = 0;
            tabControlCollection.Size = new Size(1078, 703);
            tabControlCollection.TabIndex = 1;
            // 
            // tabPage1
            // 
            tabPage1.BackColor = Color.Transparent;
            tabPage1.Controls.Add(btnAddRequest);
            tabPage1.Controls.Add(lblUserAddress);
            tabPage1.Controls.Add(lblGreetings);
            tabPage1.ForeColor = Color.FromArgb(0, 64, 0);
            tabPage1.Location = new Point(4, 29);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3, 3, 3, 3);
            tabPage1.Size = new Size(1070, 670);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "My Collections";
            // 
            // btnAddRequest
            // 
            btnAddRequest.BackColor = Color.FromArgb(0, 64, 0);
            btnAddRequest.ForeColor = Color.White;
            btnAddRequest.Location = new Point(839, 41);
            btnAddRequest.Name = "btnAddRequest";
            btnAddRequest.Size = new Size(208, 35);
            btnAddRequest.TabIndex = 2;
            btnAddRequest.Text = "+ Request Collection";
            btnAddRequest.UseVisualStyleBackColor = false;
            btnAddRequest.Click += btnAddRequest_Click;
            // 
            // lblUserAddress
            // 
            lblUserAddress.AutoSize = true;
            lblUserAddress.ForeColor = Color.FromArgb(0, 64, 0);
            lblUserAddress.Location = new Point(34, 55);
            lblUserAddress.Name = "lblUserAddress";
            lblUserAddress.Size = new Size(86, 20);
            lblUserAddress.TabIndex = 1;
            lblUserAddress.Text = "User Adress";
            // 
            // lblGreetings
            // 
            lblGreetings.AutoSize = true;
            lblGreetings.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblGreetings.ForeColor = Color.FromArgb(0, 64, 0);
            lblGreetings.Location = new Point(25, 17);
            lblGreetings.Name = "lblGreetings";
            lblGreetings.Size = new Size(214, 38);
            lblGreetings.TabIndex = 0;
            lblGreetings.Text = "Hello, Resident";
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(label8);
            tabPage2.Controls.Add(listView1);
            tabPage2.Controls.Add(label7);
            tabPage2.Controls.Add(label5);
            tabPage2.Controls.Add(label4);
            tabPage2.Location = new Point(4, 29);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3, 3, 3, 3);
            tabPage2.Size = new Size(1070, 670);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Complaints & reviews";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.FromArgb(0, 64, 0);
            label8.Location = new Point(581, 187);
            label8.Name = "label8";
            label8.Size = new Size(194, 23);
            label8.TabIndex = 5;
            label8.Text = "Nothing submitted yet";
            // 
            // listView1
            // 
            listView1.Location = new Point(327, 133);
            listView1.Name = "listView1";
            listView1.Size = new Size(697, 131);
            listView1.TabIndex = 4;
            listView1.UseCompatibleStateImageBehavior = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.FromArgb(0, 64, 0);
            label7.Location = new Point(327, 100);
            label7.Name = "label7";
            label7.Size = new Size(200, 31);
            label7.TabIndex = 3;
            label7.Text = "Your submissions";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.DimGray;
            label5.Location = new Point(27, 59);
            label5.Name = "label5";
            label5.Size = new Size(443, 17);
            label5.TabIndex = 1;
            label5.Text = "Report a missed collection or illegal dumping, or rate a completed pickup.\r\n";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.FromArgb(0, 64, 0);
            label4.Location = new Point(17, 12);
            label4.Name = "label4";
            label4.Size = new Size(399, 46);
            label4.TabIndex = 0;
            label4.Text = "Complaints and reviews";
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(pictureBox2);
            tabPage3.Controls.Add(LstAddressSaved);
            tabPage3.Controls.Add(lblAddressSaved);
            tabPage3.Controls.Add(pictureBox1);
            tabPage3.Controls.Add(lblAddress);
            tabPage3.Location = new Point(4, 29);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3, 3, 3, 3);
            tabPage3.Size = new Size(1070, 670);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "My address";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.WhatsApp_Image_2026_09_14_at_14_47_35;
            pictureBox2.Location = new Point(919, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(155, 661);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 7;
            pictureBox2.TabStop = false;
            // 
            // LstAddressSaved
            // 
            LstAddressSaved.FormattingEnabled = true;
            LstAddressSaved.Location = new Point(688, 469);
            LstAddressSaved.Name = "LstAddressSaved";
            LstAddressSaved.Size = new Size(225, 184);
            LstAddressSaved.TabIndex = 6;
            // 
            // lblAddressSaved
            // 
            lblAddressSaved.AutoSize = true;
            lblAddressSaved.Location = new Point(697, 437);
            lblAddressSaved.Name = "lblAddressSaved";
            lblAddressSaved.Size = new Size(109, 20);
            lblAddressSaved.TabIndex = 4;
            lblAddressSaved.Text = "Address Saved:";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.WhatsApp_Image_2026_09_14_at_14_21_39;
            pictureBox1.Location = new Point(688, 85);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(225, 329);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // lblAddress
            // 
            lblAddress.AutoSize = true;
            lblAddress.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblAddress.Location = new Point(29, 20);
            lblAddress.Name = "lblAddress";
            lblAddress.Size = new Size(111, 31);
            lblAddress.TabIndex = 1;
            lblAddress.Text = "ADDRESS";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.FromArgb(0, 64, 0);
            label3.Location = new Point(32, 10);
            label3.Name = "label3";
            label3.Size = new Size(123, 13);
            label3.TabIndex = 1;
            label3.Text = "♻️RECYCLING PICKUPS";
            // 
            // lblPickupsNumber
            // 
            lblPickupsNumber.AutoSize = true;
            lblPickupsNumber.Font = new Font("Segoe UI", 28.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblPickupsNumber.Location = new Point(32, 23);
            lblPickupsNumber.Name = "lblPickupsNumber";
            lblPickupsNumber.Size = new Size(44, 51);
            lblPickupsNumber.TabIndex = 2;
            lblPickupsNumber.Text = "0";
            // 
            // lblCompletedNumber
            // 
            lblCompletedNumber.AutoSize = true;
            lblCompletedNumber.Font = new Font("Segoe UI", 28.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCompletedNumber.Location = new Point(20, 26);
            lblCompletedNumber.Name = "lblCompletedNumber";
            lblCompletedNumber.Size = new Size(44, 51);
            lblCompletedNumber.TabIndex = 2;
            lblCompletedNumber.Text = "0";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(20, 13);
            label2.Name = "label2";
            label2.Size = new Size(69, 13);
            label2.TabIndex = 1;
            label2.Text = "COMPLETED";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(19, 12);
            label1.Name = "label1";
            label1.Size = new Size(111, 13);
            label1.TabIndex = 0;
            label1.Text = "UPCOMING PICKUPS";
            // 
            // lblUpcomingPickupsNumber
            // 
            lblUpcomingPickupsNumber.AutoSize = true;
            lblUpcomingPickupsNumber.Font = new Font("Segoe UI", 28.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblUpcomingPickupsNumber.Location = new Point(19, 25);
            lblUpcomingPickupsNumber.Name = "lblUpcomingPickupsNumber";
            lblUpcomingPickupsNumber.Size = new Size(44, 51);
            lblUpcomingPickupsNumber.TabIndex = 1;
            lblUpcomingPickupsNumber.Text = "0";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(17, 62);
            textBox1.Margin = new Padding(3, 2, 3, 2);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(185, 169);
            textBox1.TabIndex = 3;
            // 
            // btnSubmit
            // 
            btnSubmit.BackColor = Color.FromArgb(0, 64, 0);
            btnSubmit.ForeColor = Color.White;
            btnSubmit.Location = new Point(17, 234);
            btnSubmit.Margin = new Padding(3, 2, 3, 2);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(185, 22);
            btnSubmit.TabIndex = 2;
            btnSubmit.Text = "Submit";
            btnSubmit.UseVisualStyleBackColor = false;
            // 
            // cmbComplaintsAndReview
            // 
            cmbComplaintsAndReview.FormattingEnabled = true;
            cmbComplaintsAndReview.Items.AddRange(new object[] { "Missed Collection", "illegal dumping", "Review / feedback", "Other problem" });
            cmbComplaintsAndReview.Location = new Point(17, 28);
            cmbComplaintsAndReview.Margin = new Padding(3, 2, 3, 2);
            cmbComplaintsAndReview.Name = "cmbComplaintsAndReview";
            cmbComplaintsAndReview.Size = new Size(185, 28);
            cmbComplaintsAndReview.TabIndex = 1;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.FromArgb(0, 64, 0);
            label6.Location = new Point(17, 11);
            label6.Name = "label6";
            label6.Size = new Size(32, 15);
            label6.TabIndex = 0;
            label6.Text = "Type";
            // 
            // lblZipCode
            // 
            lblZipCode.AutoSize = true;
            lblZipCode.Location = new Point(35, 309);
            lblZipCode.Name = "lblZipCode";
            lblZipCode.Size = new Size(108, 15);
            lblZipCode.TabIndex = 9;
            lblZipCode.Text = "ZIP/POSTAL CODE:";
            // 
            // lblStateOrProvince
            // 
            lblStateOrProvince.AutoSize = true;
            lblStateOrProvince.Location = new Point(35, 237);
            lblStateOrProvince.Name = "lblStateOrProvince";
            lblStateOrProvince.Size = new Size(103, 15);
            lblStateOrProvince.TabIndex = 6;
            lblStateOrProvince.Text = "STATE/PROVINCE:";
            // 
            // lblCity
            // 
            lblCity.AutoSize = true;
            lblCity.Location = new Point(47, 172);
            lblCity.Name = "lblCity";
            lblCity.Size = new Size(35, 15);
            lblCity.TabIndex = 5;
            lblCity.Text = "CITY:";
            // 
            // lblBuldingName
            // 
            lblBuldingName.AutoSize = true;
            lblBuldingName.Location = new Point(38, 110);
            lblBuldingName.Name = "lblBuldingName";
            lblBuldingName.Size = new Size(96, 15);
            lblBuldingName.TabIndex = 4;
            lblBuldingName.Text = "BULDING NAME:";
            // 
            // lblStreetAddress
            // 
            lblStreetAddress.AutoSize = true;
            lblStreetAddress.Location = new Point(35, 47);
            lblStreetAddress.Name = "lblStreetAddress";
            lblStreetAddress.Size = new Size(101, 15);
            lblStreetAddress.TabIndex = 3;
            lblStreetAddress.Text = "STREET ADDRESS:";
            // 
            // lblLocationDetails
            // 
            lblLocationDetails.AutoSize = true;
            lblLocationDetails.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblLocationDetails.Location = new Point(35, 11);
            lblLocationDetails.Name = "lblLocationDetails";
            lblLocationDetails.Size = new Size(116, 20);
            lblLocationDetails.TabIndex = 0;
            lblLocationDetails.Text = "Location Details";
            // 
            // panelSideBar
            // 
            panelSideBar.BackColor = Color.FromArgb(0, 64, 0);
            panelSideBar.Controls.Add(panelUserDisplay);
            panelSideBar.Controls.Add(pictureBoxIcon);
            panelSideBar.Controls.Add(lblUserType);
            panelSideBar.Controls.Add(lblTitle);
            panelSideBar.Location = new Point(1, 5);
            panelSideBar.Name = "panelSideBar";
            panelSideBar.Size = new Size(270, 707);
            panelSideBar.TabIndex = 1;
            // 
            // panelUserDisplay
            // 
            panelUserDisplay.BackColor = Color.Transparent;
            panelUserDisplay.BackgroundImageLayout = ImageLayout.None;
            panelUserDisplay.Controls.Add(btnSignOut);
            panelUserDisplay.Controls.Add(lblUser);
            panelUserDisplay.Controls.Add(lblResidentFullName);
            panelUserDisplay.Location = new Point(30, 591);
            panelUserDisplay.Name = "panelUserDisplay";
            panelUserDisplay.Size = new Size(194, 97);
            panelUserDisplay.TabIndex = 1;
            // 
            // btnSignOut
            // 
            btnSignOut.BackColor = Color.FromArgb(0, 64, 0);
            btnSignOut.ForeColor = Color.White;
            btnSignOut.Location = new Point(23, 60);
            btnSignOut.Name = "btnSignOut";
            btnSignOut.Size = new Size(94, 29);
            btnSignOut.TabIndex = 1;
            btnSignOut.Text = "→ Sign Out";
            btnSignOut.UseVisualStyleBackColor = false;
            btnSignOut.Click += btnSignOut_Click;
            // 
            // lblUser
            // 
            lblUser.AutoSize = true;
            lblUser.ForeColor = Color.White;
            lblUser.Location = new Point(23, 37);
            lblUser.Name = "lblUser";
            lblUser.Size = new Size(66, 20);
            lblUser.TabIndex = 2;
            lblUser.Text = "Resident";
            // 
            // lblResidentFullName
            // 
            lblResidentFullName.AutoSize = true;
            lblResidentFullName.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblResidentFullName.ForeColor = Color.White;
            lblResidentFullName.Location = new Point(23, 17);
            lblResidentFullName.Name = "lblResidentFullName";
            lblResidentFullName.Size = new Size(116, 20);
            lblResidentFullName.TabIndex = 1;
            lblResidentFullName.Text = "Resident Name";
            lblResidentFullName.Click += lblResidentFullName_Click;
            // 
            // pictureBoxIcon
            // 
            pictureBoxIcon.Image = Properties.Resources.WhatsApp_Image_2026_09_12_at_17_39_25;
            pictureBoxIcon.Location = new Point(11, 36);
            pictureBoxIcon.Name = "pictureBoxIcon";
            pictureBoxIcon.Size = new Size(81, 55);
            pictureBoxIcon.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxIcon.TabIndex = 1;
            pictureBoxIcon.TabStop = false;
            // 
            // lblUserType
            // 
            lblUserType.AutoSize = true;
            lblUserType.Font = new Font("Segoe UI", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblUserType.ForeColor = Color.White;
            lblUserType.Location = new Point(107, 67);
            lblUserType.Name = "lblUserType";
            lblUserType.Size = new Size(58, 17);
            lblUserType.TabIndex = 1;
            lblUserType.Text = "Resident";
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTitle.ForeColor = Color.White;
            lblTitle.Location = new Point(98, 36);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(142, 31);
            lblTitle.TabIndex = 1;
            lblTitle.Text = "Smart Waste";
            // 
            // Residents
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1370, 715);
            Controls.Add(panelSideBar);
            Controls.Add(tabControlCollection);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            HelpButton = true;
            Name = "Residents";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Residents";
            tabControlCollection.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            tabPage3.ResumeLayout(false);
            tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panelSideBar.ResumeLayout(false);
            panelSideBar.PerformLayout();
            panelUserDisplay.ResumeLayout(false);
            panelUserDisplay.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxIcon).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControlCollection;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private TabPage tabPage3;
        private Panel panelSideBar;
        private Label lblTitle;
        private Label lblUserType;
        private PictureBox pictureBoxIcon;
        private Label lblGreetings;
        private Panel panelUserDisplay;
        private Button btnSignOut;
        private Label lblUser;
        private Label lblResidentFullName;
        private Label lblUserAddress;
        private Button btnAddRequest;
        private Label label3;
        private Label label2;
        private Label label1;
        private Label lblUpcomingPickupsNumber;
        private WindowsFormsApp1.RoundedPanel roundedPanel2;
        private WindowsFormsApp1.RoundedPanel roundedPanel1;
        private Label lblPickupsNumber;
        private Label lblCompletedNumber;
        private WindowsFormsApp1.RoundedPanel roundedPanel3;
        private Label label4;
        private WindowsFormsApp1.RoundedPanel roundedPanel4;
        private Label label6;
        private Label label5;
        private Button button1;
        private ComboBox comboBox1;
        private ListView listView1;
        private Label label7;
        private Label label8;
        private Label lblAddress;
        private WindowsFormsApp1.RoundedPanel rndAddress;
        private WindowsFormsApp1.RoundedButton btnSaveAddress;
        private Label lblLocationDetails;
        private WindowsFormsApp1.RoundedButton btnChangeAddress;
        private PictureBox pictureBox1;
        private WindowsFormsApp1.RoundedButtonRegister btnCancelAdress;
        private WindowsFormsApp1.CustomTextBox txtZipCode;
        private WindowsFormsApp1.CustomTextBox txtStateOrProvince;
        private WindowsFormsApp1.CustomTextBox txtCity;
        private WindowsFormsApp1.CustomTextBox txtBuildingName;
        private WindowsFormsApp1.CustomTextBox txtStreetAddress;
        private Label lblZipCode;
        private Label lblStateOrProvince;
        private Label lblCity;
        private Label lblBuldingName;
        private Label lblStreetAddress;
        private ListBox LstAddressSaved;
        private Label lblAddressSaved;
        private PictureBox pictureBox2;
        private TextBox textBox1;
        private ComboBox cmbComplaintsAndReview;
        private Button btnSubmit;
    }
}