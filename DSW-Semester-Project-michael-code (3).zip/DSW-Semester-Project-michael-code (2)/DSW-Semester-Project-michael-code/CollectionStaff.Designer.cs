﻿namespace DSW_Semester_Project
{
    partial class CollectionStaff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panelSideBar = new Panel();
            panelUserDisplay = new Panel();
            btnSignOut2 = new Button();
            lblCollectionStaff = new Label();
            pictureBoxIcon = new PictureBox();
            lblCollectionType = new Label();
            lblTitle = new Label();
            chkCollected = new CheckBox();
            chkNotCollected = new CheckBox();
            dgvCollectionStaff = new DataGridView();
            ColumnStreetAddress = new DataGridViewTextBoxColumn();
            Column1 = new DataGridViewTextBoxColumn();
            Time = new DataGridViewTextBoxColumn();
            City = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            label1 = new Label();
            lblCity = new Label();
            lblSuburbOrTown = new Label();
            lblStreetAddress = new Label();
            lblResidentialStreetAddress = new Label();
            pictureBox1 = new PictureBox();
            lblHelloDriver = new Label();
            pictureBox2 = new PictureBox();
            panel1 = new Panel();
            lblCollectionDetails = new Label();
            lblAddress = new Label();
            lblSuburb = new Label();
            lblCityInfo = new Label();
            lblCollectionStatus = new Label();
            lblTime = new Label();
            lblDate = new Label();
            txtTime = new TextBox();
            txtDate = new TextBox();
            txtStreetAddress = new TextBox();
            txtSuburb = new TextBox();
            txtCity = new TextBox();
            rbCollected = new RadioButton();
            rbNotCollected = new RadioButton();
            lblReasonforNotCollecting = new Label();
            comboBox1 = new ComboBox();
            btnUpdateStatus = new Button();
            panel2 = new Panel();
            lblRecentCollection = new Label();
            dgvTasks = new DataGridView();
            StreetAddress = new DataGridViewTextBoxColumn();
            Status = new DataGridViewTextBoxColumn();
            Reason = new DataGridViewTextBoxColumn();
            Date = new DataGridViewTextBoxColumn();
            panelSideBar.SuspendLayout();
            panelUserDisplay.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxIcon).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvCollectionStaff).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvTasks).BeginInit();
            SuspendLayout();
            // 
            // panelSideBar
            // 
            panelSideBar.BackColor = Color.FromArgb(0, 64, 0);
            panelSideBar.Controls.Add(panelUserDisplay);
            panelSideBar.Controls.Add(pictureBoxIcon);
            panelSideBar.Controls.Add(lblCollectionType);
            panelSideBar.Controls.Add(lblTitle);
            panelSideBar.Location = new Point(0, 3);
            panelSideBar.Name = "panelSideBar";
            panelSideBar.Size = new Size(270, 716);
            panelSideBar.TabIndex = 2;
            // 
            // panelUserDisplay
            // 
            panelUserDisplay.BackColor = Color.Transparent;
            panelUserDisplay.BackgroundImageLayout = ImageLayout.None;
            panelUserDisplay.Controls.Add(btnSignOut2);
            panelUserDisplay.Controls.Add(lblCollectionStaff);
            panelUserDisplay.Location = new Point(30, 591);
            panelUserDisplay.Name = "panelUserDisplay";
            panelUserDisplay.Size = new Size(194, 97);
            panelUserDisplay.TabIndex = 1;
            // 
            // btnSignOut2
            // 
            btnSignOut2.BackColor = Color.FromArgb(0, 64, 0);
            btnSignOut2.ForeColor = Color.White;
            btnSignOut2.Location = new Point(23, 60);
            btnSignOut2.Name = "btnSignOut2";
            btnSignOut2.Size = new Size(94, 29);
            btnSignOut2.TabIndex = 1;
            btnSignOut2.Text = "→ Sign Out";
            btnSignOut2.UseVisualStyleBackColor = false;
            btnSignOut2.Click += btnSignOut2_Click;
            // 
            // lblCollectionStaff
            // 
            lblCollectionStaff.AutoSize = true;
            lblCollectionStaff.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCollectionStaff.ForeColor = Color.White;
            lblCollectionStaff.Location = new Point(23, 17);
            lblCollectionStaff.Name = "lblCollectionStaff";
            lblCollectionStaff.Size = new Size(116, 20);
            lblCollectionStaff.TabIndex = 1;
            lblCollectionStaff.Text = "Collection Staff";
            // 
            // pictureBoxIcon
            // 
            pictureBoxIcon.Image = Properties.Resources.WhatsApp_Image_2026_09_12_at_17_39_25;
            pictureBoxIcon.Location = new Point(11, 36);
            pictureBoxIcon.Name = "pictureBoxIcon";
            pictureBoxIcon.Size = new Size(65, 55);
            pictureBoxIcon.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxIcon.TabIndex = 1;
            pictureBoxIcon.TabStop = false;
            // 
            // lblCollectionType
            // 
            lblCollectionType.AutoSize = true;
            lblCollectionType.Font = new Font("Segoe UI", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblCollectionType.ForeColor = Color.White;
            lblCollectionType.Location = new Point(107, 67);
            lblCollectionType.Name = "lblCollectionType";
            lblCollectionType.Size = new Size(95, 17);
            lblCollectionType.TabIndex = 1;
            lblCollectionType.Text = "Collection Staff";
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTitle.ForeColor = Color.White;
            lblTitle.Location = new Point(98, 36);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(142, 31);
            lblTitle.TabIndex = 1;
            lblTitle.Text = "Smart Waste";
            // 
            // chkCollected
            // 
            chkCollected.AutoSize = true;
            chkCollected.Location = new Point(12, 256);
            chkCollected.Margin = new Padding(3, 2, 3, 2);
            chkCollected.Name = "chkCollected";
            chkCollected.Size = new Size(76, 19);
            chkCollected.TabIndex = 11;
            chkCollected.Text = "Collected";
            chkCollected.UseVisualStyleBackColor = true;
            // 
            // chkNotCollected
            // 
            chkNotCollected.AutoSize = true;
            chkNotCollected.Location = new Point(200, 256);
            chkNotCollected.Margin = new Padding(3, 2, 3, 2);
            chkNotCollected.Name = "chkNotCollected";
            chkNotCollected.Size = new Size(99, 19);
            chkNotCollected.TabIndex = 10;
            chkNotCollected.Text = "Not Collected";
            chkNotCollected.UseVisualStyleBackColor = true;
            // 
            // dgvCollectionStaff
            // 
            dgvCollectionStaff.AllowUserToAddRows = false;
            dgvCollectionStaff.AllowUserToDeleteRows = false;
            dgvCollectionStaff.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvCollectionStaff.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvCollectionStaff.Columns.AddRange(new DataGridViewColumn[] { ColumnStreetAddress, Column1, Time, City, Column2 });
            dgvCollectionStaff.Location = new Point(0, 356);
            dgvCollectionStaff.Margin = new Padding(3, 2, 3, 2);
            dgvCollectionStaff.MultiSelect = false;
            dgvCollectionStaff.Name = "dgvCollectionStaff";
            dgvCollectionStaff.RowHeadersWidth = 51;
            dgvCollectionStaff.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvCollectionStaff.Size = new Size(492, 96);
            dgvCollectionStaff.TabIndex = 9;
            // 
            // ColumnStreetAddress
            // 
            ColumnStreetAddress.HeaderText = "Street Address";
            ColumnStreetAddress.MinimumWidth = 6;
            ColumnStreetAddress.Name = "ColumnStreetAddress";
            // 
            // Column1
            // 
            Column1.HeaderText = "Suburb";
            Column1.MinimumWidth = 6;
            Column1.Name = "Column1";
            // 
            // Time
            // 
            Time.HeaderText = "Time";
            Time.MinimumWidth = 6;
            Time.Name = "Time";
            // 
            // City
            // 
            City.HeaderText = "City";
            City.MinimumWidth = 6;
            City.Name = "City";
            // 
            // Column2
            // 
            Column2.HeaderText = "Collected";
            Column2.MinimumWidth = 6;
            Column2.Name = "Column2";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 154);
            label1.Name = "label1";
            label1.Size = new Size(37, 15);
            label1.TabIndex = 8;
            label1.Text = "Time:";
            // 
            // lblCity
            // 
            lblCity.AutoSize = true;
            lblCity.Location = new Point(12, 196);
            lblCity.Name = "lblCity";
            lblCity.Size = new Size(31, 15);
            lblCity.TabIndex = 3;
            lblCity.Text = "City:";
            // 
            // lblSuburbOrTown
            // 
            lblSuburbOrTown.AutoSize = true;
            lblSuburbOrTown.Location = new Point(12, 119);
            lblSuburbOrTown.Name = "lblSuburbOrTown";
            lblSuburbOrTown.Size = new Size(82, 15);
            lblSuburbOrTown.TabIndex = 2;
            lblSuburbOrTown.Text = "Suburb/Town:";
            // 
            // lblStreetAddress
            // 
            lblStreetAddress.AutoSize = true;
            lblStreetAddress.Location = new Point(12, 76);
            lblStreetAddress.Name = "lblStreetAddress";
            lblStreetAddress.Size = new Size(85, 15);
            lblStreetAddress.TabIndex = 1;
            lblStreetAddress.Text = "Street Address:";
            // 
            // lblResidentialStreetAddress
            // 
            lblResidentialStreetAddress.AutoSize = true;
            lblResidentialStreetAddress.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblResidentialStreetAddress.Location = new Point(136, 9);
            lblResidentialStreetAddress.Name = "lblResidentialStreetAddress";
            lblResidentialStreetAddress.Size = new Size(182, 20);
            lblResidentialStreetAddress.TabIndex = 0;
            lblResidentialStreetAddress.Text = "Residential Street Address";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.WhatsApp_Image_2026_09_14_at_14_21_39;
            pictureBox1.Location = new Point(875, 56);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(485, 388);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // lblHelloDriver
            // 
            lblHelloDriver.AutoSize = true;
            lblHelloDriver.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblHelloDriver.Location = new Point(374, 20);
            lblHelloDriver.Name = "lblHelloDriver";
            lblHelloDriver.Size = new Size(104, 23);
            lblHelloDriver.TabIndex = 5;
            lblHelloDriver.Text = "Hello Driver!";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.vehicle;
            pictureBox2.Location = new Point(312, 12);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(56, 37);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 6;
            pictureBox2.TabStop = false;
            // 
            // panel1
            // 
            panel1.Controls.Add(btnUpdateStatus);
            panel1.Controls.Add(comboBox1);
            panel1.Controls.Add(lblReasonforNotCollecting);
            panel1.Controls.Add(rbNotCollected);
            panel1.Controls.Add(rbCollected);
            panel1.Controls.Add(txtCity);
            panel1.Controls.Add(txtSuburb);
            panel1.Controls.Add(txtStreetAddress);
            panel1.Controls.Add(txtDate);
            panel1.Controls.Add(txtTime);
            panel1.Controls.Add(lblDate);
            panel1.Controls.Add(lblTime);
            panel1.Controls.Add(lblCollectionStatus);
            panel1.Controls.Add(lblCityInfo);
            panel1.Controls.Add(lblSuburb);
            panel1.Controls.Add(lblAddress);
            panel1.Controls.Add(lblCollectionDetails);
            panel1.Location = new Point(286, 56);
            panel1.Name = "panel1";
            panel1.Size = new Size(583, 388);
            panel1.TabIndex = 7;
            // 
            // lblCollectionDetails
            // 
            lblCollectionDetails.AutoSize = true;
            lblCollectionDetails.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCollectionDetails.Location = new Point(14, 16);
            lblCollectionDetails.Name = "lblCollectionDetails";
            lblCollectionDetails.Size = new Size(150, 23);
            lblCollectionDetails.TabIndex = 0;
            lblCollectionDetails.Text = "Collection Details";
            // 
            // lblAddress
            // 
            lblAddress.AutoSize = true;
            lblAddress.Location = new Point(19, 68);
            lblAddress.Name = "lblAddress";
            lblAddress.Size = new Size(105, 20);
            lblAddress.TabIndex = 1;
            lblAddress.Text = "Street Address";
            // 
            // lblSuburb
            // 
            lblSuburb.AutoSize = true;
            lblSuburb.Location = new Point(19, 109);
            lblSuburb.Name = "lblSuburb";
            lblSuburb.Size = new Size(97, 20);
            lblSuburb.TabIndex = 2;
            lblSuburb.Text = "Suburb/Town";
            // 
            // lblCityInfo
            // 
            lblCityInfo.AutoSize = true;
            lblCityInfo.Location = new Point(19, 151);
            lblCityInfo.Name = "lblCityInfo";
            lblCityInfo.Size = new Size(34, 20);
            lblCityInfo.TabIndex = 3;
            lblCityInfo.Text = "City";
            // 
            // lblCollectionStatus
            // 
            lblCollectionStatus.AutoSize = true;
            lblCollectionStatus.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCollectionStatus.Location = new Point(14, 199);
            lblCollectionStatus.Name = "lblCollectionStatus";
            lblCollectionStatus.Size = new Size(126, 20);
            lblCollectionStatus.TabIndex = 4;
            lblCollectionStatus.Text = "Collection Status";
            // 
            // lblTime
            // 
            lblTime.AutoSize = true;
            lblTime.Location = new Point(319, 68);
            lblTime.Name = "lblTime";
            lblTime.Size = new Size(42, 20);
            lblTime.TabIndex = 5;
            lblTime.Text = "Time";
            // 
            // lblDate
            // 
            lblDate.AutoSize = true;
            lblDate.Location = new Point(320, 109);
            lblDate.Name = "lblDate";
            lblDate.Size = new Size(41, 20);
            lblDate.TabIndex = 6;
            lblDate.Text = "Date";
            // 
            // txtTime
            // 
            txtTime.Location = new Point(404, 68);
            txtTime.Name = "txtTime";
            txtTime.Size = new Size(125, 27);
            txtTime.TabIndex = 7;
            // 
            // txtDate
            // 
            txtDate.Location = new Point(404, 106);
            txtDate.Name = "txtDate";
            txtDate.Size = new Size(125, 27);
            txtDate.TabIndex = 8;
            // 
            // txtStreetAddress
            // 
            txtStreetAddress.Location = new Point(149, 68);
            txtStreetAddress.Name = "txtStreetAddress";
            txtStreetAddress.Size = new Size(125, 27);
            txtStreetAddress.TabIndex = 9;
            // 
            // txtSuburb
            // 
            txtSuburb.Location = new Point(149, 109);
            txtSuburb.Name = "txtSuburb";
            txtSuburb.Size = new Size(125, 27);
            txtSuburb.TabIndex = 10;
            // 
            // txtCity
            // 
            txtCity.Location = new Point(149, 148);
            txtCity.Name = "txtCity";
            txtCity.Size = new Size(125, 27);
            txtCity.TabIndex = 11;
            // 
            // rbCollected
            // 
            rbCollected.AutoSize = true;
            rbCollected.Location = new Point(32, 239);
            rbCollected.Name = "rbCollected";
            rbCollected.Size = new Size(93, 24);
            rbCollected.TabIndex = 12;
            rbCollected.TabStop = true;
            rbCollected.Text = "Collected";
            rbCollected.UseVisualStyleBackColor = true;
            // 
            // rbNotCollected
            // 
            rbNotCollected.AutoSize = true;
            rbNotCollected.Location = new Point(192, 239);
            rbNotCollected.Name = "rbNotCollected";
            rbNotCollected.Size = new Size(122, 24);
            rbNotCollected.TabIndex = 13;
            rbNotCollected.TabStop = true;
            rbNotCollected.Text = "Not Collected";
            rbNotCollected.UseVisualStyleBackColor = true;
            // 
            // lblReasonforNotCollecting
            // 
            lblReasonforNotCollecting.AutoSize = true;
            lblReasonforNotCollecting.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblReasonforNotCollecting.Location = new Point(14, 294);
            lblReasonforNotCollecting.Name = "lblReasonforNotCollecting";
            lblReasonforNotCollecting.Size = new Size(189, 20);
            lblReasonforNotCollecting.TabIndex = 14;
            lblReasonforNotCollecting.Text = "Reason for Not Collecting";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Bins not out", "Access blocked", "Bin Damaged", "Contaminated", "Other" });
            comboBox1.Location = new Point(215, 291);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(348, 28);
            comboBox1.TabIndex = 15;
            // 
            // btnUpdateStatus
            // 
            btnUpdateStatus.BackColor = Color.DodgerBlue;
            btnUpdateStatus.ForeColor = Color.White;
            btnUpdateStatus.Location = new Point(118, 344);
            btnUpdateStatus.Name = "btnUpdateStatus";
            btnUpdateStatus.Size = new Size(348, 29);
            btnUpdateStatus.TabIndex = 16;
            btnUpdateStatus.Text = "Update Status";
            btnUpdateStatus.UseVisualStyleBackColor = false;
            btnUpdateStatus.Click += btnUpdateStatus_Click;
            // 
            // panel2
            // 
            panel2.Controls.Add(dgvTasks);
            panel2.Controls.Add(lblRecentCollection);
            panel2.Location = new Point(286, 450);
            panel2.Name = "panel2";
            panel2.Size = new Size(1072, 253);
            panel2.TabIndex = 8;
            // 
            // lblRecentCollection
            // 
            lblRecentCollection.AutoSize = true;
            lblRecentCollection.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblRecentCollection.Location = new Point(10, 10);
            lblRecentCollection.Name = "lblRecentCollection";
            lblRecentCollection.Size = new Size(130, 20);
            lblRecentCollection.TabIndex = 0;
            lblRecentCollection.Text = "Recent Collection";
            // 
            // dgvTasks
            // 
            dgvTasks.AllowUserToAddRows = false;
            dgvTasks.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvTasks.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvTasks.Columns.AddRange(new DataGridViewColumn[] { StreetAddress, Status, Reason, Date });
            dgvTasks.Location = new Point(0, 33);
            dgvTasks.MultiSelect = false;
            dgvTasks.Name = "dgvTasks";
            dgvTasks.RowHeadersWidth = 51;
            dgvTasks.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvTasks.Size = new Size(1069, 217);
            dgvTasks.TabIndex = 1;
            // 
            // StreetAddress
            // 
            StreetAddress.HeaderText = "Street Address";
            StreetAddress.MinimumWidth = 6;
            StreetAddress.Name = "StreetAddress";
            // 
            // Status
            // 
            Status.HeaderText = "Status";
            Status.MinimumWidth = 6;
            Status.Name = "Status";
            // 
            // Reason
            // 
            Reason.HeaderText = "Reason";
            Reason.MinimumWidth = 6;
            Reason.Name = "Reason";
            // 
            // Date
            // 
            Date.HeaderText = "Date";
            Date.MinimumWidth = 6;
            Date.Name = "Date";
            // 
            // CollectionStaff
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1370, 715);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(pictureBox2);
            Controls.Add(lblHelloDriver);
            Controls.Add(pictureBox1);
            Controls.Add(panelSideBar);
            Name = "CollectionStaff";
            Text = "CollectionStaff";
            panelSideBar.ResumeLayout(false);
            panelSideBar.PerformLayout();
            panelUserDisplay.ResumeLayout(false);
            panelUserDisplay.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxIcon).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvCollectionStaff).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvTasks).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panelSideBar;
        private Panel panelUserDisplay;
        private Button btnSignOut2;
        private Label lblCollectionStaff;
        private PictureBox pictureBoxIcon;
        private Label lblCollectionType;
        private Label lblTitle;
        private WindowsFormsApp1.RoundedPanel roundedPanel1;
        private PictureBox pictureBox1;
        private Label lblHelloDriver;
        private PictureBox pictureBox2;
        private Label lblCity;
        private Label lblSuburbOrTown;
        private Label lblStreetAddress;
        private Label lblResidentialStreetAddress;
        private WindowsFormsApp1.RoundedButton roundedButton1;
        private Label label1;
        private DataGridView dgvCollectionStaff;
        private DataGridViewTextBoxColumn ColumnStreetAddress;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Time;
        private DataGridViewTextBoxColumn City;
        private DataGridViewTextBoxColumn Column2;
        private CheckBox chkNotCollected;
        private CheckBox chkCollected;
        private Panel panel1;
        private Label lblCollectionDetails;
        private Label lblDate;
        private Label lblTime;
        private Label lblCollectionStatus;
        private Label lblCityInfo;
        private Label lblSuburb;
        private Label lblAddress;
        private TextBox txtStreetAddress;
        private TextBox txtDate;
        private TextBox txtTime;
        private TextBox txtCity;
        private TextBox txtSuburb;
        private Label lblReasonforNotCollecting;
        private RadioButton rbNotCollected;
        private RadioButton rbCollected;
        private Button btnUpdateStatus;
        private ComboBox comboBox1;
        private Panel panel2;
        private DataGridView dgvTasks;
        private DataGridViewTextBoxColumn StreetAddress;
        private DataGridViewTextBoxColumn Status;
        private DataGridViewTextBoxColumn Reason;
        private DataGridViewTextBoxColumn Date;
        private Label lblRecentCollection;
    }
}